package com.qf.Inner_static;
/*
* 静态内部类
*   不依赖外部类对象，可直接创建对象或通过类名访问，可声明静态成员
*   只能直接访问外部类的静态成员
*
* */

//外部类
public class Outer {
    //外部类属性
    private String name = "XXX";
    private int age = 20;

    //静态内部类,和外部类等级相同 (只有内部类才可以被static修饰)
    static class Inner {
        //静态内部类属性
        private String address = "上海";
        private String phone = "222";

        //静态成员
        private static int count = 1000;

        //静态内部类方法
        public void show(){
            //打印外部类属性
            System.out.println("-------打印外部类属性-------");
            //1.创建外部类对象
            Outer outer = new Outer();
            //2.通过外部类对象调用属性
            System.out.println(outer.name);
            System.out.println(outer.age);

            //打印静态内部类属性
            System.out.println("-------打印静态内部类属性-------");
            System.out.println(this.address);
            System.out.println(this.phone);

            //打印静态内部类静态成员
            System.out.println("-------打印静态内部类静态成员-------");
            //通过类名.属性名方法调用静态成员
            System.out.println(Inner.count);


        }
    }
}
