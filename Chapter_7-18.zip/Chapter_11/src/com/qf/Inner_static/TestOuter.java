package com.qf.Inner_static;

import com.qf.Inner_static.Outer.Inner;

public class TestOuter {
    public static void main(String[] args) {
        //直接创建静态内部类对象(静态内部类与外部类等级相同)
        //Outer.Inner 表示Inner包含在Outer内部，与Outer无关
        Outer.Inner inner = new Inner();
        inner.show();
    }
}
