package com.qf.Package;
/*
* 包装类
*   基本数据类型所对应的引用数据类型
*       基本数据类型包装成引用数据类型以后可以拥有属性和方法
*       基本数据类型: byte short int     long float double boolean char
*       引用数据类型: Byte Short Integer Long Float Double Boolean Character
*   Object可统一所有数据,包装类的默认值时null
* 类型转换与 装箱 拆箱
*   基本数据类型保存在栈空间内,引用数据类型保存在堆空间中
*   装箱: 基本数据类型从栈空间拿到堆空间变成引用数据类型
*   拆箱: 引用数据类型从堆空间拿到栈空间变成基本数据类型
*
*
*
*
*
* */
public class PackageClass {
    public static void main(String[] args) {
//        //类型转换: 装箱,基本类型 -> 引用类型
//        //基本类型
//        int num1 = 18;
//        //使用Integer类创建对象
//        Integer integer1 = new Integer(num1);
//        Integer integer2 = Integer.valueOf(num1);
//        System.out.println("--------装箱--------");
//        System.out.println(integer1);
//        System.out.println(integer2);
//
//        //类型转换: 拆箱,引用类型 -> 基本类型
//        //引用类型
//        Integer integer3 = new Integer(100);
//        int num2 = integer3.intValue();
//        System.out.println("--------拆箱--------");
//        System.out.println(num2);
//
//        //JDK1.5以后，提供自动拆箱和装箱
//        int num3 = 100;
//        //自动装箱
//        System.out.println("--------自动装箱--------");
//        Integer integer4 = num3;
//        System.out.println(integer4);
//        //自动拆箱
//        System.out.println("--------自动拆箱--------");
//        int num4 = integer4;
//        System.out.println(num4);
//
//        //基本类型与字符串之间的转换
//        System.out.println("--------基本类型与字符串之间的转换--------");
//        //基本类型 -> 字符串
//        //1.1使用+号
//        int n1 = 15;
//        String s1 = n1+" ";
//        System.out.println(n1);
//        //1.2使用Integer中的toString()方法
//        String s2 = Integer.toString(n1);
//        System.out.println(s2);
//        //将n1转换成对应机制的字符串
//        String s3 = Integer.toString(n1,16);//f
//        System.out.println(s3);
//
//        //字符串 -> 基本类型
//        String str1 = "145";
//        //使用Integer.parseXXX
//        int n2 = Integer.parseInt(str1);
//        System.out.println(n2);
//
//
//        //boolean字符串形式转换成基本类型 "true" --> true  非"true" --> false
//        System.out.println("--------boolean字符串形式转换成基本类型--------");
//        String str2 = "true";
//        Boolean b1 = Boolean.parseBoolean(str2);
//        System.out.println("\'"+str2+"'-->"+b1);
//        String str3 = "trueeee";
//        String str4 = "false";
//        Boolean b2 = Boolean.parseBoolean(str3);
//        Boolean b3 = Boolean.parseBoolean(str4);
//        System.out.println("\'"+str3+"'-->"+b2+"\n"+"\'"+str4+"'-->"+b3);

        String st1 = "true";
        String st2 = "falses";

        boolean st3 =  Boolean.parseBoolean(st2);
        System.out.println(st3);
    }



}
