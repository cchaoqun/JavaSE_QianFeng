package com.qf.Package;
/*
* 整数缓冲区
*
* */
public class IntegerCache {
    public static void main(String[] args) {
        //面试题
        Integer integer1 = new Integer(100);
        Integer integer2 = new Integer(100);
        System.out.println(integer1 == integer2);//false
        //创建两个Integer引用类型，地址不同

        Integer integer3 = Integer.valueOf(100);//自动装箱调用Integer.valueOf()方法
        Integer integer4 = Integer.valueOf(100);
        System.out.println(integer3 == integer4);//true
        //堆空间存在 -127~128的整数缓冲区，直接调用100，因此两者地址相同
        //对已创建的对象进行复用

        Integer integer5 = Integer.valueOf(200);
        Integer integer6 = Integer.valueOf(200);
        System.out.println(integer5 == integer6);//false
        //200不在整数缓冲区之间，因此，new Integer()创建了新的引用类型，导致两者地址不同
//
//        //装箱
//        int i1 = 1;
//        Integer integer7 = new Integer(i1);
//        Integer integer8 = Integer.valueOf(i1);
//        //拆箱
//        Integer integer9 = new Integer(2);
//        int i2 = integer9.intValue();
//        //自动装箱
//        int i3 = 3;
//        Integer integer10 = i3;
//        //自动拆箱
//        int i4 = integer10;
//
        String s1 = Integer.toString(10,8);
        System.out.println(s1);

    }
}
