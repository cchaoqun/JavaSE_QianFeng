package com.qf.Date;

import java.util.Calendar;

/*
* Calendar
*
* */
public class calendar {
    public static void main(String[] args) {
        //1.创建Calendar对象 protected修饰，没有构造方法
        Calendar calendar = Calendar.getInstance();
        //getTime() 获取Date
        System.out.println(calendar.getTime().toLocaleString());
        //getTimeMillis() 获取毫秒数
        System.out.println(calendar.getTimeInMillis());

        //2.获取时间信息
        //年
        int year = calendar.get(Calendar.YEAR); //1
        //月 0-11
        int month = calendar.get(Calendar.MONTH);
        //日
        int day = calendar.get(Calendar.DAY_OF_MONTH);//DATE
        //时
        int hour = calendar.get(Calendar.HOUR_OF_DAY);//HOUR12小时 HOUR_OF_DAY24小时
        //分
        int minute = calendar.get(Calendar.MINUTE);
        //秒
        int second = calendar.get(Calendar.SECOND);
        System.out.println(year+"年"+(month+1)+"月"+day+"日"+hour+":"+minute+":"+second);

        //3.修改时间 set()
        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(Calendar.DAY_OF_MONTH,5);
        System.out.println(calendar2.getTime().toLocaleString());

        //4.add()增加指定field的值
        calendar2.add(Calendar.HOUR_OF_DAY, -1);
        System.out.println(calendar2.getTime().toLocaleString());

        //补充方法
        calendar2.add(Calendar.MONTH,1);
        int max = calendar2.getActualMaximum(Calendar.DAY_OF_MONTH);
        int min = calendar2.getActualMinimum(Calendar.DAY_OF_MONTH);
        System.out.println(max);
        System.out.println(min);

    }
}
