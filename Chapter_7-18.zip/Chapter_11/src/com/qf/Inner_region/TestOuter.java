package com.qf.Inner_region;

public class TestOuter {
    public static void main(String[] args) {

        Outer outer = new Outer();
        outer.showOuter();
    }
}
