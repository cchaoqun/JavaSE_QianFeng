package com.qf.Inner_region;
/*
* 局部内部类
*   定义在外部类方法中的类,作用方法和创建对象范围仅限于当前方法
*   局部内部类访问外部类当前方法中的局部变量时，因无法保障局部变量的声明周期和自身相同，变量必须修饰为final
*   限制类的使用范围
*
*
* */

//外部类
public class Outer {
    private String name = "外部类属性";
    private int age = 20;

    public void showOuter(){
        //定义局部变量
        final String address = "上海";

        //局部内部类:
        class Inner{
            //局部内部类的属性
            private String phone = "15216798873";
            private String email = "chengchaoqun@hotmail.com";

            //局部内部类不能定义静态成员
            //private static String county = "xxx";
            //局部内部类可以定义静态常量
            private static final String county = "XXX";

            public void showInner(){
                //打印外部类属性
                System.out.println("--------打印外部类属性--------");
                System.out.println(Outer.this.name);
                System.out.println(Outer.this.age);

                //访问局部内部类属性
                System.out.println("--------打印局部内部类属性--------");
                System.out.println(this.phone);
                System.out.println(this.email);

                //访问外部类方法中的局部变量
                System.out.println("--------访问外部类方法中的局部变量--------");
                //访问局部变量，jdk1.7要求局部变量必须时常量 final. jdk1.8自动添加final
                System.out.println(address);//address只能定义一次，不能修改
            }

        }
        //访问局部内部类中的方法，必须创建局部内部类对象才可以调用其方法
        //创建局部内部类对象
        Inner inner = new Inner();
        inner.showInner();
    }
}
