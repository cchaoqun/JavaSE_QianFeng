package com.qf.System;

public class sys {
    public static void main(String[] args) {
        //1.System.arraycopy(); 复制数组
        //src 源数组
        //srcPos 从源数组的哪个位置开始复制
        //dest 目标数组
        //destPos 将复制的部分数组放入目标数组的位置
        //length 复制源数组的长度
        //System, static类，无需创建对象，通过 .方法调用参数和方法

        int[] arr = new int[]{1,2,3,4,5,6,7,8};
        int[] dest = new int[8];
        System.arraycopy(arr, 4, dest, 4, 4);
        for (int i = 0; i < dest.length; i++) {
            System.out.println(dest[i]);
        }

        //2.System.currentTimeMillis(); 获取当前时间毫秒数
        //可用于计算程序运行时间
        //起始时间
        long start = System.currentTimeMillis();

        for (int i = -999999999; i < 99999999; i++) {
            for (int j = -99999999; j < 99999999; j++) {
                int result = i+j;
            }
        }
        //结束时间
        long end = System.currentTimeMillis();
        System.out.println("用时："+(end-start));

        new Student("aaa", 20);
        new Student("bbb", 20);
        new Student("ccc", 20);
        new Student("ddd", 20);

        //3.垃圾回收器
        System.gc();//告诉JVM垃圾回收器回收垃圾，但并不一定执行，由JVM决定

        //4.退出JVM (o表示正常退出，1表示异常退出)
        System.exit(0);
        //程序已经结束，并不会执行以下程序
        System.out.println("程序结束了");


    }
}
