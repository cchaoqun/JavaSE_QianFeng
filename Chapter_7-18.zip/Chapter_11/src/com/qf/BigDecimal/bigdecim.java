package com.qf.BigDecimal;

import java.math.BigDecimal;

/*
* BigDecimal
*
* */
public class bigdecim {
    public static void main(String[] args) {
        //double 类型是近似值存储，看上去是1.0，实际可能为0.9999999999999999998，因此造成误差
        double d1 = 1.0;
        double d2 = 0.9;
        System.out.println(d1-d2);
        double d3 = (1.4-0.5)/0.9;
        System.out.println(d3);

        //BigDecimal 大的浮点数精确计算
        //传入值时，选择String类型，这样值最准确
        BigDecimal bd1 = new BigDecimal("1.0");
        BigDecimal bd2 = new BigDecimal("0.9");
        //相减 subtract()  使用BigDecimal subtract()方法相减
        BigDecimal result = bd1.subtract(bd2);
        System.out.println(result);

        //加法 add()
        BigDecimal r2 = bd1.add(bd2);
        System.out.println(r2);

        //乘法 multiply()
        BigDecimal r3 = bd1.multiply(bd2);
        System.out.println(r3);

        //除法 divide()
        BigDecimal r4 = new BigDecimal("1.4")
                .subtract(new BigDecimal("0.5"))
                .divide(new BigDecimal("0.9"));
        System.out.println(r4);
        //除法如果不能除尽，且不明确保留几位小数的情况会报错
        //                                                                      保留两位小数         四舍五入
        BigDecimal r5 = new BigDecimal("20").divide(new BigDecimal("3"),2,BigDecimal.ROUND_HALF_UP);
        System.out.println(r5);

        BigDecimal bd6 = new BigDecimal("1.4")
                    .subtract(new BigDecimal("0.5"))
                    .divide(new BigDecimal("0.9"));
        System.out.println(bd6);

    }
}
