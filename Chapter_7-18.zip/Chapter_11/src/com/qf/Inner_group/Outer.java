package com.qf.Inner_group;
/*
* 成员内部类
*    在类的内部定义，与实例变量，实例方法同级别的类
 *   外部类的一个实例部分，在创建内部对象的时候，必须依赖外部对象 (必须先创建外部对象再创建对象)
 *       Outer out = new Outer();
 *       Inner in = out.new Inner();
 *    or Inner in = new Outer().new Inner()
 *   当外部类，内部类具有重名属性时，会优先访问内部属性
 *       内部类中访问内部类属性： this.属性名
 *       内部类中访问外部类属性： 外部类名.this.属性名
 *   成员内部类不能定义静态成员
* */
//外部类
public class Outer {
    //外部类实例变量
    private String name = "外部张三";
    private int age = 20;

    //内部类
    class Inner{
        private String address = "上海";
        private String phone = "110";
        private String name = "内部李四";

        //成员内部类不能定义静态成员
        //private static String country = "中国";
        //成员内部类可以定义静态常量
        private static final String country = "中国";


        public void show(){
            System.out.println("--------打印外部类中的变量--------");
            System.out.println("--------内部类属性和外部类属性名字相同，通过外部类名.this.外部类属性名访问--------");
            //打印外部类name属性
            System.out.println(Outer.this.name);
            System.out.println(Outer.this.age);
            System.out.println("--------打印内部类中的变量--------");
            System.out.println(this.name);
            System.out.println(this.address);
            //打印内部类name属性
            System.out.println(this.phone);
        }

    }
}
