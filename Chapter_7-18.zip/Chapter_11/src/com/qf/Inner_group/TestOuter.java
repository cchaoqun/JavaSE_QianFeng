package com.qf.Inner_group;
/*
* 成员内部类
*   在类的内部定义，与实例变量，实例方法同级别的类
*   外部类的一个实例部分，在创建内部对象的时候，必须依赖外部对象 (必须先创建外部对象再创建对象)
*       Outer out = new Outer();
*       Inner in = out.new Inner();
*    or Inner in = new Outer().new Inner()
*   当外部类，内部类具有重名属性时，会优先访问内部属性
*       内部类中访问内部类属性： this.属性名
*       内部类中访问外部类属性： 外部类名.this.属性名
*   成员内部类不能定义静态成员
*
*
*
* */
import com.qf.Inner_group.Outer.Inner;

public class TestOuter {
    public static void main(String[] args) {

        //方法一，外部类对象 -> 内部类对象
        //1.创建外部类对象
        Outer outer = new Outer();
        //2.创建内部类对象
        Inner inner = outer.new Inner();

//        //方法二 一步到位
//        Inner inner = new Outer().new Inner();

        inner.show();
    }
}
