package com.qf.Str1;
/*
* 需求
*   已知 String str = "this is a text"
*   1.将str中的单词单独提取出来
*   2.将text替换成practice
*   3.在text前面插入 easy
*   4.将每个单词首字母改成大写
*
*
*
*
* */
public class Str_Practice {
    public static void main(String[] args) {
//        String str = "this is a text";
//        //1.将str中的单词单独提取出来
//        String[] arr = str.split(" ");
//        System.out.println("--------1.将str中的单词单独提取出来--------");
//        for (int i = 0; i < arr.length; i++) {
//            System.out.println(arr[i]);
//        }
//        //2.将text替换成practice
//        String str2= str.replace("text", "practice");
//        System.out.println("--------2.将text替换成practice--------");
//        System.out.println(str2);
//
//        //3.在text前面插入easy
//        String str3 = str.replace("text", "easy text");
//        System.out.println("--------3.在text前面插入easy--------");
//        System.out.println(str3);
//
//        //4.将每个单词首字母改成大写
//        for (int i = 0; i < arr.length; i++) {
//            //找到每个单词的第一个字母
//            char first = arr[i].charAt(0);
//            //利用Character引用类型方法变成大写
//            char upperFirst = Character.toUpperCase(first);
//            //利用substring将大写的首字母与剩余字母拼接在一起
//            String newfirst = upperFirst+arr[i].substring(1);//拼接从1开始的剩余字符
//            System.out.println(newfirst);
//
//        }
        String str = "this is a text";
        String[] str2 = str.replace("text","easy practice").split(" ");
        String[] str3 = new String[str2.length];
        for (int i = 0; i < str2.length; i++) {
            char c1 = str2[i].charAt(0);
            char first = Character.toUpperCase(c1);
            str3[i] = str2[i].replace(c1,first);

        }
        for (int i = 0; i < str3.length; i++) {
            System.out.println(str3[i]);
        }

    }
}
