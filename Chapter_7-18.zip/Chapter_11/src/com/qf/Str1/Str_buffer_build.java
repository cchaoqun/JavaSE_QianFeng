package com.qf.Str1;

/*
* 可变字符串 StringBuffer StringBuilder
* 和String的区别
*   1.比String效率更高
*   2.比String占用内存更小
*
*
* */
public class Str_buffer_build {
    public static void main(String[] args) {
        //创建可变字符串
        StringBuilder sb = new StringBuilder();
        //append();追加
        System.out.println("----------append()----------");
        sb.append("java世界第一");
        System.out.println(sb.toString());
        sb.append("java真香");
        System.out.println(sb.toString());
        sb.append("javaBest");
        System.out.println(sb.toString());

        //insert();插入：在指定位置处添加
        System.out.println("----------insert()----------");
        sb.insert(0,"我在最前面");
        System.out.println(sb.toString());

        //replace();替换: 指定起始和终止位置，并替换成指定字符串(包含起始位置不包含终止位置)
        System.out.println("----------replace()----------");
        sb.replace(0,5,"hello");
        System.out.println(sb.toString());

        //delete();删除: 指定起始和终止位置，删除(包含起始位置不包含终止位置)
        System.out.println("----------delete()----------");
        sb.delete(0,5);
        System.out.println(sb.toString());
        System.out.println("----------delete(0，sb.length())清空----------");
        sb.delete(0,sb.length());
        System.out.println(sb.toString());

        //reverse();反转
        System.out.println("----------reverse()----------");
        StringBuilder sb2 = new StringBuilder("123456");
        sb2.reverse();
        System.out.println(sb2.toString());





    }
}
