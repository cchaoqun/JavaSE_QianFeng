package com.qf.Str1;

import java.util.Arrays;

/*
* String
*
*   字符串是常量，创建以后不可更改
*   字符串字面值存储在字符串池中，可以共享
*   String s = "Hello"; 产生一个对象，字符串池中存储
*   String s = new String("Hello"); 产生两个对象，堆，池中各存储一个
*
*
*
*
* */
public class Str1 {
    public static void main(String[] args) {
        String name = "小明";//"小明"常量存储在字符串池中
        name = "张三";//"张三"赋值给name变量，给字符串赋值时，并没有修改"小明"，而是在字符串池中开辟一个新的空间"张三"
        String name2 = "张三";//栈内开辟一个新的空间 name2,指向字符串池中已经存在的"张三",并未在字符串池中开辟新的空间
        //判断name和name2值是否相同
        System.out.println(name.equals(name2));//true 值相同
        //判断name和name2地址是否相同
        System.out.println(name == name2);//true 都指向了字符串池中的同一个地址 "张三"

        //演示字符串的另一种创建方式 new String();
        String str = new String("java");//在堆空间和方法区内产生两个对象，各存储一个"java"
        String str2 = new String("java");
        //判断str和str2地址是否相同
        System.out.println(str == str2);//false 指向了堆中的两个对象
        //判断str和str2存储值是否相同
        System.out.println(str.equals(str2));//true 值相同

        System.out.println("---------字符串方法的使用1---------");
        //1.length();返回字符串的长度
        //2.charAt(int index);返回特定位置的字符串
        //3.contains(String str);判断是否包含某个字符串

        String content = "java是java世界上最好的语言,java真香";
        System.out.println("---------1.length()---------");
        System.out.println(content.length());
        System.out.println("---------2.charAt(int index)---------");
        System.out.println(content.charAt(content.length()-1));
        System.out.println("---------3.contains(String str)---------");
        System.out.println(content.contains("java"));
        System.out.println(content.contains("va是"));

        System.out.println("---------字符串方法的使用2---------");
        //4.toCharArray();返回字符串对应的数值
        //5.indexOf();返回子字符串首次出现的下标位置，
        //6.lastIndexOf();返回子字符串最后依次出现下标的位置

        System.out.println("---------4.toCharArray()---------");
        System.out.println(content.toCharArray());
        System.out.println(Arrays.toString(content.toCharArray()));

        System.out.println("---------5.indexOf()---------");
        System.out.println(content.indexOf("java"));//0
        System.out.println(content.indexOf("java",4));//5 fromindex = 4,从下标4以后开始找第一出现的java下标
        System.out.println("---------6.lastIndexOf()---------");
        System.out.println(content.lastIndexOf("java"));//18

        System.out.println("---------字符串方法的使用3---------");
        //7.trim();去掉字符串前后的空格，中间的空格不变
        //8.toLowerCase();将字符串全部转换为小写   toUpperCase();将字符串全部转换为大写
        //9.endWith();判断字符串是否以某字符串结尾  startWith();判断字符串是否以某字符串开头

        String content2 = "   Hello World   ";
        String filename = "Hello.java";
        System.out.println("---------7.trim()---------");
        System.out.println(content2.trim());
        System.out.println("---------8.toLowerCase()---------");
        System.out.println(content2.toLowerCase());
        System.out.println(content2.toUpperCase());
        System.out.println("---------9.endWith()---------");
        System.out.println(filename.endsWith(".java"));
        System.out.println(filename.startsWith("Hello"));

        System.out.println("---------字符串方法的使用4---------");
        //10.replace(char old, char new);用旧字符串替换新的字符串
        //11.split(String str);根据字符串做拆分
        String str3 = "java is the best      programming language,java best";
        System.out.println("---------10.replace(char old, char new)---------");
        System.out.println(content.replace("java","php"));
        System.out.println("---------11.split(String str)---------");
        String[] arr1 = str3.split(" ");//用空格分开
        System.out.println(arr1.length);
        String[] arr2 = str3.split("[ ,]");//用空格或者逗号分开
        String[] arr3 = str3.split("[ ,]+");//+代表可以有一个或多个空格和逗号
        //字符串类型数组遍历
        System.out.println("--------\" \"--------");
        for (int i = 0; i < arr1.length; i++) {
            System.out.println(arr1[i]);
        }
        System.out.println("--------\"[ ,]\"--------");

        for (int i = 0; i < arr2.length; i++) {
            System.out.println(arr2[i]);
        }
        System.out.println("--------\"[ ,]+\"--------");
        for (int i = 0; i < arr3.length; i++) {
            System.out.println(arr3[i]);
        }

        System.out.println("---------字符串补充方法---------");
        //equals();比较字符串值是否相等
        //compareTo();比较两个字符串在编码表中的位置，比较第一不相同的字符，位置相减得到结果
        String str4 = "hello";
        String str5 = "HELLO";
        System.out.println(str4.equalsIgnoreCase(str5));//不区分大小写比较是否相等

        String str6 = "abc";//a=97
        String str7 = "xyz";//x=120  a-x = -23
        System.out.println(str6.compareTo(str7));//-23

        //特殊情况
        String str8 = "abc";
        String str9 = "abcxyzas";
        //?
        System.out.println(str8.compareTo(str9));//长度相减





    }
}
