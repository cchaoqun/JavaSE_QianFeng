package com.qf.Str1;
/*
* StringBuilder效率测试
*
* */
public class Str_builder_efficency {
    public static void main(String[] args) {
        //获取开始时间
        long start = System.currentTimeMillis();

        //使用String  result = 97
        //String s = "";
        //for (int i = 1; i < 9999; i++) {
        //    s += i;
        //}
        //System.out.println(s);

        //使用StringBuilder   result = 2
        StringBuilder sb = new StringBuilder(" ");
        for (int i = 0; i < 9999; i++) {
            sb.append(i);
        }
        //获取结束时间
        long end = System.currentTimeMillis();
        System.out.println("用时："+(end-start));

    }
}
