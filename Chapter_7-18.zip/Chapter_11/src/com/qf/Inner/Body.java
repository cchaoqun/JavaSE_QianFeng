package com.qf.Inner;
/*
* 内部类
*   在一个类的内部再定义一个完整的类
*   会生成一个对应的.class文件 (Body$Header.class)
* 特点
*   编译后可生成独立的字节码文件
*   内部类可直接访问外部类的私有成员而不破坏封装
*   可为外部类提供必要的内部组件
* */
public class Body {
    private String name;
    //内部类
    class Header{

        public void show(){
            //内部类可直接访问外部类的私有成员而不破坏封装
            System.out.println(name);
        }

    }
}
