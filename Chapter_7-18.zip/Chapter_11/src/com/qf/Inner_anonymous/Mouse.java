package com.qf.Inner_anonymous;
/*
* 实现类
* */
public class Mouse implements Usb{
    @Override
    public void service() {
        System.out.println("鼠标连接电脑成功，开始工作...");
    }
}
