package com.qf.Inner_anonymous;
/*
* 接口类
* */
public interface Usb {
    //服务
    void service();
}
