package com.qf.Inner_anonymous;
/**
* 匿名内部类
*   没有类名的局部内部类，(一切特征与局部内部类相同)
*   必须承接一个父类，或者实现一个接口
*   实现类，定义类，创建对象的一个语法合并，只能创建一个该类对象
* 优点 减少代码量
* 确定 可读性较差
*
*
* */
public class TestUsb {
    public static void main(String[] args) {
        //创建接口类型的变量
        Usb usb1 = new Mouse();//多态
        usb1.service();

        //局部内部类
        class Fan implements Usb{
            @Override
            public void service() {
                System.out.println("风扇连接电脑成功，开始工作...");
            }
        }
        //使用局部内部类创建对象
        Usb usb2 = new Fan();
        usb2.service();

        //使用匿名内部类进行优化 (相当于创建了一个没有名字的局部内部类，在类的内部重写了方法)
        Usb usb3 = new Usb(){
            @Override
            public void service() {
                System.out.println("风扇连接电脑成功，开始工作...");
            }
        };
        usb3.service();
    }
}
