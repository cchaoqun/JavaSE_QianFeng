package com.qf.Object;

public class Student {
    private String name;
    private int age;

    //默认构造方法
    public Student() {
    }

    //带参构造方法
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    //Get Set

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    //toString()方法重写(方法名相同，参数列表数量顺序一致，修饰符不能更加严格)
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    //equals()方法重写
    //@Override
    //public boolean equals(Object o) {
    //    if (this == o) return true;
    //    if (o == null || getClass() != o.getClass()) return false;
    //    Student student = (Student) o;
    //    return age == student.age &&
    //            Objects.equals(name, student.name);
    //}
//    public boolean equals(Object obj){
//        //1.比较两个引用是否指向同一个对象
//        if (this == obj){
//            return true;
//        }
//        //2.判断obj是否为null
//        if (obj == null){
//            return false;
//        }
//        //3.判断两个引用指向的实际对象类型是否一致
//        //if (this.getClass() == obj.getClass()){
//        //
//        //}
//        if (obj instanceof Student){
//            //强制类型转换
//            Student s = (Student)obj;
//            //依次比较各个属性值是否相同
//            if (this.name.equals(s.getName()) && this.age == s.getAge()){
//                return true;
//            }
//        }
//
//        return false;
//    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj){
            return false;
        }
        if(obj == null){
            return false;
        }
        if(obj instanceof Student){
            Student s1 = (Student)obj;
            if(this.getName().equals(s1.getName())&&this.getAge() == (s1.getAge())){
                return true;
            }
        }
        return false;
    }


    //重写finalize()方法
    protected void finalize() throws Throwable{
        System.out.println(this.name+"对象被回收了");
    }
}
