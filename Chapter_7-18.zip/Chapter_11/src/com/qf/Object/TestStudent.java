package com.qf.Object;
/*
* Object类
*   超类，基类，所有类的直接或间接父类，位于继承树的最顶层
*   任何类，没有书写extends继承某个类，默认直接继承Object类，否则为间接继承
*   Object类中所定义的方法是所有对象都具备的方法
*   Object类型可以存储任何对象
*       作为参数，可接受任何对象
*       作为返回值，可返回任何对象
*
* 1.getClass()方法
*   public final Class<?> getClass(){}
*   返回引用中存储的实际对象类型
*   应用：判断两个引用中实际存储对象的类型是否一致
*
* 2.hashCode()方法
*   public int hashCode(){}
*   返回该对象十进制哈希码值
*   哈希算法根据对象的地址或字符串或数字计算出来的int类型的数值
*   哈希码并不唯一，尽量保证相同对象返回想要哈希码，不同对象返回不同哈希码
*
* 3.toString()方法
*   public String toString(){}
*   返回该对象的字符串表示
*   可根据程序需求覆盖该方法，如：展示对象的各个属性
*
* 4.equals()方法
*   public boolean equals(Object obj){}
*   默认实现为(this == obj)判断两个对象地址是否一直
*   可进行覆盖，比较两个对象内容是否相同
*
* 5.finalize()方法
*   当对象被判定为垃圾对象时,由JVM自动调用此方法,用以标记垃圾对象,进入回收队列
*   垃圾对象: 没有引用指向此对象,为垃圾对象
*   垃圾回收: 由 GC销毁垃圾对象,释放数据存储空间
*   自动回收机制: JVM内存耗尽,一次性回收所有垃圾对象
*   手动回收机制: 使用System.gc(),通知JVM执行垃圾回收
*
*
*
* */
public class TestStudent {
    public static void main(String[] args) {
        //1.getClass()方法
        System.out.println("----------1.getClass()----------");
        Student s1 = new Student("aaa",20);
        Student s2 = new Student("bbb",22);
        //判断s1和s2是不是同一个类型
        Class class1 = s1.getClass();
        Class class2 = s2.getClass();

        if(class1 == class2){
            System.out.println("s1和s2属于同一个类");
        }else{
            System.out.println("s1和s2不属于同一个类");
        }

        //2.hashCode()方法
        System.out.println("----------2.hashCode()----------");
        //s1和s2是两个不同的对象，存储地址不同，即hashCode不同
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        //将s1地址赋给s3,s3和s1地址相同，即hashCode也相同
        Student s3 = s1;
        System.out.println(s3.hashCode());

        //3.toString()方法
        System.out.println("----------3.toString()----------");
        System.out.println(s1.toString());
        System.out.println(s2.toString());

        //4.equals()方法
        System.out.println("----------4.equals()----------");
        System.out.println(s1.equals(s2));
        Student s4 = new Student("小明",17);
        Student s5 = new Student("小明",17);
        System.out.println(s4.equals(s5));
    }


}
