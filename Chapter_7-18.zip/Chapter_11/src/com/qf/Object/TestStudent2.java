package com.qf.Object;

public class TestStudent2 {
    public static void main(String[] args) {
        //有引用指向对象
        //Student s1 = new Student("aaa",20);
        //Student s2 = new Student("bbb",22);
        //Student s3 = new Student("ccc",23);
        //Student s4 = new Student("ddd",19);
        //Student s5 = new Student("eee",21);

        //没有引用指向对象
        new Student("aaa",20);
        new Student("bbb",22);
        new Student("ccc",23);
        new Student("ddd",19);
        new Student("eee",21);

        //回收垃圾
        System.gc();
        System.out.println("垃圾回收了");
    }
}
