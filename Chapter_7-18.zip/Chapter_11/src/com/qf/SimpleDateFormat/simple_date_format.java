package com.qf.SimpleDateFormat;
/*
* SimpleDateFormat类
*   以与语言环境有关的方式来格式化和解析日期的类
*   格式化日期 (日期 -> 文本)
*   解析文本 (文本 -> 日期)
*
*
*
* */
import java.text.SimpleDateFormat;
import java.util.Date;

public class simple_date_format {
    public static void main(String[] args) throws Exception{
        //1.创建SimpleDateFormat 对象 y 年 M 月 d 日 H 时 m 分钟 s 秒 S 毫秒
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        //2.创建Date对象
        Date date = new Date();
        //3.格式化日期 .format(); //(将日期转化为日期字符串)
        String str = sdf.format(date);
        System.out.println(str);

        //4.解析日期 。parse(); //将指定类型日期字符串转化成日期
        Date date2 = new Date();
        date2 = sdf.parse("1990年11月10日 01:01:01");
        System.out.println(date2.toLocaleString());
    }
}
