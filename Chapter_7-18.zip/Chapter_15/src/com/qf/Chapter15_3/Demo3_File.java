package com.qf.Chapter15_3;

import java.io.File;
import java.io.FileFilter;
import java.util.Date;

/**
 * @Description: File类
 * (1)分隔符
 * (2)文件操作
 * (3)文件夹操作
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo3_File {
    public static void main(String[] args) throws Exception{
//        separator();
//        fileOpen();
        directoryOpen();
    }
    //(1)分隔符
    public static void separator(){
        System.out.println("路径分隔符"+ File.pathSeparator);
        System.out.println("名称分隔符"+File.separator);
    }

    //(2)文件操作
    public static void fileOpen() throws Exception{
        //1创建文件对象，但是不一定有这个文件
        File file = new File("D:\\IDEA_Project\\file.txt");
        //判断
        while(!file.exists()){
            boolean b = file.createNewFile();
            System.out.println("文件创建结果："+b);
        }

        //2删除
        //2.1
//        Thread.sleep(3000);
//        System.out.println("文件删除结果"+file.delete());

        //2.2使用JVM退出时删除
//        file.deleteOnExit();

        //3.获取文件信息
        System.out.println("获取文件绝对路径："+file.getAbsolutePath());
        System.out.println("获取路径："+file.getPath());
        System.out.println("获取文件名称："+file.getName());
        System.out.println("获取父目录："+file.getParent());
        System.out.println("获取文件大小："+file.length());
        System.out.println("获取文件创建时间："+new Date(file.lastModified()).toLocaleString());

        //4.判断
        System.out.println("是否可写：" + file.canRead());
        System.out.println("是否是文件："+file.isFile());
        System.out.println("是否隐藏："+file.isHidden());
    }

    public static void directoryOpen() throws Exception{
        //1.创建文件夹
        File dir = new File("D:\\IDEA_Project\\aaa\\bbb\\ccc");
        if(!dir.exists()){
//            dir.mkdir();//创建单级目录
            System.out.println("创建文件夹结果："+dir.mkdirs());//创建多级目录
        }

        //2.删除文件夹
        //2.1直接删除
//        Thread.sleep(5000);
        System.out.println("删除结果："+dir.delete());
        //2.2JVM退出删除
//        dir.deleteOnExit();

        //3.获取文件夹信息
        System.out.println("获取文件夹绝对路径："+dir.getAbsolutePath());
        System.out.println("获取文件夹路径："+dir.getPath());
        System.out.println("获取文件夹父目录："+dir.getParent());
        System.out.println("获取文件夹名称："+dir.getName());
        System.out.println("获取文件夹时间："+new Date(dir.lastModified()).toLocaleString());

        //4.判断
        System.out.println("是否是文件夹:"+dir.isDirectory());
        System.out.println("是否隐藏:"+dir.isHidden());

        //5.遍历文件夹
        File dir2 = new File("d:\\IDEA_Project\\txt");
        String[] dirlist= dir2.list();
        System.out.println("------------文件遍历--------------");
        for (String str:dirlist){
            System.out.println(str);
        }
        
        //6.文件过滤
        System.out.println("--------------FileFilter接口的使用------------------");
        File[] files = dir2.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                if(file.getName().endsWith(".jpg")){
                    return true;
                }
                return false;
            }
        });

        for (File file:files){
            System.out.println(file.getName());
        }

    }
}
