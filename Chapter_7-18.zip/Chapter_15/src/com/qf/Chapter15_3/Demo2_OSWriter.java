package com.qf.Chapter15_3;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

/**
 * @Description: OutputStreamWriter写入文件，指定编码格式
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo2_OSWriter {
    public static void main(String[] args) throws Exception{
        //创建OutputStreamWriter
        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\info.txt");
        OutputStreamWriter osw = new OutputStreamWriter(fos,"utf-8");
        //写入数据
        for (int i = 0; i < 10; i++) {
            osw.write("Java是世界上最好的语言\r\n");
            osw.flush();
        }
        //关闭
        osw.close();
        System.out.println("执行完毕");
    }
}
