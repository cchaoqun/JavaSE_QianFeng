package com.qf.Chapter15_3;

import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * @Description: InputStreamReader读取文件，并指定编码方式
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo1_ISReader {
    public static void main(String[] args) throws Exception{
        //创建一个InputStreamReader
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\PrintWriter.txt");
        InputStreamReader isr = new InputStreamReader(fis,"utf-8");
        //读取文件
        int data = 0;
        while((data=isr.read()) != -1){
            System.out.print((char)data);
        }
        //关闭
        isr.close();
        System.out.println("执行完成");
    }
}
