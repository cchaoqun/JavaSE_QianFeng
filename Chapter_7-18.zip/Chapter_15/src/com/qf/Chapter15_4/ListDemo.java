package com.qf.Chapter15_4;

import java.io.File;

/**
 * @Description: 递归遍历和删除文件夹
 * 1.递归遍历文件夹
 * 2.递归删除文件夹
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class ListDemo {
    public static void main(String[] args) throws Exception{
//        listDir(new File("D:\\IDEA_Project\\myFiles"));
        deleteDir(new File("D:\\IDEA_Project\\myFiles"));
    }
    //1.递归遍历文件夹
    public static void listDir(File dir){

        File[] files = dir.listFiles();
        System.out.println(dir.getAbsolutePath());
        //判断文件或文件夹不为空
        if(files!=null&&files.length>0){
            //遍历每一个文件或文件夹
            for (File files2:files){
                if(files2.isDirectory()){
                    //如果时文件夹，调用本方法递归遍历
                    listDir(files2);
                }else{
                    System.out.println(files2.getAbsolutePath());
                }
            }
        }
    }
    //2.递归删除文件夹
    public static void deleteDir(File dir){
        File[] files = dir.listFiles();
        //判断不为空
        if(files!=null&&files.length>0){
            //遍历
            for (File files3:files){
                if(files3.isDirectory()){
                    deleteDir(files3);
                }else{
                    //删除文件
                    System.out.println(files3.getAbsolutePath()+"删除："+files3.delete());

                }
            }
        }
        System.out.println(dir.getAbsolutePath()+"删除："+dir.delete());
    }
}
