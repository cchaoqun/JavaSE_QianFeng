package com.qf.Chapter15_4;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

/**
 * @Description: Properties集合的使用
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class PropertiesDemo {
    public static void main(String[] args) throws Exception{
        //1.创建集合
        Properties properties = new Properties();
        //2.添加元素
        properties.setProperty("UserName","zhangsan");
        properties.setProperty("Age","20");
        System.out.println(properties.toString());
        //3.遍历元素
        //3.1 keySet()
        System.out.println("-------------3.1 keySet()-------------");
        Set<Object> key =  properties.keySet();
        for (Object keys: key){
            System.out.println((String)keys+"---"+properties.get(keys));
        }
        //3.2 entrySet()
        System.out.println("-------------3.2 entrySet()-------------");
        Set<Entry<Object, Object>> entryPro = properties.entrySet();
        for (Map.Entry<Object, Object> entries: properties.entrySet()){
            System.out.println(entries.toString());
        }
        //3.3 stringPropertyNames()
        System.out.println("--------------3.3 stringPropertyNames()---------------");
        Set<String> proNames = properties.stringPropertyNames();
        for (String proname:proNames){
            System.out.println(proname+"-----"+properties.getProperty(proname));
        }

        //4和流有关的方法
        //----------------list方法 将properties集合的属性打印到流中---------------------
        PrintWriter pw = new PrintWriter("D:\\IDEA_Project\\print.txt");
        properties.list(pw);
        pw.close();
        System.out.println("打印完毕");

        //----------------store方法 保存---------------------
//        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\store.properties");
//        properties.store(fos,"Comments");
//        fos.close();

        //----------------load方法 加载---------------------
        System.out.println("------------load----------------");
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\store.properties");
        Properties properties2 = new Properties();
        properties2.load(fis);
        System.out.println(properties2.toString());

    }
}
