package com.qf.Chapter15_2;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * @Description: 演示BufferedWriter的使用
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo6_BufferWriter {
    public static void main(String[] args) throws Exception{
        //1创建BufferedWriter
        FileWriter fw = new FileWriter("D:\\IDEA_Project\\buffer2.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        //2写入
        for (int i = 0; i < 10; i++) {
            bw.write("Java是世界上最好的语言");
            bw.newLine();// windows \r\n Linux \n
            bw.flush();
        }
        //3关闭
        bw.close();
        System.out.println("执行完毕");
    }
}
