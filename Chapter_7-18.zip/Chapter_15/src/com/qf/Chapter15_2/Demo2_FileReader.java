package com.qf.Chapter15_2;

import java.io.FileReader;

/**
 * @Description: 使用FileReader读取文件
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo2_FileReader {
    public static void main(String[] args) throws Exception{
        //创建FIleReader
        FileReader fr = new FileReader("D:\\IDEA_Project\\hello.txt");
        //2.1一次读取一个字符
//        int data = 0;
//        while((data=fr.read()) != -1){
//            System.out.print((char)data);
//        }
        //2.2一次读取多个字符
        //创建缓冲区
        char[] buf = new char[1024];
        int count = 0;
        while((count=fr.read(buf)) != -1){
            System.out.println(new String(buf, 0, count));
        }

        //3关闭
        fr.close();
    }
}
