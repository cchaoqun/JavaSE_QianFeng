package com.qf.Chapter15_2;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * @Description: 使用BufferReader读取数据
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo5_BufferReader {
    public static void main(String[] args) throws Exception{
        //1创建一个BufferedReader对象 需要一个文件字符输入流
        FileReader fr = new FileReader("D:\\IDEA_Project\\write.txt");
        BufferedReader br = new BufferedReader(fr);
        //2读取数据
        //2.1读取到缓冲区
//        char[] buf = new char[1024];
//        int count =0;
//        while((count=br.read(buf)) != -1){
//            System.out.println(new String(buf,0,count));
//        }
        //2.2 readline() 一次读取一行
        String line = null;
        while((line=br.readLine()) != null){
            System.out.println(line);
        }

        //3关闭
        br.close();
    }
}
