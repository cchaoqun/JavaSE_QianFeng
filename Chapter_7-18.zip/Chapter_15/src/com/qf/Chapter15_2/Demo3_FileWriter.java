package com.qf.Chapter15_2;

import java.io.FileWriter;

/**
 * @Description: 使用FileWriter写入文件
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo3_FileWriter {
    public static void main(String[] args) throws Exception{
        //创建一个FileWriter对象
        FileWriter fw = new FileWriter("D:\\IDEA_Project\\write.txt");
        //写入
        for (int i = 0; i < 10; i++) {
            fw.write("Java是世界上最好的语言\r\n");
            fw.flush();
        }
        //关闭
        fw.close();
        System.out.println("完成写入");
    }
}
