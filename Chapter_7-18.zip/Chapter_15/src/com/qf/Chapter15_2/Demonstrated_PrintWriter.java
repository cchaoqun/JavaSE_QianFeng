package com.qf.Chapter15_2;

import java.io.PrintWriter;

/**
 * @Description: 演示PrintWriter
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demonstrated_PrintWriter {
    public static void main(String[] args) throws Exception{
        //创建一个打印流
        PrintWriter pw = new PrintWriter("D:\\IDEA_Project\\PrintWriter.txt");
        //打印数据
        pw.println(97);
        pw.println(3.14);
        pw.println('a');
        pw.println("好好学习");
        pw.println(true);
        //关闭
        pw.close();
        System.out.println("执行完毕");

    }
}
