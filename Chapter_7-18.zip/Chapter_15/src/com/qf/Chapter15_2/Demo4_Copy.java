package com.qf.Chapter15_2;

import java.io.FileReader;
import java.io.FileWriter;

/**
 * @Description: 使用文件字符流完成文件复制，只支持文本文件，不支持图片或其他二进制文件
 * 因为不能复制没有字符编码的文件
 * 使用字节流复制所有文件
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo4_Copy {
    public static void main(String[] args) throws Exception{
        //创建FileReader 和 FileWriter
        FileReader fr = new FileReader("D:\\IDEA_Project\\Copy_for_FileReaderWriter.txt");
        FileWriter fw = new FileWriter("D:\\IDEA_Project\\Copy_for_FileReaderWriter1.txt");
//        FileReader fr = new FileReader("D:\\IDEA_Project\\Chaoqun cheng.jpg");
//        FileWriter fw = new FileWriter("D:\\IDEA_Project\\Chaoqun cheng3.jpg");

        //一边读一边写
        char[] buf = new char[1024];
        int count = 0;
        while((count=fr.read(buf)) != -1){
            fw.write(buf,0,count);
            fw.flush();
        }
        //关闭
        fw.close();
        fr.close();
        System.out.println("复制完成");
    }
}
