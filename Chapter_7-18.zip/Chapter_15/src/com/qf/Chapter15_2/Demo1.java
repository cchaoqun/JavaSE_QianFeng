package com.qf.Chapter15_2;

import java.io.FileInputStream;

/**
 * @Description: 演示字节流读取字符时乱码
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo1 {
    public static void main(String[] args) throws Exception{
        //创建FileInputStream
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\hello.txt");
        //读取文件
        int data = 0;
        while((data=fis.read()) != -1){
            System.out.println((char)data);//UTF-8 编码，一个中文三个字节，一个字节一个字节读取，会造成乱码
        }
        //关闭
        fis.close();
    }
}
