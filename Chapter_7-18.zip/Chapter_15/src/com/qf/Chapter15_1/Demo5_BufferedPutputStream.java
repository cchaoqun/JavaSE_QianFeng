package com.qf.Chapter15_1;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

/**
 * @Description: 使用字节缓冲流写入数据
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo5_BufferedPutputStream {
    public static void main(String[] args) throws Exception{
        //创建BufferedOutputStream
        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\buffered.txt");
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        //写入数据
        String str = "HelloWorld\r\n";
        for (int i = 0; i < 10; i++) {

            bos.write(str.getBytes());//这里仅将数据写入到8K缓冲区
            bos.flush();//调用flush，将数据刷新到硬盘

        }
        //关闭,调用close会在内部调用flush
        bos.close();

    }
}
