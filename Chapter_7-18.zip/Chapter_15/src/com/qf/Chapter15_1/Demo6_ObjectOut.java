package com.qf.Chapter15_1;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 * @Description: 使用对象流实现序列化
 * 要求：
 * (1)序列化类必须实现Serializable接口
 * (2)序列化类属性必须实现Serializable接口
 * (3)序列化版本号 SerialVersionID,保证了序列化和反序列化的时同一个类
 * (4)transient(瞬时的)修饰的属性不能被序列化
 * (5)静态(static)属性不能被序列化
 * (6)序列化多个属性可以借助集合(ArrayList)实现
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo6_ObjectOut {
    public static void main(String[] args) throws Exception{
        //创建对象流
        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\stu.bin");
        ObjectOutputStream oos = new ObjectOutputStream(fos);

        //创建学生类对象
        Student zhangsan = new Student(20,"张三");
        Student lisi = new Student(22, "李四");
        //使用集合写入多个对象
        ArrayList<Student> list = new ArrayList<>();
        list.add(zhangsan);
        list.add(lisi);
        //序列化(写入操作)
//        oos.writeObject(zhangsan);
        oos.writeObject(list);
        //关闭
        oos.close();
        System.out.println("序列化完成");
    }
}
