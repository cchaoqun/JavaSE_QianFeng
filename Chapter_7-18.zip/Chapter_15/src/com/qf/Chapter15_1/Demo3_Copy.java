package com.qf.Chapter15_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * @Description: 使用文件字节流实现文件的复制
 * 1.将存储设备中的文件读入内存中，
 * 2.将读入的文件再重新写进存储设备中
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo3_Copy {
    public static void main(String[] args) throws Exception{
        //创建文件流
        //1.文件字节输入流
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\Chaoqun Cheng.jpg");
        //2.文件字节输出流
        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\Chaoqun Cheng_1.jpg");
        //一边读入数据，一边写入数据
        //存放读入字节的数量
        int count = 0;
        //读取数据的缓冲区，一次读取1024个字节
        byte[] buf = new byte[1024];
        while((count=fis.read(buf)) != -1){
            fos.write(buf,0,count);
        }
        //关闭
        fis.close();
        fos.close();
        System.out.println("执行完毕");
////
//        int count= 0;
//        byte[] buf = new byte[1024];
//        while((count=fis.read(buf))!=-1){
//            fos.write(buf,0,count);
//        }
//        fis.close();
//        fos.close();
    }
}
