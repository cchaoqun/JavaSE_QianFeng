package com.qf.Chapter15_1;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

/**
 * @Description: 使用ObjectInputStream实现反序列化 (读取重构对象)
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo7_ObjectIn {
    public static void main(String[] args) throws Exception{
        //创建对象流
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\stu.bin");
        ObjectInputStream ois = new ObjectInputStream(fis);
        //实现反序列化(读取操作)
//        Student stu = (Student) ois.readObject();
        //一次读取多个对象
        ArrayList<Student> list2 = (ArrayList<Student>)ois.readObject();
        //关闭
        ois.close();
//        System.out.println(stu.toString());
        System.out.println(list2.toString());
        System.out.println("反序列化完成");
    }
}
