package com.qf.Chapter15_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * @Description: 字节输出流 FileOutputStream
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo2_FileOutputStream {
    public static void main(String[] args) throws Exception{
        //创建一个FileOutputStream
        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\SiqilovesCcq.txt",true);
        //输入字节
//        fos.write(97);
//        fos.write('b');
//        fos.write('c');

        //一次输入多个字节
        String str = "HelloWord";
        //getBytes() 获取字符串对应的字节类数组
        fos.write(str.getBytes());
        //关闭
        fos.close();

        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\SiqilovesCcq.txt");
        byte[] buf = new byte[1024];
        int count = 0;
        while((count=fis.read(buf)) != -1){
            System.out.println(new String(buf,0,count));
        }

        //执行完毕
        System.out.println("执行完毕");
        fis.close();
    }
}
