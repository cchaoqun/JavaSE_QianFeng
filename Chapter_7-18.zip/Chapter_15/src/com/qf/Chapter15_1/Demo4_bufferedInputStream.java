package com.qf.Chapter15_1;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

/**
 * @Description: 字节缓冲流读入数据
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo4_bufferedInputStream {
    public static void main(String[] args) throws Exception{
        //创建BufferedInputStrea,
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\SiqilovesCcq.txt");
        BufferedInputStream bis = new BufferedInputStream(fis);
        //读入数据
//        int data=0;
//        while((data=bis.read()) != -1){
//            System.out.print((char)data);
//        }

        //自己创建一个缓冲区，bis内部已经创建一个8Kb的缓冲区，调用read()方法时已经读入了8Kb的数据进入内置的缓冲区
        byte[] buf = new byte[1024];
        int count = 0;
        while((count=bis.read(buf)) != -1){
            System.out.println(new String(buf,0,count));
        }

        //关闭缓冲区会同时关闭输入流
        bis.close();
    }
}
