package com.qf.Chapter15_1;

import java.io.FileInputStream;

/**
 * @Description: 文件字节输入流 FileInputStream
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class Demo1_FileInputSteam {
    public static void main(String[] args) throws Exception{
        //创建一个FileInputStream，并指定文件路径
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\CcqlovesSiqi.txt");
        //1.读取文件,一次读取一个字节 fis.read()返回值为读取的字节数量，若到达末尾则返回-1
//        int data = 0;
//        while((data=fis.read()) != -1){
//            System.out.println((char)data);
//        }

        //2.一次读取多个字节
        //创建一个字节类型的数组存储读入的字节信息
        byte [] buf = new byte[3];
        int count = 0;
        while((count=fis.read(buf)) != -1){
            System.out.println(count);
            System.out.println(new String(buf,0,count));
        }

        //关闭流
        fis.close();
    }
}
