package com.qf.inheritance_2;
/*
* 猫类(和Animal非同包子类）
*
* */
import com.qf.inheritance_1.Animal;

public class Cat extends Animal {

    String hobby;

    public void PlayBall(){
        System.out.println(this.hobby);
    }
}
