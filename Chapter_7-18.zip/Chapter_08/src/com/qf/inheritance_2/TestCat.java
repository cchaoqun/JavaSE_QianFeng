package com.qf.inheritance_2;
/*
* 非同包非子类 protected不可用
*
* */
public class TestCat {
    public static void main(String[] args) {
        Cat bosimao = new Cat();
        bosimao.hobby = "波斯猫";// protected age 受保护的成员

    }
}
