package com.qf.inheritance_3;
/*super.关键字
* super访问方法
    * super关键字可在子类中访问父类的方法
    * 使用"super."的形式访问父类的方法，进行完成在子类中的复用；
    * 再叠加额外的功能代码，组成新的功能
*super访问属性
* 父子类的同名属性不存在重写关系，两块空间同时存在(子类遮蔽父类属性)需要使用不同前缀进行访问
*
* */
public class Son extends Father{//Son类 继承 Father类

    int value = 20;
    @Override
    public void show(){
        super.show();//调用Father类的show()方法
        System.out.println("Son类的show方法");
    }
    public void  superTest(){
        int value = 30;
        System.out.println(value + " -> superTest");//局部变量
        System.out.println(this.value + " -> Son");//本类的实例变量
        System.out.println(super.value + " -> Father");//父类的实例变量
    }
}
