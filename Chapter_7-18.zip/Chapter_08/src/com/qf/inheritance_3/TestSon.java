package com.qf.inheritance_3;

public class TestSon {
    public static void main(String[] args) {
        Son son = new Son();
//        son.show();
        son.superTest();

        son.show();
    }
}
