package com.qf.inheritance_3;
/*
* 父类
*
* */
public class Father {
    int value = 10;
    public void show(){
        System.out.println("Father类的show方法");
    }
}
