package com.qf.inheritance_1;
/*
* 鸟类
*
* */
public class Bird extends Animal{//extends Animal 继承父类中所有的属性和方法

    //毛色
    String furColor;

    //飞
    public void fly(){
        System.out.println("飞...");
    }
}
