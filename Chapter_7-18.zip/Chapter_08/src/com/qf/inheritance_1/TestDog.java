package com.qf.inheritance_1;

public class TestDog {
    public static void main(String[] args) {
        Dog wangcai = new Dog();
        wangcai.breed = "萨摩";
        wangcai.age = 10;
        wangcai.sex = "公";
        wangcai.furColor = "白色";

        wangcai.eat();
        wangcai.sleep();
        wangcai.run();
    }
}
