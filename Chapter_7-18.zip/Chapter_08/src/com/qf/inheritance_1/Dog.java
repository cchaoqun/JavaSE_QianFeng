package com.qf.inheritance_1;
/*
* 狗类
*
* */
public class Dog extends Animal{//extends Animal 继承父类中所有的属性和方法

    //毛色
    String furColor;

//    //方法重写
//    public void eat(){
//        System.out.println("狗狗吃狗粮...");
//    }

    // Ctrl + o 方法重写的快捷添加
    @Override //验证方法重写是否遵循规则：访问修饰符，返回值类型，名称与父类相同
    public void eat() {
        System.out.println("狗狗吃狗粮...");
    }

    //跑
    public void run(){
        System.out.println("跑...");
    }
}
