package com.qf.inheritance_1;

public class Snake extends Animal{//extends Animal 继承父类中所有的属性和方法
    //爬
    public void crawl(){
        System.out.println("爬...");

    }
}
