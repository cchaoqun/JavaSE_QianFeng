package com.qf.inheritance_1;
/*
* 鱼类
*
* */
public class Fish extends Animal{//extends Animal 继承父类中所有的属性和方法
    //游
    public void swim(){
        System.out.println("游...");
    }
}
