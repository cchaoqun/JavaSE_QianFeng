package com.qf.inheritance_4;

public class B extends A{
    int num3;

    public void m2(){
        System.out.println("B类中的m2方法");
    }

    public B(){
        super();//调用父类的无参构造方法。默认添加
        System.out.println("B类的默认构造方法");
    }

    public B(int num1, int num2, int num3){
        //super();//调用父类的无参构造方法。默认添加
        super(num1, num2);//调用父类的带参构造方法
        this.num3 = num3;
        //this();
        System.out.println("B类的带参构造方法");
    }
}
