package com.qf.inheritance_4;

public class A {
    int num1;
    int num2;

    public void m1(){
        System.out.println("A类中的m1方法");
    }

    public A(){
        System.out.println("A类的默认构造方法");
    }

    public A(int num1, int num2){
        this.num1 = num1;
        this.num2 = num2;
        System.out.println("A类的带参构造方法");
    }
}
