package com.qf.inheritance_4;
/*继承者的对象创建
*在具有继承关系的对象创建中，构建子类对象会先构建其父类对象
*由父类的共性内容，叠加子类的独有内容，组合成完整的子类对象
*
* super():
*   表示调用父类的无参构造方法。如果没有显示书写，则隐存在于子类构造方法的首行
* super(实参)：
*   表示调用父类的带参构造方法。
*
* this()和super()的区别
*   this和super使用在构造方法中，都要求出现在构造方法的首行，
*   当子类构造中使用了 this() 或 this(实参)，即不可再同时书写super()和super(实参)
*   会由this()指向的构造方法完成super()的调用
*
* super()关键字的第一种用法
*   在子类的方法中使用 "super."的形式访问父类的属性和方法
*   例如：super.属性 super.父类方法()
* super()关键字的第二种用法
*   在子类构造方法的首行通过 super() 或 super(实参)调用父类的构造方法
* 注意：
*   如果子类构造方法没有显示super()或super(实参)，默认提供super()
*   在同一子类的构造方法中，super()和this()不可同时存在
*
*
* */

public class TestB {
    public static void main(String[] args) {
        B b = new B(100,200,300);

        b.m1();
        b.m2();
    }
}
