package com.qf.encap_1;

public class TestStudent {
    public static void main(String[] args) {

        Student s1 = new Student();
//        s1.name = "小张"; //私有属性在类的外部不可访问 (如何提供正常对外访问渠道的同时，又可以控制录入数据的有效性？)
        s1.setName("小张");
//        s1.age = 10000; //在对象的外部为对象属性赋值，可能存在非法数据的录入
        s1.setAge(10000);
//        s1.sex = "妖";
        s1.setSex("女");
//        s1.score = 100;
        s1.setScore(90);
        s1.sayHi();
    }
}
