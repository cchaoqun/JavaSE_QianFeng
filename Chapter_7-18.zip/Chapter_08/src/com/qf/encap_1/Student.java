package com.qf.encap_1;

public class Student {

    private String name;
    private int age;
    private String sex;
    private int score;

    public void sayHi() {
        System.out.println("大家好，我是" + name);
        System.out.println("年龄：" + age);
        System.out.println("性别：" + sex);
        System.out.println("成绩：" + score);
    }

    /*
     * 公共访问方法
     *   以访问方法的形式，进而完成赋值和取值的操作
     * 命名规范
     *   赋值：setXXX();//使用方法参数实现赋值
     *   取值：getXXX();//使用方法返回值实现取值
     * 在公共的访问方法内部，添加逻辑判断，进而过滤掉非法数据，以保证数据安全
     *
     * 总结
     *   外界不可直接访问private属性
     *   通过访问公共方法的方式对属性进行赋值取值操作
     *   get/set方法是外界访问对象私有属性的唯一通道，方法内部可对数据进行检测和过滤
     *
     * */

    //通过class内部的setter getter方法来为属性赋值，同时可以判断输入数据是否合理
    //alt + insert

    public void setAge(int age) {
        if (age > 0 && age <= 120) {
            this.age = age;
        } else {
            this.age = 18;
        }
    }

    public int getAge() {
        return this.age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        if (sex == "男" || sex == "女") {
            this.sex = sex;
        } else {
            this.sex = "sex不在范围内";
        }

    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        if (score >= 0 && score <= 100) {
            this.score = score;
        } else {
            this.score = 0;
        }

    }
}
