package com.qf.poly_1;

/*
* 多态应用
* 场景一
*   使用父类作为方法形参，使方法参数的类型更为广泛
*
*
*
*
* */

public class TestMaster {
    public static void main(String[] args) {
        //创建Master类型对象
        Master master = new Master();
        //创建 Dog Bird类对象
        Dog dog = new Dog();
        Bird bird = new Bird();
        //调用feed()方法
        //将dog bird子类对象赋给父类Animal变量，dog 和 bird中重写了eat()方法，遵循覆盖原则，执行 Dog Bird类中eat()方法
        master.feed(dog);
        master.feed(bird);

    }
}
