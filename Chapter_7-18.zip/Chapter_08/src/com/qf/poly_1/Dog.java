package com.qf.poly_1;

public class Dog extends Animal{
    //毛色
    String furColor;

    //跑
    public void run(){
        System.out.println("跑...");
    }

    //方法重写
    @Override
    public void eat(){
        System.out.println("狗狗大口吃狗粮...");
    }
}
