package com.qf.poly_1;
/*
* 主人类
*   将父类作为方法形参实现多态，使方法参数的类型更为广泛
*
* */

public class Master {

    //主人名称
    String name;

    /*
    * 喂狗
    *
    * */
//    public void feed(Dog dog){
//        System.out.println("主人喂食");
//        dog.eat();
//    }

    /*
    * 喂鸟
    *
    * */
//    public void feed(Bird bird){
//        System.out.println("主人喂食");
//        bird.eat();
//    }

    public void feed(Animal animal){
        System.out.println("主人喂食");
        animal.eat();//调用Animal类中的eat()方法
    }

    //购买动物
    public Animal buy(int type){
        Animal animal = null;
        if (type == 1){
            animal = new Dog();
        }else if (type == 2){
            animal = new Bird();
        }
        return animal;
    }
}
