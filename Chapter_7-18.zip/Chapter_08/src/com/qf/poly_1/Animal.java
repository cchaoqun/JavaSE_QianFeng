package com.qf.poly_1;
/*
* 动物类(父类)
*
* */

/*继承
* 语法： class 子类 extends 父类 {} //定义子类时，显示继承父类
* 应用：产生继承关系后，子类可以使用父类的属性和方法，也可以定义子类独有的属性和方法
* 好处：提高代码复用性，又可以提高代码的可扩展性
*
* 特点：java为单继承，一个子类只能有一个直接父类，但是可以多级继承，属性和方法逐级叠加
*
* 不可继承：
*   1.构造方法：类中构造方法只负责创建本类对象，不可继承
*   2.private修饰的属性和方法：访问修饰符的一种，仅本类可见
*   3.父子类不在同一package中，default修饰的属性和方法：访问修饰符的一种，仅同包可见
*
* 访问修饰符：
*   private < default < protected < public (从严到宽)
*
* 方法的覆盖 (Override)
*   子类中是否可以定义与父类相同的方法？
*   为何需要？
*   父类提供的方法无法满足子类需求时，可以在子类中定义与父类相同的方法进行覆盖(Override)
* 方法覆盖的原则
*   方法名称，参数列表，返回值类型必须与父类相同，
*   访问修饰符不能比父类更严格
* 方法覆盖的执行
*   子类覆盖父类后，调用时优先执行子类覆盖的方法
* */

public class Animal {
    //品种
    String breed;
    //年龄
    int age;
    //性别
    String sex;//不写修饰符 为default, 但无需加上 default，不写即可

    //吃
    public void eat(){
        System.out.println("吃...");
    }
    //睡
    public void sleep() {
        System.out.println("睡...");
    }
}
