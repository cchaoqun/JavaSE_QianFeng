package com.qf.poly_1;
/*
* 多态
* 应用场景2
*   使用父类作为方法返回值实现多态，使方法可以返回不同子类对象
* instanceof 关键字
*   向下转型前，应判断引用中的对象真实类型，以确保类型转换的正确性
*   语法 引用 instanceof 类型 //返回boolean类型结果
*
* */
import java.util.Scanner;

public class TestMaster2 {
    public static void main(String[] args) {
        System.out.println("==========欢迎来到动物市场==========");
        System.out.println("==========1.狗狗 2.鸟儿==========");
        System.out.println("请选择");

        Master master = new Master();
        Scanner input = new Scanner(System.in);
        int choice = input.nextInt();
        Animal animal = master.buy(choice);
        //Master类型 buy()方法返回值为Animal类型多态 并赋予animal变量
        //判断是否购买成功
        if (animal != null){
            System.out.println("购买成功");
            //判断引用中对象真实类型，并进行向下转型
            if (animal instanceof Dog){//animal中的对象为Dog类型
                //向下转型
                Dog dog = (Dog)animal;
                //转型后调用子类方法
                dog.run();
            }else if(animal instanceof Bird){//animal中的对象为Bird类型
                //向下转型
                Bird bird = (Bird)animal;
                //转型后调用子类方法
                bird.fly();
            }
        }else{
            System.out.println("购买失败");
        }

    }
}
