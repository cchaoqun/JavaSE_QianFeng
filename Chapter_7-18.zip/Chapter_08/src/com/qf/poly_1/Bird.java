package com.qf.poly_1;

public class Bird extends Animal{
    //毛色
    String furColor;

    //飞
    public void fly(){
        System.out.println("鸟儿飞...");
    }

    //方法重写
    @Override//ctrl + o 方法重写快捷键
    public void eat() {
//        super.eat();//默认调用父类的eat方法
        System.out.println("鸟儿找东西吃");
    }
}
