package com.qf.encap_2;
/*
* 用户类
*
*
*
* */

public class User {
    //卡号
    private String cardNo;
    //身份证号
    private String identify;
    //用户名
    private String username;
    //密码
    private String password;
    //电话号码
    private String phone;
    //余额
    private double balance;

    //默认构造方法
    public User(){

    }

    //带参构造方法，右键->generate->constructor->select all
    public User(String cardNo, String identify, String username, String password, String phone, double balance) {
        this.cardNo = cardNo;
        this.identify = identify;
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.balance = balance;
    }

    //get/set  右键->generate->get and set

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getIdentify() {
        return identify;
    }

    public void setIdentify(String identify) {
        this.identify = identify;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
