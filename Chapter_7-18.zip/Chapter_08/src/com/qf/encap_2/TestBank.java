package com.qf.encap_2;

public class TestBank {
    public static void main(String[] args) {
        Bank bank = new Bank();
        //bank.initial();
        bank.login();
    }

}
