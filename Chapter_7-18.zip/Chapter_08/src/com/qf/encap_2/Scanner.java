package com.qf.encap_2;

import java.io.InputStream;

public class Scanner {
    public Scanner(InputStream in) {
    }
}
