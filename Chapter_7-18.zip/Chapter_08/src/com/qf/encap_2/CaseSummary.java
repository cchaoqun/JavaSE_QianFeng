package com.qf.encap_2;

public class CaseSummary {

    /*
     * 实现银行功能
     *   用户输入正确银行卡号和密码后可执行以下操作
     *   菜单如下：1.存款 2.取款 3.转账 4.查询余额 5.修改密码 6.退出
     *
     * 分析
     *   User类(cardNo identity username password phone balance)
     *   Bank类主要包含以下功能
     *      初始化用户(initial)
     *      用户登录(login)
     *      显示菜单(showMenu)
     *      存款(save) 取款(withDraw) 转账(trans) 查询余额(query) 修改密码(modifyPassword)
     *
     *
     *
     *
     *
     * */
}
