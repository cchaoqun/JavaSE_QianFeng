package com.qf.encap_2;

/*
* 银行类
*
* */

import java.util.Scanner;

public class Bank {
    //创建用户数组
    private User[] users = new User[5];
    //给定初始大小
    private int size;

    //1初始化用户-----------------------
    public void initial() {
        //创建用户1
        User user1 = new User();
        user1.setCardNo("622275489620114");
        user1.setIdentify("342923199606110031");
        user1.setUsername("曹操");
        user1.setPassword("123456");
        user1.setPhone("15216798873");
        user1.setBalance(10000);

        //创建用户2
        User user2 = new User("622255568894115", "3429231996262022", "吕布", "1234567", "15264849952", 20000);

        users[0] = user1;
        users[1] = user2;
        size = 2;

        System.out.println("用户初始化完成...");

    }

    public Bank() {
        initial();
    }

    //2登录------------------------
    public void login() {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入卡号");
        String cardNo = input.next();
        System.out.println("请输入密码");
        String password = input.next();

        //新建一个User类对象用来存储数组找到的匹配的账号
        User u = null;
        //判断账号密码是否匹配，遍历User数组
        for (int i = 0; i < size; i++) {
            if (users[i].getCardNo().equals(cardNo) && users[i].getPassword().equals(password)) {
                u = users[i];
                break;
            }
        }
        if (u != null) {
            //成功
            //显示菜单
            showMenu(u);
        } else {
            System.out.println("账号密码错误...");
        }

    }

    //3显示菜单===================================
    public void showMenu(User u) {
        //根据用户输入数字确定执行程序
        Scanner input = new Scanner(System.in);
        System.out.println("====欢迎来到中国银行系统====当前用户：" + u.getCardNo() + "====");
        do {
            System.out.println("====1.存款 2.取款 3.转账 4.查询余额 5.修改密码 0.退出====");
            int choice = input.nextInt();
            switch (choice) {
                case 1:
                    this.save(u);
                    break;
                case 2:
                    this.withDraw(u);
                    break;
                case 3:
                    this.trans(u);
                    break;
                case 4:
                    this.query(u);
                    break;
                case 5:
                    this.modify(u);
                    break;
                case 0:

                    return;//结束该showMenu方法
                default:

                    break;
            }
        } while (true);

    }

    //4存钱===================================
    public void save(User u) {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入存钱金额：");
        double m = input.nextDouble();
        if (m > 0) {
            u.setBalance(u.getBalance() + m);
            System.out.println("存钱成功，余额为：" + u.getBalance());
        } else {
            System.out.println("存钱失败，请重新输入金额：...");
        }
    }

    //5取钱===================================
    public void withDraw(User u) {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入取钱金额：");
        double m = input.nextDouble();
        if (m > 0) {
            if (u.getBalance() >= m) {
                u.setBalance(u.getBalance() - m);
                System.out.println("取钱成功，余额为：" + u.getBalance());
            } else {
                System.out.println("余额不足");
            }
        } else {
            System.out.println("取钱失败，请重新输入金额：...");
        }
    }

    //6转账===================================
    public void trans(User u) {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入转账账号：");
        String cardNo = input.next();
        System.out.println("请输入转账金额：");
        double m = input.nextDouble();

        //判断转账用户是否存在
        User toUser = null;
        for (int i = 0; i < size; i++) {
            //判断用户
            if (users[i].getCardNo().equals(cardNo)) {
                toUser = users[i];
                break;
            }
        }
        if (toUser != null) {//存在对方账号
            //判断余额是否足够
            if (u.getBalance() >= m) {
                //扣钱
                u.setBalance(u.getBalance() - m);
                //加钱
                toUser.setBalance(toUser.getBalance() + m);
                System.out.println("转账成功，当前余额：" + u.getBalance());
            } else {
                System.out.println("转账失败，当前余额不足");
            }
        } else {
            System.out.println("对方卡号不存在，请重新输入转账卡号");
        }

    }

    //7查询余额===================================
    public void query(User u){
        System.out.println("当前卡号：" + u.getCardNo());
        System.out.println("当前用户：" + u.getIdentify());
        System.out.println("当前余额为：" + u.getBalance());
    }

    //8修改密码===================================
    public void modify(User u){
        Scanner input = new Scanner(System.in);
        System.out.println("请输入新密码：");
        String newpassword = input.next();
        if (newpassword.length() == 6){
            u.setPassword(newpassword);
            System.out.println("密码修改成功！");
        }else{
            System.out.println("密码不符合要求，请重新输入新密码...");
        }

    }

}
