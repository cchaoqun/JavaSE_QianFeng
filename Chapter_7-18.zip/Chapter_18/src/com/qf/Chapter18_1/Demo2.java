package com.qf.Chapter18_1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * @Description: 常用的函数式接口
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Demo2 {
    public static void main(String[] args) {
        //------------------Consumer 消费型接口---------------------
        System.out.println("------------------Consumer 消费型接口---------------------");
        //匿名内部类
//        Consumer<Double> consumer = new Consumer<>(){
//            @Override
//            public void accept(Double money) {
//                System.out.println("聚餐消费："+money);
//            }
//        };
        //Lambda
        Consumer<Double> consumer = money -> System.out.println("唱歌消费："+money);
        happy(consumer,1000d);
        //Lambda
        happy(money -> System.out.println("健身消费："+money),2000d);

        //------------------Supplier 供给型接口---------------------
        System.out.println("------------------Supplier 供给型接口---------------------");
        //匿名内部类
        Supplier<Integer> supplier = new Supplier<>(){
            @Override
            public Integer get() {
                return new Random().nextInt(100);
            }
        };


        int[] arrays = getNums(supplier,5);
        //Lambda
        int[] arrays2 = getNums(() ->new Random().nextInt(1000),10);

        System.out.println(Arrays.toString(arrays));
        System.out.println(Arrays.toString(arrays2));

        //------------------Function 函数型接口---------------------
        System.out.println("------------------Function 函数型接口---------------------");
        //匿名内部类
        Function<String,String> function = new Function<>(){
            @Override
            public String apply(String str) {
                return str.toUpperCase();
            }
        };

        String result = stringHandler(function,"hello");
        //Lambda
        String result2 = stringHandler(str->str.trim(),"  zhangsan      ");
        System.out.println(result);
        System.out.println(result2);

        //------------------Predicate 断言型接口---------------------
        System.out.println("------------------Predicate 断言型接口---------------------");
        List<String> list = new ArrayList<>();
        list.add("zhangsan");
        list.add("zhangwuji");
        list.add("lisi");
        list.add("wangwu");
        list.add("zhaoliu");
        //匿名内部类
        Predicate<String> predicate = new Predicate<String>() {
            @Override
            public boolean test(String s) {
                return s.startsWith("zhang");

            }
        };
        List<String> namesList = filterNames(predicate,list);
        //Lambda
        List<String> namesList2 = filterNames(s->s.length()>5,list);
        System.out.println(namesList.toString());
        System.out.println(namesList2.toString());

    }

    //Consumer 消费型接口
    public static void happy(Consumer<Double> consumer, Double money){
        consumer.accept(money);
    }

    //Supplier 供给型接口
    public static int[] getNums(Supplier<Integer> supplier,int count){
        int[] nums = new int[count];
        for (int i = 0; i < count; i++) {
            nums[i] = supplier.get();
        }
        return nums;
    }

    //Function 函数型接口
    public static String stringHandler(Function<String,String> function,String str){
        return function.apply(str);
    }

    //Predicate 断言型接口
    public static List<String> filterNames(Predicate<String> predicate, List<String> list){
        List<String> list2 = new ArrayList<>();
        for (String str:list){
            //如果参数集合元素符合要求，将该元素添加到集合
            if(predicate.test(str)){
                list2.add(str);
            }
        }
        return list2;
    }
}
