package com.qf.Chapter18_1;

import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @Description: 方法引用
 * (1)对象::实例方法
 * (2)类::静态方法
 * (3)类::实例方法
 * (4)类::new
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class MethodInvoke {
    public static void main(String[] args) {
        //(1)对象::实例方法
        System.out.println("---------------(1)对象::实例方法---------------");
        //lambda表达式只调用了一个方法，且这个方法的特点(参数，返回值类型)与接口的特点相同，可以使用方法引用
        //匿名内部类
        Consumer<String> consumer = new Consumer<>(){
            @Override
            public void accept(String s) {
                System.out.println(s);
            }
        };
        consumer.accept("Hello");
        //lambda
        Consumer<String> consumer2 = s-> System.out.println(s);
        consumer2.accept("World");
        //方法引用 对象::实例方法
        Consumer<String> consumer3 = System.out::println;
        consumer3.accept("Hi");

        //(2)类::静态方法
        System.out.println("---------------(2)类::静态方法---------------");
        //匿名内部类
        Comparator<Integer> comparator = new Comparator<>(){

            @Override
            public int compare(Integer o1, Integer o2) {
//                return (o1<o2)? -1 : (o1==o2 ? 0 : 1 );
                return Integer.compare(o1,o2);
            }
        };
        int result = comparator.compare(1,2);
        //lambda
        Comparator<Integer> comparator2 = (o1,o2)->Integer.compare(o1,o2);
        int result2 = comparator2.compare(5,2);
        //方法引用
        Comparator<Integer> comparator3 = Integer::compare;
        int result3 = comparator2.compare(5,5);

        System.out.println(result);
        System.out.println(result2);
        System.out.println(result3);


        //(3)类::实例方法
        System.out.println("---------------(3)类::实例方法---------------");
        //匿名内部类
        Function<Employee,String> function = new Function<Employee, String>() {
            @Override
            public String apply(Employee e) {
                return e.getName();
            }
        };
        //lambda
        Function<Employee,String> function2 = e -> e.getName();
        //方法引用
        Function<Employee,String> function3 = Employee::getName;

        String eName = function.apply(new Employee("小华",60000));
        String eName2 = function2.apply(new Employee("小明",50000));
        String eName3 = function3.apply(new Employee("小丽",70000));
        System.out.println(eName);
        System.out.println(eName2);
        System.out.println(eName3);

        //(4)类::new
        System.out.println("---------------(4)类::new---------------");
        //匿名内部类
        Supplier<Employee> supplier = new Supplier<Employee>() {
            @Override
            public Employee get() {
                return new Employee();
            }
        };
        //lambda
        Supplier<Employee> supplier2 = () -> new Employee();
        //方法引用
        Supplier<Employee> supplier3 = Employee::new;
        Employee e1 = supplier.get();
        Employee e2 = supplier2.get();
        Employee e3 = supplier3.get();
        System.out.println(e1.toString());
        System.out.println(e2.toString());
        System.out.println(e3.toString());



    }

}
