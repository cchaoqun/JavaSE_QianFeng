package com.qf.Chapter18_1;

import java.util.Comparator;
import java.util.TreeSet;

/**
 * @Description:  
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Lambda {
    public static void main(String[] args) {
        //匿名内部类
        Runnable runnable1 = new Runnable() {
            @Override
            public void run() {
                System.out.println("子线程运行了1...");
            }
        };
        //lambda
        Runnable runnable2 = () ->  System.out.println("子线程运行了2...");

        new Thread(runnable1).start();
        new Thread(runnable2).start();
        new Thread(() -> System.out.println("子线程运行了3...")).start();

        //匿名内部类
        Comparator<String> com = new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return s1.length()-s2.length();
            }
        };
        //lambda
        Comparator<String> com2 = (String s1, String s2) -> {

            return s1.length()-s2.length();
        };

        Comparator<String> com3 = (s1,s2) -> s1.length()-s2.length();

        TreeSet<String> tree = new TreeSet<>(com);
        TreeSet<String> tree2 = new TreeSet<>(com2);
        TreeSet<String> tree3 = new TreeSet<>(com3);
    }
}
