package com.qf.Chapter18_1;
/**
 * @Description:
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Demo1 {
    public static void main(String[] args) {
        //匿名内部类
        Usb mouse = new Usb(){
            @Override
            public void Service() {
                System.out.println("鼠标开始工作...");
            }
        };

        run(mouse);
        //Lambda
        Usb fan = () -> System.out.println("风扇开始工作...");
        run(fan);
    }


    public static void run(Usb usb){
        usb.Service();
    }
}
