package com.qf.Chapter18_1;
/**
 * @Description: 函数式接口
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
@FunctionalInterface
public interface Usb {
    void Service();
}
