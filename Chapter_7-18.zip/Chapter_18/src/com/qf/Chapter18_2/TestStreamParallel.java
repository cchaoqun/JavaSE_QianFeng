package com.qf.Chapter18_2;

import java.util.ArrayList;
import java.util.Random;

/**
 * @Description: 验证 Stream parallelStream的效率
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class TestStreamParallel {
    public static void main(String[] args) {
        //串行流和并行流的区别
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5000000; i++) {
            list.add(new Random().nextInt(20000000));
        }
        //串行流对5000000字符串的集合进行排序和计数
        long start = System.currentTimeMillis();
        long count = list.parallelStream().sorted().count();
        System.out.println(count);
        long end = System.currentTimeMillis();
        System.out.println("总用时："+(end-start));

        //串行流对5000000字符串的集合进行排序和计数
//        long start2 = System.currentTimeMillis();
//        long count2 = list.parallelStream().sorted().count();
//        System.out.println(count2);
//        long end2 = System.currentTimeMillis();
//        System.out.println("并行流总用时："+(end-start));
    }


}
