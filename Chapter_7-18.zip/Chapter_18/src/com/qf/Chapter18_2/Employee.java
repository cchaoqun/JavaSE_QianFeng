package com.qf.Chapter18_2;

import java.util.Objects;

/**
 * @Description: 雇员类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Employee {
    private String name;
    private int money;

    public Employee() {
    }

    public Employee(String name, int money) {
        this.name = name;
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", money=" + money +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return money == employee.money &&
                name.equals(employee.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, money);
    }
}
