package com.qf.Chapter18_2;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description: Stream 终止操作的使用方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class FinalStream {
    public static void main(String[] args) {
        ArrayList<Employee> list = new ArrayList<>();
        list.add(new Employee("小王",12000));
        list.add(new Employee("小明",20000));
        list.add(new Employee("小成",16000));
        list.add(new Employee("小李",24000));
        list.add(new Employee("小路",30000));
        list.add(new Employee("小路",30000));

        //终止操作 forEach
        System.out.println("------forEach-----");
        list.stream()
                .filter(e->{
                    System.out.println("过滤了....");
                    return e.getMoney()>20000;
                })
                .forEach(System.out::println);
        //终止操作 min max count
        System.out.println("------min-----");
        Optional<Employee> minlist = list.stream()
                .min(new Comparator<Employee>() {
                    @Override
                    public int compare(Employee e1, Employee e2) {
                        return Double.compare(e1.getMoney(),e2.getMoney());
                    }
                });
//                .min((e1,e2)->Double.compare(e1.getMoney(),e2.getMoney()));
        System.out.println(minlist.toString());

        System.out.println("------max-----");
        Optional<Employee> maxlist = list.stream()
                .max((e1,e2)->Double.compare(e1.getMoney(),e2.getMoney()));
        System.out.println(maxlist.toString());

        System.out.println("------count-----");
        long count = list.stream().count();
        System.out.println("员工个数:"+count);

        //终止操作 reduce 规约
        //计算所有员工工资总和
        System.out.println("------终止操作 reduce 规约-----");
        Optional<Integer> sum =  list.stream()
                .map(e->e.getMoney())
                .reduce((x,y)->(x+y));
        System.out.println("员工工资总和:"+sum.get());

        //终止操作 collect
        //获取所有员工的姓名，封装成一个list集合
        System.out.println("------终止操作 collect------");
        List<String> namesList = list.stream()
                .map(e->e.getName())
                .collect(Collectors.toList());
        Iterator<String> it = namesList.iterator();
        while(it.hasNext()){
            System.out.println((String)it.next());
        }




    }
}
