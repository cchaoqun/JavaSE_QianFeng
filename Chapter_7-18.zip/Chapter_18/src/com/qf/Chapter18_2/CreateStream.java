package com.qf.Chapter18_2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @Description: Stream的创建
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class CreateStream {
    public static void main(String[] args) {
        //1.通过Collection中的Stream()和parallelStream()
        System.out.println("----1.通过Collection中的Stream()和parallelStream()-----");
        ArrayList<String> list = new ArrayList<>();
        list.add("小明");
        list.add("小王");
        list.add("小程");
        //1.1创建Stream
        Stream stream = list.stream();
        //多线程
        Stream stream2 = list.parallelStream();
        Stream stream3 = list.stream();
        //1,2遍历
        //1.2.1 匿名内部类
        System.out.println("--------1.2.1 匿名内部类----------");
        stream.forEach(new Consumer<String>(){
            @Override
            public void accept(String s) {
                System.out.println(s);
            }
        });
        //1.2.2 lambda
        System.out.println("--------1.2.2 lambda----------");
        stream2.forEach(s-> System.out.println(s));
        //1.2.3方法引用
        System.out.println("--------1.2.3 方法引用----------");
        stream3.forEach(System.out::println);


        //2.Arrays中的Stream方法
        System.out.println("-----------2.Arrays中的Stream方法---------");
        String[] arr = new String[]{"aaa","bbb","ccc"};
        Stream streamArray = Arrays.stream(arr);
        Stream streamArray2 = Arrays.stream(arr);
        Stream streamArray3 = Arrays.stream(arr);
        //2.1lambda
        System.out.println("--------2.1lambda-----------");
        streamArray.forEach(s-> System.out.println(s));
        //2.2方法引用
        System.out.println("--------2.2方法引用-----------");
        streamArray2.forEach(System.out::println);
        //2.3匿名内部类
        System.out.println("--------2.3匿名内部类-----------");
        streamArray3.forEach(new Consumer<String>(){
            @Override
            public void accept(String s) {
                System.out.println(s);
            }
        });

        //3.Stream接口中的 of iterate generate 的方法
        System.out.println("-----3.Stream接口中的 of iterate generate 的方法-----");
        //3.1 of 方法
        System.out.println("---------3.1 of 方法---------");
        Stream<Integer> streamIn = Stream.of(10,20,30,40,50,60);
        streamIn.forEach(System.out::println);
        //3.2 iterate 迭代流
        System.out.println("---------3.2 iterate 迭代流---------");
        Stream<Integer> streamIter = Stream.iterate(1, c->c*2);
        //limit()设置操作次数的上限 中间操作
        streamIter.limit(10).forEach(System.out::println);
        //3.3 generate 生成流
        System.out.println("---------3.3 generate 生成流---------");
        //3.3.1匿名内部类
        System.out.println("---3.3.1匿名内部类---");
        Stream<Integer> streamGene = Stream.generate(new Supplier<Integer>() {
            @Override
            public Integer get() {
                return new Random().nextInt(1000);
            }
        });
        streamGene.limit(10).forEach(new Consumer<Integer>() {
            @Override
            public void accept(Integer s) {
                System.out.println(s);
            }
        });
        //3.3.2 lambda
        System.out.println("---3.3.2 lambda---");
        Stream<Integer> streamGene2 = Stream.generate(()->new Random().nextInt(10000));
        streamGene2.limit(5).forEach(s-> System.out.println(s));

        //4. IntStream,LongStream,DoubleStream 的 of range rangeClosed方法
        System.out.println("----4. IntStream,LongStream,DoubleStream 的 of range rangeClosed方法-----");
        //4.1 of方法
        System.out.println("-------4.1 of方法------");
        IntStream intStream = IntStream.of(10,20,30);
        intStream.forEach(System.out::println);
        //4.2 range方法 不包含末尾
        System.out.println("-------4.2 range方法------");
//        IntStream intStream2 = IntStream.range(0,5);
        //rangeClosed 包含末尾
        IntStream intStream2 = IntStream.rangeClosed(0,5);

        intStream2.forEach(System.out::println);


    }
}
