package com.qf.Chapter18_2;

import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * @Description: 中间操作
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class IntermediateStream {
    public static void main(String[] args) {
        ArrayList<Employee> list = new ArrayList<>();
        list.add(new Employee("小王",12000));
        list.add(new Employee("小明",20000));
        list.add(new Employee("小成",16000));
        list.add(new Employee("小李",24000));
        list.add(new Employee("小路",30000));
        list.add(new Employee("小路",30000));
        // 1 filter 过滤 2 limit 限制 3 skip 跳过 4 distinct 去重 5 sorted 排序
        //1 filter 过滤
        System.out.println("----1 filter 过滤-----");
        //lambda
//        list.stream()
//                .filter(e->e.getMoney()>20000)
//                .forEach(System.out::println);
        //匿名内部类
        list.stream().
                filter(new Predicate<Employee>(){
                    @Override
                    public boolean test(Employee e) {
                        return e.getMoney()>20000;
                    }
                })
                .forEach(new Consumer<Employee>() {
                    @Override
                    public void accept(Employee e) {
                        System.out.println(e.toString());
                    }
                });
//                .forEach(System.out::println);

        //2 limit 限制
        System.out.println("----2 limit 限制-----");
//        list.stream()
//                .limit(2)
//                .forEach(System.out::println);
        list.stream()
                .limit(2)
                .forEach(new Consumer<Employee>() {
                    @Override
                    public void accept(Employee e) {
                        System.out.println(e.toString());
                    }
                });

        //3 skip 跳过
        System.out.println("----3 skip 跳过-----");
        list.stream()
                .skip(2)
                .forEach(System.out::println);


        //4 distinct 去重
        System.out.println("----4 distinct 去重-----");
        //通过重写 equals() hashCode()方法比较去重
        list.stream()
                .distinct()
                .forEach(System.out::println);

        //5 sorted 排序
        System.out.println("----5 sorted 排序-----");
        list.stream()
                .sorted((o1,o2)->Double.compare(o1.getMoney(),o2.getMoney()))
                .forEach(System.out::println);

        //6 map 将流映射成另一组数据
        System.out.println("----6 map 将流映射成另一组数据-----");
        //lambda
        System.out.println("-------6.1 lambda---------");
        list.stream()
                .map(e->e.getName())
                .forEach(System.out::println);
        //匿名内部类
        System.out.println("-------6.2 匿名内部类---------");
        list.stream()
                .map(new Function<Employee,String>(){
                    @Override
                    public String apply(Employee e) {
                        return e.getName();
                    }
                })
                .forEach(new Consumer<String>(){
                    @Override
                    public void accept(String s) {
                        ArrayList<String> arr = new ArrayList<>();
                        arr.add(s);
                        System.out.println(arr.toString());
                    }
                });

        //7 parallel 采用多线程 效率高
        System.out.println("-------7 parallel 采用多线程 效率高---------");
        list.parallelStream()
                .forEach(System.out::println);


    }
}
