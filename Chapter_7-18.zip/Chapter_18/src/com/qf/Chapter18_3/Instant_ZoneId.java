package com.qf.Chapter18_3;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Set;

/**
 * @Description: Instant ZoneId
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Instant_ZoneId {
    public static void main(String[] args) {
        //Instant
        Instant instant = Instant.now();
        System.out.println(instant.toString());
        //变成毫秒数
        System.out.println(instant.toEpochMilli());
        //当前时间
        System.out.println(System.currentTimeMillis());

        //增加减少时间
        Instant instant2 = instant.plusSeconds(10);
        System.out.println(Duration.between(instant,instant2).toMillis());

        //ZoneId
        ZoneId zoneId = ZoneId.systemDefault();
        System.out.println(zoneId.toString());
        Set<String> zoneSet = ZoneId.getAvailableZoneIds();
        for (String str:zoneSet){
            System.out.println(str);
        }

        //Date ----------> Instant ---------->LocalDateTime
        System.out.println("Date ----------> Instant ---------->LocalDateTime");
        Date date = new Date();
        Instant instant3 = date.toInstant();
        System.out.println(instant3.toString());
        LocalDateTime ldt = LocalDateTime.ofInstant(instant3,ZoneId.systemDefault());
        System.out.println(ldt);


        //LocalDateTime ----------> Instant ---------->Date
        System.out.println("LocalDateTime ----------> Instant ---------->Date");
        Instant instant4 = ldt.atZone(ZoneId.systemDefault()).toInstant();
        System.out.println(instant4);
        Date date2 = Date.from(instant4);
        System.out.println(date2);

        //DateTimeFormatter
        System.out.println("----DateTimeFormatter-----");
        //把时间格式化成文本
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String time = dtf.format(LocalDateTime.now());
        System.out.println(time);
        //把文本解析成时间
        LocalDateTime ldt2 = LocalDateTime.parse("2020-02-21 08:00:01",dtf);
        System.out.println(ldt2.toString());
    }
}
