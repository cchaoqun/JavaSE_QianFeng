package com.qf.Chapter18_3;

import java.time.LocalDateTime;

/**
 * @Description: LocalDateTime
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class LocalDateTimeDemo {
    public static void main(String[] args) {
        //创建本地时间
        LocalDateTime localDateTime1 = LocalDateTime.now();
        LocalDateTime localDateTime2 = LocalDateTime.of(2019, 12, 31, 8, 0);
        System.out.println(localDateTime1);
        System.out.println(localDateTime2);
        System.out.println(localDateTime1.getYear());
        System.out.println(localDateTime1.getMonth());
        System.out.println(localDateTime1.getDayOfMonth());

        //添加两天
        LocalDateTime localDateTime3 = localDateTime1.plusDays(2);
        System.out.println(localDateTime3);

        //减一个月
        LocalDateTime localDateTime4 = localDateTime1.minusMonths(1);
        System.out.println(localDateTime4);
    }
}
