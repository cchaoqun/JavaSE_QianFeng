package com.qf.Chapter18_3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * @Description: SimpleDateFormat 线程安全问题 
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Demo1 {
    public static void main(String[] args) throws Exception{
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyDDmm");
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
            ExecutorService pool = Executors.newFixedThreadPool(10);
            Callable<LocalDate> callable = new Callable<LocalDate>(){
                @Override
                public LocalDate call() throws Exception {
                    return LocalDate.parse("20201201", dtf);
                }
            };
            List<Future<LocalDate>> list = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                Future<LocalDate> task = pool.submit(callable);
                list.add(task);
            }
            for (Future<LocalDate> task: list){
                System.out.println(task.get());
            }

//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//        ExecutorService pool = Executors.newFixedThreadPool(10);
//        Callable<Date> callable = new Callable<Date>(){
//            @Override
//            public Date call() throws Exception {
//                return sdf.parse("20201201");
//            }
//        };
//        List<Future<Date>> list = new ArrayList<>();
//        for (int i = 0; i < 10; i++) {
//            Future<Date> task = pool.submit(callable);
//            list.add(task);
//        }
//        for (Future<Date> task: list){
//            System.out.println(task.get());
//        }
    }
}
