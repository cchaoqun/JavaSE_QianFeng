package com.qf.debug;

import java.util.HashMap;

public class DebugTest {
    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            System.out.println(i);
        }
        HashMap<String,String> hashMap = new HashMap<>();
        hashMap.put("Name","1");
        hashMap.put("age","2");
        hashMap.put("city","3");
        hashMap.put("school","4");
        hashMap.put("job","5");

        String map = hashMap.get("Name");
        System.out.println(map);
        hashMap.remove("city");
        System.out.println(hashMap.toString());
    }
}
