package com.qf.Chapter_12_4;

public class Student implements Comparable<Student>{
    private String name;
    private int stuNo;

    public Student() {
    }

    public Student(String name, int stuNo) {
        this.name = name;
        this.stuNo = stuNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStuNo() {
        return stuNo;
    }

    public void setStuNo(int stuNo) {
        this.stuNo = stuNo;
    }

    @Override
    public String toString() {
        return "Student[" + "name='" + name + '\'' + ", stuNo=" + stuNo + ']';
    }

    //重写hashcode和equals方法

    @Override
    public boolean equals(Object o) {
        if(this == o){
            return true;
        }
        if(o==null){
            return false;
        }
        if(o instanceof Student){
            if(this.name.equals(((Student) o).getName())&&this.stuNo==((Student) o).getStuNo());
            return true;
        }
        return false;

    }

    @Override
    public int hashCode(){
        final int prime = 31;
        int result = 1;
        result = result * prime + stuNo;
        result = result * prime + ((this.name==null)? 0:this.name.hashCode());
        return result;
    }

    @Override
    public int compareTo(Student stu) {
        int n1 = this.stuNo - stu.getStuNo();
        return n1;
    }
}
