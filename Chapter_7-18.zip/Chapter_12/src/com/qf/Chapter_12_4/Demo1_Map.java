package com.qf.Chapter_12_4;

import java.util.HashMap;
import java.util.Map;

/*
* Map
* 特点：(1)用于存储任意键值对
*      (2)无序、无下标、键不可重复、值可重复
*
* */
public class Demo1_Map {
    public static void main(String[] args) {
        //创建集合
        Map<String,String> map = new HashMap<String,String>();
        //1添加元素
        map.put("CN","中国");
        map.put("UK","英国");
        map.put("USA","美国");
        map.put("CN","zhongguo");//添加重复键后，后者映射的值会覆盖前者
        System.out.println("元素个数"+map.size());
        System.out.println(map.toString());

        //2删除元素
        //map.remove("USA");
        //System.out.println("删除之后"+map.size());

        //3遍历
        //3.1 KeySet()
        System.out.println("------------3.1 KeySet()------------");
        //keySet()返回值是Set集合
        //Set<String> keySet = map.keySet();
        for (String key:map.keySet()){
            System.out.println(key+":"+map.get(key));
        }
        //3.2 EntrySet()
        System.out.println("------------3.2 EntrySet()------------");
        //entrySet 返回值是Set集合、类型是entry(键值对)
        //Set<Map.Entry<String,String>> entrySet = map.entrySet();
        for (Map.Entry<String,String> entries:map.entrySet()){
            System.out.println(entries.getKey()+":"+entries.getValue());
        }

        //4判断
        System.out.println(map.containsKey("CN"));
        System.out.println(map.containsValue("泰国"));
    }
}
