package com.qf.Chapter_12_4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/*
 * Collections工具类的常用方法
 *
 *
 * */
public class Demo4_Collections {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<Integer>();
        //添加元素
        list.add(20);
        list.add(2);
        list.add(13);
        list.add(57);
        list.add(120);
        list.add(287);
        //sort排序
        System.out.println("排序之前："+list.toString());
        Collections.sort(list);
        System.out.println("排序之后："+list.toString());

        //binarySearch 二分查找
        /*
        *
        *
        *
        * */
        int i = Collections.binarySearch(list,288);
        System.out.println(i);

        //Copy 复制
        List<Integer> dest = new ArrayList<Integer>();
        for (int j = 0; j < list.size(); j++) {
            dest.add(0);
        }
        Collections.copy(dest,list);
        System.out.println("复制:"+dest.toString());

        //reverse 反转
        Collections.reverse(list);
        System.out.println("反转之后:"+list.toString());

        //shuffle 打乱
        Collections.shuffle(list);
        System.out.println("打乱以后:"+list.toString());

        //补充
        //list转成数组
        System.out.println("------------list转成数组-----------");
        Integer[] arr = list.toArray(new Integer[0]);//new的数组大小小于list时，新的数组和list大小相同
        System.out.println(arr.length);
        System.out.println(Arrays.toString(arr));
        //数组转成集合
        System.out.println("------------数组转成集合-----------");
        String [] names = {"kobe","James","WADE"};
        List<String> list2 = Arrays.asList(names);
        //数组不可改变长度和元素
        //list2.remove("WADE");
        //list2.add("Onearl");
        System.out.println(list2.toString());
        //把基本类型数组转成集合时，需使用包装类
        int [] nums1 = {100,200,300,400};
        Integer [] nums = {100,200,300};
        List<Integer> list3 = Arrays.asList(nums);
        System.out.println(list3.toString());
    }
}
