package com.qf.Chapter_12_4;

public class TestCoputing {
    public static void main(String[] args) {
        int h;
        String name = "CCQ";
        System.out.println(name.hashCode());
        System.out.println((h = name.hashCode()) ^ (h >>> 16));
        System.out.println(h>>>16);
        System.out.println(2^1);
        String biStr = Integer.toBinaryString(h);
        String biStr2 = Integer.toBinaryString(1);

        System.out.println(biStr);
        System.out.println(biStr2);
    }
}
