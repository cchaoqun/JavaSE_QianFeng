package com.qf.Chapter_12_4;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

/*
* TreeMap的使用
* 存储结构：红黑树，必须实现Comparable接口
*
*
*
*
* */
public class Demo3_TreeMap {
    public static void main(String[] args) {
        //新建集合
        TreeSet
        //定制比较规则则无需泛型类实现Comparable接口
        TreeMap<Student,String> treeMap = new TreeMap<Student,String>(new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                int n1 = s1.getStuNo() - s2.getStuNo();
                int n2 = s1.getName().compareTo(s2.getName());

                return (n1==0)? n2:n1;
            }
        });
        //1.添加元素
        Student s1 = new Student("科比",100);
        Student s2 = new Student("詹姆斯",101);
        Student s3 = new Student("韦德",102);
        treeMap.put(s1,"LA");
        treeMap.put(s2,"CLE");
        treeMap.put(s3,"MIA");
        treeMap.put(new Student("韦德",102),"CHI");
        System.out.println("元素个数" + treeMap.size());
        System.out.println(treeMap.toString());

        //2.删除元素
        //treeMap.remove(new Student("韦德",102));
        //System.out.println("删除以后"+treeMap.size());

        //3.遍历
        //3.1 keySet()
        System.out.println("-----------3.1 keySet()--------------");
        //Set<Student> keySet = treeMap.keySet();
        for (Student key:treeMap.keySet()){
            System.out.println(key+"->"+treeMap.get(key));
        }
        //3.2 entrySet()
        System.out.println("-----------3.2 entrySet()--------------");
        for (Map.Entry<Student,String> entry: treeMap.entrySet()){
            System.out.println(entry.getKey()+"->"+entry.getValue());
        }

        //4.判断
        System.out.println(treeMap.containsKey(new Student("韦德",102)));
        System.out.println(treeMap.containsValue("HEAT"));
    }
}
