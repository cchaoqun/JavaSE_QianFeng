package com.qf.Chapter_12_4;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*
* HashMap集合的使用
* 存储结构 ： 哈希表 （数组+链表+红黑树）
* 重复依据：key的hashcode和equals方法判断
*
* */
public class Demo2_HashMap {
    public static void main(String[] args) {
        //创建集合
        HashMap<Student, String> students = new HashMap<Student, String>();
        //无参构造方法，刚创建HashMap未添加元素时 table=null size=0,目的是节省空间
        //1.添加元素
        Student s1 = new Student("科比",100);
        Student s2 = new Student("詹姆斯",101);
        Student s3 = new Student("韦德",102);
        students.put(s1,"LA");
        students.put(s2,"CLE");
        students.put(s3,"MIA");
        //students.put(s3,"CLE");
        students.put(new Student("韦德1",102),"CHI");//若不想添加重复key的元素，须在Student类中重写hashcode和equals方法
        System.out.println("元素个数"+students.size());
        System.out.println(students.toString());

        //2.删除
        //students.remove(s1);
        //System.out.println("删除以后"+students.size());

        //3.遍历
        //3.1 keySet()
        System.out.println("----------3.1 keySet()----------");
        //Set<Student> keySet = students.keySet();
        for (Student key:students.keySet()){
            System.out.println(key+"->"+students.get(key));
        }
        //3.2 entrySet()
        System.out.println("----------3.2 entrySet()----------");
        Set<Entry<Student, String>> entries =  students.entrySet();
        for (Entry<Student,String> entry: entries){
            System.out.println(entry.getKey()+"--------"+entry.getValue());
        }
        //Set<Map.Entry<Student,String>> entrySet = students.entrySet();
        for (Map.Entry<Student,String> entry:students.entrySet()){
            System.out.println(entry.getKey()+"->"+entry.getValue());
        }



    }
}
