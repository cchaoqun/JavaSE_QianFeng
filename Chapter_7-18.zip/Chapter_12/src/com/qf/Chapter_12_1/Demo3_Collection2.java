package com.qf.Chapter_12_1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Demo3_Collection2 {
    public static void main(String[] args) {
        //创建Collection集合 存储Student类对象
        Collection collection  = new ArrayList();
        Student s1 = new Student("张一",20);
        Student s2 = new Student("张二",21);
        Student s3 = new Student("张三",22);

        //1.添加元素
        collection.add(s1);
        collection.add(s2);
        collection.add(s3);
        System.out.println(collection.toString());
        System.out.println("元素个数："+collection.size());

        //2.删除元素
        //collection.remove(s1);
        //能否实现通过这种方式删除s2
        //collection.remove(new Student("张二",21));
//        System.out.println("删除之后元素个数："+collection.size());

        //3.遍历元素
        //3.1使用增强for
        System.out.println("----------3.1增强for-----------");
        for (Object object:collection) {
            Student s = (Student)object;
            System.out.println(s.toString());
        }
        //3.2使用Iterator迭代器 hasNext() next() remove() 迭代过程不能使用collection删除方法
        System.out.println("----------3.2使用Iterator迭代器-----------");
        //获取一个迭代器
        Iterator it = collection.iterator();
        while(it.hasNext()){
            Student s = (Student)it.next();
            System.out.println(s);
        }

        //4.判断
        System.out.println(collection.contains(new Student("张二",21)));//false
        System.out.println(collection.contains(s1));
        System.out.println(collection.isEmpty());

    //    ====================Test====================
    //    Collection collection = new ArrayList();
    //    Student s1 = new Student("yi",1);
    //    Student s2 = new Student("er",2);
    //    Student s3 = new Student("san",3);
    //    collection.add(s1);
    //    collection.add(s2);
    //    collection.add(s3);
    //    System.out.println("元素个数" + collection.size());
    //
    //    //collection.remove(s1);
    //    //collection.clear();
    //    collection.remove(new Student("san",3));
    //    System.out.println("删除之后"+collection.size());
    //
    //    for (Object object : collection) {
    //        System.out.println(object);
    //
    //    }
    //
    //    Iterator it = collection.iterator();
    //    while(it.hasNext()){
    //        Student s = (Student)it.next();
    //        System.out.println(s);
    //    }
    //
    //    System.out.println(collection.contains(s1));
    //    System.out.println(collection.isEmpty());
    }
}
