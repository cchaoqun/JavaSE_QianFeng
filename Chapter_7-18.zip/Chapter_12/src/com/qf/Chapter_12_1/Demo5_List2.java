package com.qf.Chapter_12_1;

import java.util.ArrayList;
import java.util.List;

/*
* list子接口的使用
*
*
*
* */
public class Demo5_List2 {
    public static void main(String[] args) {
        //创建集合
        List list = new ArrayList();
    //    添加元素 集合中不能添加基本类型，只能添加引用类型，所以这里存在自动装箱，添加为Integer类型元素
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        list.add(60);
        System.out.println("元素个数" + list.size());
        System.out.println(list.toString());
    //    删除元素
    //    1.通过下标来删除指定元素
    //    list.remove(0);
    //    2.Object(20) new Integer(20)
    //    list.remove((Object)20);
        list.remove(new Integer(20));
        System.out.println(list.toString());
    //    创建子集合 索引下标含前不含后 返回下标为1 2的两个元素集合
        List list2 = list.subList(1,3);
        System.out.println(list2.toString());

    //    List list = new ArrayList();
    //    list.add(10);
    //    list.add(20);
    //    list.add(30);
    //    list.add(40);
    //    list.add(50);
    //    System.out.println("元素个数" + list.size());
    //
    //    //list.remove((Object)20);
    //    list.remove(new Integer(20));
    //    System.out.println(list.toString());
    //
    //    List list2 =list.subList(2,4);
    //    System.out.println(list2.toString());
    }
}
