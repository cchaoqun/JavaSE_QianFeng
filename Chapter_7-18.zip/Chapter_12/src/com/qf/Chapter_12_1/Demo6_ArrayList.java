package com.qf.Chapter_12_1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

/*
* ArrayList
* 实现结构：数组，有序、有下表、元素可重复
*
* */
public class Demo6_ArrayList {
    public static void main(String[] args) {
    //    创建数组列表 容量=0 size=0
        ArrayList arrayList = new ArrayList();
    //   1. 添加元素
        Student s1 = new Student("一",20);
        Student s2 = new Student("二",20);
        Student s3 = new Student("三",20);
        arrayList.add(s1);
        arrayList.add(s2);
        arrayList.add(s3);
        System.out.println("元素个数" + arrayList.size());

    //    2.删除元素
    //    arrayList.remove(new Student("一",20));//this == obj 重写equals方法即可通过此形式删除该元素
    //    System.out.println("元素个数"+arrayList.size());
    //    System.out.println(arrayList.toString());

    //    3.遍历元素
    //    3.1 for循环
        System.out.println("--------3.1 for循环---------");
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println(arrayList.get(i));
        }
    //    3.2 增强for
        System.out.println("--------3.2 增强for---------");
        for (Object object : arrayList) {
            System.out.println((Student)object);
        }
    //    3.3 iterator
        System.out.println("--------3.3 iterator---------");
        Iterator it = arrayList.iterator();
        while(it.hasNext()){
            System.out.println((Student)it.next());
        }
    //    3.4 ListIterator
        System.out.println("--------3.4 ListIterator 顺序---------");
        ListIterator lit = arrayList.listIterator();
        while(lit.hasNext()){
            System.out.println(lit.nextIndex()+":"+lit.next());
        }
        System.out.println("--------3.4 ListIterator 逆序---------");
        while(lit.hasPrevious()){
            System.out.println(lit.previousIndex()+":"+lit.previous());
        }

    //    判断
        System.out.println(arrayList.contains(new Student("三",20)));
        System.out.println(arrayList.isEmpty());

    //    查找
        System.out.println(arrayList.indexOf(new Student("三",20)));
    }
}
