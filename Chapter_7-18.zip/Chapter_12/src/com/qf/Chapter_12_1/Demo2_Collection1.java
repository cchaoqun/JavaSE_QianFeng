package com.qf.Chapter_12_1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/*
* Collection体系集合
*   Collection父接口：该体系接口的根接口，代表一组对象，称为集合
*       List子接口：有序，有下标，可以重复
*       Set子接口：无序，无下标，不可重复
*
* Collection接口的使用
*   1.添加元素
*   2.删除元素
*   3.遍历元素
*   4.判断
*
*
* */
public class Demo2_Collection1 {
    public static void main(String[] args) {
        //创建Collection集合
        //可以创建对象但是不可以实例化对象
        //List Set接口也不可实例化对象，但是对应实现类可以
        //*   1.添加元素
        Collection collection = new ArrayList();
        collection.add("科比");
        collection.add("韦德");
        collection.add("詹姆斯");
        System.out.println(collection);
        System.out.println("元素个数："+collection.size());

        //*   2.删除元素
        //collection.remove("科比");
        //collection.clear();//删除所有元素
        //System.out.println("元素个数："+collection.size());

        //*   3.遍历元素

        //3.1增强for遍历 (因为collection集合没有下标，无法通过普通for循环下标的方式遍历元素)

        // * for(元素类型 ele : 数组名/Iterable 实例){}
        // *
        // *

        System.out.println("-------------3.1增强for遍历---------------");
        for (Object object:collection){
            System.out.println(object);
        }

        //3.2使用迭代器(迭代器专门用来遍历集合的一种方式)

        System.out.println("-------------3.2使用迭代器---------------");
        Iterator it = collection.iterator();
        //it.hasNext();//有没有下一个元素
        //it.next();//获取下一个元素
        //it.remove();//删除下一个元素
        while (it.hasNext()){
            String s = (String)it.next();//将获取的元素转换成字符串 强制类型转化
            System.out.println(s);
            //迭代过程中不允许使用collection删除方法 remove()，可以使用迭代器remove()方法
            //collection.remove(s);
            //it.remove();
        }
        System.out.println("元素个数："+collection.size());
        //*   4.判断
        System.out.println(collection.contains("科比"));
        System.out.println(collection.isEmpty());

        //================================Test================================

        //Collection collection = new ArrayList();
        //collection.add("1");
        //collection.add("2");
        //collection.add("3");
        //System.out.println("元素个数"+collection.size());
        //
        ////collection.remove("1");
        //System.out.println("删除以后"+collection.size());
        //
        //for (Object object : collection) {
        //    System.out.println(object);
        //}
        //
        //Iterator it = collection.iterator();
        //while(it.hasNext()){
        //    String s = (String)it.next();
        //    System.out.println(s);
        //    //it.remove();
        //}
        //System.out.println("元素个数"+collection.size());
        //
        //System.out.println(collection.contains("1"));
        //System.out.println(collection.isEmpty());
    }
}
