package com.qf.Chapter_12_1;

/*
* List子接口的使用
* 特点：有序，有下标，可以重复
*
* 方法
*   void add(int index, object o) //在指定位置插入对象o
*   boolean addAll(int index, Collection c)//将一个集合中的元素c添加到集合中指定index位置
*   Object get(int index)//返回集合中指定位置的元素
*   List sublist(int fromIndex, int toIndex)//返回fromIndex和toIndex之间的集合元素
*
*
*
*
* */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Demo4_List {
    public static void main(String[] args) {
    //    1.创建集合
        List list = new ArrayList();

    //    2.添加元素
        list.add("苹果");
        list.add("小米");
        list.add(0,"华为");
        System.out.println("元素个数"+list.size());
        System.out.println(list.toString());

    //    3.删除元素
    //    list.remove(0);
    //    list.remove("苹果");
    //    System.out.println(list.toString());

    //    4.遍历元素
    //    4.1使用for循环
        System.out.println("------------4.1使用for循环-------------");
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    //    4.2使用增强for
        System.out.println("------------4.2使用增强for-------------");
        for(Object object: list){
            System.out.println((String)object);
        }
    //    4.3使用iterator
        System.out.println("------------4.3使用iterator-------------");
        Iterator it =list.iterator();
        while(it.hasNext()){
            System.out.println(it.next().toString());
        }
    //    4.4使用listiterator 与Iterator的区别， listIterator可以向前或向后 遍历，删除，添加，修改元素
        System.out.println("------------4.4使用listiterator-------------");
        ListIterator lit = list.listIterator();
//        System.out.println("------------正序遍历-------------");
//        while(lit.hasNext()){
//            System.out.println(lit.nextIndex()+":"+lit.next());
//        }
        System.out.println("------------反序遍历-------------");
        while(lit.hasPrevious()){
            System.out.println(lit.previousIndex()+":"+lit.previous());
        }

    //    5判断
        System.out.println(list.contains("苹果"));
        System.out.println(list.isEmpty());
        System.out.println(list.indexOf("小米"));

    //=================Test==========================
    //    List list = new ArrayList();
    //    list.add("2");
    //    list.add("3");
    //    list.add(0,"1");
    //    System.out.println("元素个数" + list.size());
    //
    //    //list.remove("1");
    //    System.out.println("删除之后"+list.size());
    //
    //    for (int i = 0; i < list.size(); i++) {
    //        System.out.println(list.get(i));
    //    }
    //
    //    for (Object object : list) {
    //        System.out.println(object);
    //    }
    //
    //    Iterator it = list.iterator();
    //    while(it.hasNext()){
    //        String s = (String)it.next();
    //        System.out.println(s);
    //    }
    //
    //    ListIterator lit = list.listIterator();
    //    while(lit.hasNext()){
    //        //String s = (String) lit.next();
    //        System.out.println(lit.nextIndex()+":"+lit.next());
    //    }
    //
    //    while(lit.hasPrevious()){
    //        //String s = (String)lit.previous();
    //        System.out.println(lit.previousIndex()+":"+lit.previous());
    //    }
    //
    //    System.out.println(list.contains("1"));
    //    System.out.println(list.isEmpty());
    //    System.out.println(list.indexOf("2"));

    }

}
