package com.qf.Chapter_12_3;

import java.util.Iterator;
import java.util.TreeSet;

/*
* TreeSet的使用
* 存储结构：红黑树
*
* */
public class Demo4_TreeSet {
    public static void main(String[] args) {
        //创建集合
        TreeSet<String> treeSet = new TreeSet<String>();
        //1.添加元素
        treeSet.add("abc");
        treeSet.add("hello");
        treeSet.add("xyz");
        treeSet.add("xyz");
        System.out.println("元素个数"+treeSet.size());
        System.out.println(treeSet.toString());

        //2.删除元素
        treeSet.remove("abc");
        System.out.println("删除以后"+treeSet.size());

        //3.遍历元素
        //3.1 增强for
        System.out.println("------------3.1 增强for----------");
        for (String s:treeSet){
            System.out.println(s);
        }
        //3.2 Iterator
        System.out.println("------------3.2 Iterator----------");
        Iterator<String> it = treeSet.iterator();
        while(it.hasNext()){
            String s = (String)it.next();
            System.out.println(s);
        }

        //4.判断
        System.out.println(treeSet.contains("abc"));
        System.out.println(treeSet.isEmpty());
    }
}
