package com.qf.Chapter_12_3;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/*
* 测试Set接口的使用
* 特点：无序，无下标，不能重复
* */
public class Demo1_Set {
    public static void main(String[] args) {
    //    创建集合
        Set<String> set = new HashSet<>();
    //    1.添加元素
        set.add("小米");
        set.add("Apple");
        set.add("华为");
        System.out.println("元素个数:" + set.size());
        System.out.println(set.toString());

    //    2.删除元素
    //    set.remove("小米");
    //    System.out.println(set.toString());

    //    3.遍历元素
    //    3.1 增强for
        System.out.println("-----------3.1 增强for-----------");
        for (String s:set) {
            System.out.println(s);
        }
        // 3.2 Iterator
        System.out.println("-----------3.2 Iterator-----------");
        Iterator<String> it = set.iterator();
        while(it.hasNext()){
            String s = (String)it.next();
            System.out.println(s);
        }

    //    4.判断
        System.out.println(set.contains("小米"));
        System.out.println(set.isEmpty());

    }
}
