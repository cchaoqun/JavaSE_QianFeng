package com.qf.Chapter_12_3;

import java.util.Objects;

public class Person implements Comparable<Person>{
    private String name;
    private int age;

    public Person() {

    }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" + "name='" + name + '\'' + ", age=" + age + '}';
    }




    //@Override
    //public int hashCode() {
    //    int n1 = this.name.hashCode();
    //    int n2 = this.age;
    //    return n1 + n2;
    //}
    //
    //public boolean equals(Object obj) {
    //    if(this==obj){
    //        return true;
    //    }
    //    if(obj==null){
    //        return false;
    //    }
    //    if(obj instanceof Person){
    //        if(this.name.equals(((Person) obj).getName())&&this.age== ((Person) obj).getAge()){
    //            return true;
    //        }
    //    }
    //
    //    return false;
    //}


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return age == person.age &&
                Objects.equals(name, person.name);
    }

    @Override
    public int hashCode() {
        //(1)31是一个质数，减少散列冲突
        //(2)31提高执行效率 31*i = (2<<i) - i (2^i - i)
        final int prime = 31;
        int result = 1;
        result = prime * result + this.age;
        result = prime * result + ((name == null)? 0 : this.name.hashCode());
        return result;

//        final int prime = 31;
//        int result = 1;
//        result = result * prime + age;
//        result = result * prime + ((name == null)? 0:name.hashCode());
//        return result;
    }

    @Override
    public int compareTo(Person person) {
        int n1 = this.name.compareTo(person.getName());
        int n2 = this.age - person.getAge();
        return n1==0? n2:n1;
    }
}
