package com.qf.Chapter_12_3;

import java.util.HashSet;
import java.util.Iterator;

/*
* HashSet集合的使用
* 存储结构: 哈希表(数组+链表+红黑树)
*
* */
public class Demo2_HashSet {
    public static void main(String[] args) {
    //    创建集合
        HashSet<String> hashSet = new HashSet<String>();
    //    1.添加元素
        hashSet.add("科比");
        hashSet.add("詹姆斯");
        hashSet.add("韦德");
        hashSet.add("奥尼尔");
        System.out.println("元素个数"+hashSet.size());
        System.out.println(hashSet.toString());

    //    2.删除
    //    hashSet.remove("科比");
    //    System.out.println("删除以后"+hashSet.size());

    //    3.遍历
    //    3.1 增强for
        System.out.println("----------3.1 增强for-----------");
        for (String s:hashSet){
            System.out.println(s);
        }
    //    3.2 Iterator
        System.out.println("----------3.2 Iterator-----------");
        Iterator<String> it = hashSet.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

    //    4判断
        System.out.println(hashSet.contains("安东尼"));
        System.out.println(hashSet.isEmpty());
    }
}
