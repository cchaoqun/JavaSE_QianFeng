package com.qf.Chapter_12_3;

import java.util.Iterator;
import java.util.TreeSet;

/*
* 使用TreeSet保存数据
* 存储结构：红黑树
* 要求：元素必须实现Comparable接口 (Person类中重写 CompareTo方法，按照指定方法比较）
*      CompareTo()返回值为0，认为是重复元素
* */
public class Demo5_TreeSet2 {
    public static void main(String[] args) {
        //创建集合
        TreeSet<Person> persons = new TreeSet<Person>();
        //1.添加元素
        Person p1 = new Person("xyz",21);
        Person p2 = new Person("hello",20);
        Person p3 = new Person("zhangsan",26);
        Person p4 = new Person("zhangsan",20);
        persons.add(p1);
        persons.add(p2);
        persons.add(p3);
        persons.add(p4);
        System.out.println("元素个数"+persons.size());
        System.out.println(persons.toString());

        //2.删除元素
        //persons.remove(new Person("zhangsan",20));
        //System.out.println("删除以后" + persons.size());

        //3.遍历
        //3.1 增强for
        System.out.println("-------------3.1 增强for-------------");
        for (Person p:persons){
            System.out.println(p);
        }
        //3.2 Iterator
        System.out.println("-------------3.2 Iterator-------------");
        Iterator<Person> it = persons.iterator();
        while(it.hasNext()){
            Person p = (Person)it.next();
            System.out.println(p);
        }

        //4.判断
        System.out.println(persons.contains(new Person("zhangsan",26)));
        System.out.println(persons.isEmpty());
    }
}
