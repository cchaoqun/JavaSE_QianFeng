package com.qf.Chapter_12_3;

import java.util.Comparator;
import java.util.TreeSet;

/*
* 要求使用TreeSet集合实现按照字符串长度进行排序
* Comparator接口实现定制比较
*
*
* */
public class Demo7_TreeSet4 {
    public static void main(String[] args) {
        //创建集合
//        TreeSet<String> string = new TreeSet<>(new Comparator<String>() {
//            @Override
//            public int compare(String s1, String s2) {
//                int n1 = s1.length() - s2.length();
//                int n2 = s1.compareTo(s2);
//                return n1==0? n2:n1;
//            }
//        });
        TreeSet<String> string = new TreeSet<>(new Comparator<String>(){
            @Override
            public int compare(String o1, String o2) {
                int n1 = o1.length() - o2.length();
                int n2 = o1.compareTo(o2);
                return ((n1 == 0)? n2:n1);
            }
        });





        //添加元素
        string.add("xian");
        string.add("lisi");
        string.add("cat");
        string.add("nanjing");
        string.add("wuhan");
        string.add("beijing");
        string.add("shanghai");
        string.add("helloworld");
        System.out.println(string.toString());
    }
}
