package com.qf.Chapter_12_3;

import java.util.HashSet;
import java.util.Iterator;

/*
* HashSet的使用
* 存储结构：哈希表（数组+链表+红黑树）
* 存储过程(重复的依据)
*   （1）根据hashcode计算保存的位置，若此位置为空，则直接保存，若不为空执行第二部
*   （2）再执行equals方法，若equals方法为真，则认为时重复，否则形成链表
* */
public class Demo3_HashSet2 {
    public static void main(String[] args) {
    //    创建集合
        HashSet<Person> persons = new HashSet<Person>();
    //    1.添加元素
        Person p1 = new Person("科比",21);
        Person p2 = new Person("詹姆斯",21);
        Person p3 = new Person("韦德",21);
        persons.add(p1);
        persons.add(p2);
        persons.add(p3);
        //persons.add(p3);重复
        //persons.add(new Person("韦德",21));//再重写 hashCode 和 equals 方法之前可以添加，重写后不可添加因为判定为重复元素
        System.out.println("元素个数"+persons.size());
        System.out.println(persons.toString());

    //    2.删除
    //    persons.remove(new Person("韦德",21));
    //    System.out.println("删除之后"+persons.size());

    //    3.遍历
    //    3.1 增强for
        System.out.println("--------------3.1 增强for-------------");
        for (Person p:persons){
            System.out.println(p.toString());
        }
    //    3.2 Iterator
        System.out.println("--------------3.2 Iterator-------------");
        Iterator<Person> it = persons.iterator();
        while(it.hasNext()){
            Person p = (Person)it.next();
            System.out.println(p.toString());
        }

    //    4.判断
        System.out.println(persons.contains("安东尼"));
        System.out.println(persons.isEmpty());
    }
}
