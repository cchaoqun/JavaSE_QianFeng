package com.qf.Chapter_12_3;

import java.util.Comparator;
import java.util.TreeSet;

/*
* TreeSet集合的使用
* Comparator : 实现定制比较(比较器)
*   在构造方法中重写compare方法，指定比较规则，则无需使Person类实现Comparable接口
* Comparable : 可比较的
*
* */
public class Demo6_TreeSet3 {
    public static void main(String[] args) {
        //创建集合,并指定比较规则
        TreeSet<Person> persons = new TreeSet<>(new Comparator<Person>() {
            //匿名内部类
            @Override
            public int compare(Person p1, Person p2) {
                int n1 = p1.getAge() - p2.getAge();
                int n2 = p1.getName().compareTo(p2.getName());
                return n1==0? n2:n1;
            }
        });
        //添加元素
        Person p1 = new Person("xyz",21);
        Person p2 = new Person("hello",20);
        Person p3 = new Person("zhangsan",26);
        persons.add(p1);
        persons.add(p2);
        persons.add(p3);
        System.out.println("元素个数" + persons.size());
        System.out.println(persons.toString());
    }
}
