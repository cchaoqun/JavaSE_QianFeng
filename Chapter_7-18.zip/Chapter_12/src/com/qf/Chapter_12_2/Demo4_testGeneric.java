package com.qf.Chapter_12_2;

public class Demo4_testGeneric {
    public static void main(String[] args) {
    //    使用泛型类型创建对象
    //    注意：1.泛型只能使用引用类型 2.不同泛型类型对象之间不能相互赋值

        //泛型类
        Demo3_MyGeneric<String> myGeneric = new Demo3_MyGeneric<String>();
        myGeneric.t = "hello";
        myGeneric.show("World");
        String s = myGeneric.getT();
        System.out.println(s);

        Demo3_MyGeneric<Integer> myGeneric2 = new Demo3_MyGeneric<Integer>();
        myGeneric2.t = 100;
        myGeneric2.show(200);
        Integer in = myGeneric2.getT();
        System.out.println(in);

        Demo3_MyGeneric<String> myGeneric3 = myGeneric;
        System.out.println(myGeneric3.t);

        //泛型接口
        //接口实现类在实现接口的时候已经确定泛型类型
        Demo6_MyInterfaceImpl myImpl1 = new Demo6_MyInterfaceImpl();
        myImpl1.server("接口实现类");

        //接口实现类在实现接口的时候不确定泛型类型，该实现类为泛型类
        //在实例化对象的时候才确定泛型引用类型
        Demo7_myInterfaceImpl2<Integer> myImpl2 = new Demo7_myInterfaceImpl2<Integer>();
        myImpl2.server(1000);

        //泛型方法
        Demo8_MyGenericMethod myGMethod = new Demo8_MyGenericMethod();
        //调用泛型方法时，无需传递泛型类型，会根据传入的值的类型确定
        myGMethod.show("Helloword");
        myGMethod.show(1000);
        myGMethod.show(3.14);
    }
}
