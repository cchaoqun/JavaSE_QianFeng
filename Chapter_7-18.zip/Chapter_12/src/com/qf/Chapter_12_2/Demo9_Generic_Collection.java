package com.qf.Chapter_12_2;

import com.qf.Chapter_12_1.Student;

import java.util.ArrayList;
import java.util.Iterator;

public class Demo9_Generic_Collection {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("XXX");
        arrayList.add("YYY");
        for (String s:arrayList) {
            System.out.println(s);
        }

        ArrayList<Student> arrayList1 = new ArrayList<Student>();
        Student s1 = new Student("一",20);
        Student s2 = new Student("二",20);
        Student s3 = new Student("三",20);
        arrayList1.add(s1);
        arrayList1.add(s2);
        arrayList1.add(s3);

        Iterator<Student> it =arrayList1.iterator();
        while(it.hasNext()){
            Student stu = it.next();
            System.out.println(stu.toString());
        }
    }
}
