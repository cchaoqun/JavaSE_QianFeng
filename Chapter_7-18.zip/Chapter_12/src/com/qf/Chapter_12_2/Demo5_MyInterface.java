package com.qf.Chapter_12_2;
/*
* 泛型接口
* 语法 接口名<T,...>
*
*
* */
public interface Demo5_MyInterface<T> {
    String name = "张三";

    T server(T t);
}
