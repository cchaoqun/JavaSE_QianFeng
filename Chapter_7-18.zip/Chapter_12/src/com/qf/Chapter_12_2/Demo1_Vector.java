package com.qf.Chapter_12_2;

import java.util.Enumeration;
import java.util.Vector;

/*
* Vector实现类
* 实现结构：数组
*
*
* */
public class Demo1_Vector {
    public static void main(String[] args) {
    //    创建向量
        Vector vector = new Vector();
    //    添加元素
        vector.add("10");
        vector.add("20");
        vector.add("30");
        vector.add("40");
        System.out.println("元素个数" + vector.size());

    //    删除元素
    //    vector.remove(0);
    //    vector.remove("10");
    //    vector.clear();

    //    遍历元素
    //    使用枚举器
        Enumeration en = vector.elements();
        while(en.hasMoreElements()){
            String s = (String)en.nextElement();
            System.out.println(s);
        }

    //    判断
        System.out.println(vector.contains("20"));
        System.out.println(vector.isEmpty());

    //    其他方法
    //    firstElement、 lastElement、 elementAt
        System.out.println(vector.firstElement());
        System.out.println(vector.lastElement());
        System.out.println(vector.elementAt(1));
    }
}
