package com.qf.Chapter_12_2;
/*
* 泛型方法
* 语法： <T> 返回值类型
*
* */
public class Demo8_MyGenericMethod {

    public <T> T show(T t){
        System.out.println(t);
        return t;
    }
}
