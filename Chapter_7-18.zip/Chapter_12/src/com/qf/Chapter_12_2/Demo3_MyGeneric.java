package com.qf.Chapter_12_2;

/*
 * 泛型类
 * 语法 类名<T,...>
    T为占位符，表示引用类型，如果编写多个使用逗号隔开
 *
 *
 *
 * */
public class Demo3_MyGeneric<T> {
//    使用泛型T
//    1.创建变量
    T t;

//    2.泛型作为方法的形参
    public void show(T t){
        System.out.println(t);
    }

//    3.泛型作为方法的返回值类型
    public T getT(){
        return t;
    }

}
