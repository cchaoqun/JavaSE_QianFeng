package com.qf.Chapter_12_2;

public class Demo6_MyInterfaceImpl implements Demo5_MyInterface<String>{
    @Override
    public String server(String t) {
        System.out.println(t);
        return t;
    }
}
