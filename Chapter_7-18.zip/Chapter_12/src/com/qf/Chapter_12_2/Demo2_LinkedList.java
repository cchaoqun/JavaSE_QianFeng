package com.qf.Chapter_12_2;

import com.qf.Chapter_12_1.Student;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

/*
* LinkedList的使用
* 存储结构：双向链表
*
*
*
* */
public class Demo2_LinkedList {
    public static void main(String[] args) {
    //    创建集合
        LinkedList<Student> linkedList = new LinkedList<>();
    //    1.添加元素
        Student s1 = new Student("一",20);
        Student s2 = new Student("二",20);
        Student s3 = new Student("三",20);
        linkedList.add(s1);
        linkedList.add(s2);
        linkedList.add(s3);
        System.out.println("元素个数" + linkedList.size());
        System.out.println(linkedList.toString());

    //    2.删除元素
    //    linkedList.remove(new Student("三",20));//因为重写了equals方法，可以这样删除元素
    //    System.out.println("删除以后" + linkedList.size());

    //    3.遍历元素
    //    3.1 for
        System.out.println("==============3.1 for============");
        for (int i = 0; i < linkedList.size(); i++) {
//            Student s = (Student)linkedList.get(i);
            Student s = linkedList.get(i);
            System.out.println(s);
        }
    //    3.2 增强for
        System.out.println("==============3.2 增强for============");
        for (Student s : linkedList) {
//            Student s = (Student)object;
            System.out.println(s);
        }
    //    3.3 Iterator
        System.out.println("==============3.3 Iterator============");
        Iterator<Student> it = linkedList.iterator();
        while(it.hasNext()){
//            Student s = (Student)it.next();
            Student s = it.next();
            System.out.println(s);
        }
    //    3.4 ListIterator
        System.out.println("==============3.4 ListIterator正序============");
        ListIterator<Student> lit = linkedList.listIterator();
        while(lit.hasNext()){
            Student s = lit.next();
            System.out.println(s);
        }
        System.out.println("==============3.4 ListIterator逆序============");
        while(lit.hasPrevious()){
            Student s = lit.previous();
            System.out.println(s);
        }

    //    4判断
        System.out.println(linkedList.contains(new Student("三",20)));
        System.out.println(linkedList.isEmpty());

    //    5.获取
        System.out.println(linkedList.indexOf(new Student("一",20)));




    }
}
