package com.qf.Chapter_12_2;

public class Demo7_myInterfaceImpl2<T> implements Demo5_MyInterface<T>{
    @Override
    public T server(T t) {
        System.out.println(t);
        return t;
    }
}
