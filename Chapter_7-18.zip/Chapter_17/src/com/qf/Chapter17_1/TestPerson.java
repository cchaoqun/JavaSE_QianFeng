package com.qf.Chapter17_1;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Properties;

/**
 * @Description:
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class TestPerson {
    public static void main(String[] args) throws Exception{
        //-verbose:class (VM option)显示类的加载过程
//        Person person = new Person(20,"zhangsan");
//        person.eat();
//        getClazz();
//        reflectOpe1();
//        reflectOpe2();
//        reflectOpe3();
        Properties properties = new Properties();
//        正常调用对象方法
        properties.setProperty("name","zhangsan");
        System.out.println(properties.toString());
//        通过invokeAny
        invokeAny(properties,"setProperty",new Class<?>[]{String.class,String.class}, "name","zhangsan");
        System.out.println(properties.toString());
        reflectOpe4();
    }

    public static void getClazz() throws Exception{
        //1.通过类的对象获取类对象
        Person p1 = new Person(20,"lisi");
        Class<?> class1 = p1.getClass();
        System.out.println(class1.hashCode());
        //2.通过类名获取类对象
        Class<?> class2 = Person.class;
        System.out.println(class2.hashCode());
        //3.通过静态方法获取类对象[推荐使用，不依赖于对象，因为输入的是一个字符串，只要运行的时候存在该类即可]
        Class<?> class3 = Class.forName("com.qf.Chapter17_1.Person");
        System.out.println(class3.hashCode());
    }
    //1.通过反射获取类的名字，包名，父类，接口
    public static void reflectOpe1() throws Exception {

        //获取类对象
        Class<?> class1 = Class.forName("com.qf.Chapter17_1.Person");
        //getName()
        System.out.println(class1.getName());
        //getPackage()
        System.out.println(class1.getPackage().getName());
        //getSuper()
        System.out.println(class1.getSuperclass().getName());
        //getInterfaces()
        Class<?>[] classes = class1.getInterfaces();
        System.out.println(Arrays.toString(classes));
        System.out.println(class1.getSimpleName());
        System.out.println(class1.getTypeName());
    }

    //2.通过反射获取类的构造方法，创建对象
    public static void reflectOpe2() throws Exception{
        //获取类对象
        Class<?> class1 = Class.forName("com.qf.Chapter17_1.Person");
        //通过反射获取类的构造方法 Constructor
//        Constructor<?>[] cons = class1.getConstructors();
//        for(Constructor<?> con: cons){
//            System.out.println(con.toString());
//        }
        //获取无参构造，并实例化对象
        Constructor<?> con = class1.getConstructor();
        //实例化对象
        Person zhangsan = (Person)con.newInstance();
        System.out.println(zhangsan.toString());
        //简便方法 类对象.newInstance()
        Person wangwu = (Person) class1.newInstance();
        System.out.println(wangwu.toString());
        //获取带参构造
        Constructor<?> conPara = class1.getConstructor(int.class,String.class);
        Person lisi = (Person)conPara.newInstance(20,"lisi");
        System.out.println(lisi.toString());

    }

    //3.通过反射获取类的方法，并调用方法
    public static void reflectOpe3() throws Exception {
        //1.通过反射获取类对象
        Class<?> class1 = Class.forName("com.qf.Chapter17_1.Person");
        //2.通过类对象获取方法 Method对象
        //2.1 getMethods() 只能获取公开的方法，以及继承自父类的方法
//        Method[] methods = class1.getMethods();
        //2.2 getDeclaredMethod() 获取类中的所有方法，包括私有、静态、保护的方法，不包含继承的方法
//        Method[] methods = class1.getDeclaredMethods();
//        for (Method method:methods){
//            System.out.println(method.toString());
//        }
        //3.获取单个方法
        //3.1 eat
        Method eatMethod = class1.getMethod("eat");
        //调用方法
        //正常调用方法 Person zhangsan = new Person()  zhangsan.eat()
        Person zhangsan = (Person)class1.newInstance();
        eatMethod.invoke(zhangsan);//zhangsan.eat()
        System.out.println("--------------------");
        //3.2 toString
        Method toStringMethod = class1.getMethod("toString");
        Object result = toStringMethod.invoke(zhangsan);
        System.out.println(result);
        System.out.println("--------------------");
        //3.3 eat(String food)
        Method eatMethod2 = class1.getMethod("eat",String.class);
        eatMethod2.invoke(zhangsan,"烤肉");

        //3.4 privateMethod() 获取私有方法
        Method privateMethod = class1.getDeclaredMethod("privateMethod");
        //设置访问权限无效
        privateMethod.setAccessible(true);
        privateMethod.invoke(zhangsan);

        //3.5 staticMethod() 获取静态方法
        Method staticMethod = class1.getMethod("staticMethod");
        //正常调用静态方法 类名.静态方法名 无需对象
        staticMethod.invoke(null);
    }

    //4.使用反射实现一个可以调用任何对象方法的通用方法
    //参数包括 调用的对象，方法名，方法的参数类型，方法参数值
    public static  Object invokeAny(Object obj, String methodName, Class<?>[] paraType, Object...args) throws Exception{
        //1.获取类对象
        Class<?> class1 = obj.getClass();
        //2.获取方法
        Method method = class1.getMethod(methodName,paraType);
        //3.调用方法
        method.invoke(obj,args);

        return obj;

    }

    //5.通过反射获取类的属性
    public static void reflectOpe4() throws Exception{
        //1.获取类对象
        Class<?> class1 = Class.forName("com.qf.Chapter17_1.Person");
        //2.获取属性(字段)
        //getFields() 只能获取公开的以及继承自父类的属性
//        Field[] fields = class1.getFields();
        //getDeclaredFields() 可以获取类中所有的属性
        Field[] fields = class1.getDeclaredFields();
        for(Field field:fields){
            System.out.println(field.toString());
        }

        //3.获取name属性
        //设置访问权限无效
        Field nameField = class1.getDeclaredField("name");
        nameField.setAccessible(true);
        //赋值 获取值
        //正常赋值方法 Person zhangsan = new Person zhangsan.name = "张三"
        Person zhangsan = (Person)class1.newInstance();
        nameField.set(zhangsan,"张三");//zhangsan.name = "张三";
        Object result = nameField.get(zhangsan);//zhangsan.name
        System.out.println(result.toString());
    }
}
