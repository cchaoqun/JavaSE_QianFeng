package com.qf.Chapter17_1;

import java.io.Serializable;

/**
 * @Description: Person类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class Person implements Serializable,Cloneable {
    private int age;
    private String name;

    public Person(int age, String name) {
        System.out.println("带参构造执行了...");
        this.age = age;
        this.name = name;
    }

    public Person(){
        System.out.println("无参构造执行了...");
    }



    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void eat(){
        System.out.println(name+"正在吃....");
    }

    @Override
    public String toString() {
        return "Person{" +
                "age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
    //带参方法
    public void eat(String food){
        System.out.println(name+"正在吃..."+food);

    }
    //私有方法
    private void privateMethod(){
        System.out.println("这是一个私有方法...");
    }
    //静态方法
    public static void staticMethod(){
        System.out.println("这是一个静态方法...");
    }
}
