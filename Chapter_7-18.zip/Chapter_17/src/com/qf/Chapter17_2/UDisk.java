package com.qf.Chapter17_2;

public class UDisk implements Usb{
    @Override
    public void Service() {
        System.out.println("U盘开始工作了...");
    }
}
