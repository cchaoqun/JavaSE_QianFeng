package com.qf.Chapter17_2;

public class Fan implements Usb{
    @Override
    public void Service() {
        System.out.println("风扇开始工作了...");
    }
}
