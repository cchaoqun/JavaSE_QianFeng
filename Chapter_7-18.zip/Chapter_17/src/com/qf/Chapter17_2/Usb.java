package com.qf.Chapter17_2;
/** 
 * @Description: 父类产品 
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public interface Usb {
    void Service();
}
