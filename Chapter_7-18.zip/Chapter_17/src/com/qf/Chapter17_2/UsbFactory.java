package com.qf.Chapter17_2;
/**
 * @Description: Usb工厂类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class UsbFactory {
    public static Usb createUsb(String type) throws Exception{
        //获取Usb类对象，将子类的完整类名传递过来，确定创建的是Usb的哪个子类
        Class<?> usbClass = Class.forName(type);
        Usb usb = (Usb)usbClass.newInstance();

        return usb;
    }
}
