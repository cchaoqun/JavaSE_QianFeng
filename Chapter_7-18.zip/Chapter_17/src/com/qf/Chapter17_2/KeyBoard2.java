package com.qf.Chapter17_2;

public class KeyBoard2 implements Usb{
    @Override
    public void Service() {
        System.out.println("键盘2开始工作了...");
    }
}
