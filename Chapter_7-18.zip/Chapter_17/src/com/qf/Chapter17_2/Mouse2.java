package com.qf.Chapter17_2;

public class Mouse2 implements Usb{
    @Override
    public void Service() {
        System.out.println("鼠标2开始工作了...");
    }
}
