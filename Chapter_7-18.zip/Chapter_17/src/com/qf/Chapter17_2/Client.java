package com.qf.Chapter17_2;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Scanner;

/**
 * @Description: 客户类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Client {
    public static void main(String[] args) throws Exception{
//        System.out.println("---------------请选择 1 Mouse 2 Fan 3 UDisk---------------------");
//        Scanner input = new Scanner(System.in);
//        String choice = input.next();
//        Properties properties = new Properties();
//        //1=com.qf.Chapter17_2.Mouse
//        //2=com.qf.Chapter17_2.Fan
//        //3=com.qf.Chapter17_2.UDisk
//        //4=com.qf.Chapter17_2.KeyBoard
//        //5=com.qf.Chapter17_2.Mouse2
//        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\Chapter_17\\src\\com\\qf\\Chapter17_2\\usbProperties.properties");
//        properties.load(fis);
//        fis.close();
//
//        Usb usb = UsbFactory.createUsb(properties.getProperty(choice));
//        if(usb!=null){
//            System.out.println("购买成功！");
//            usb.Service();
//        }else{
//            System.out.println("购买失败，你所选择的产品不存在...");
//        }
        System.out.println("---------------请选择 1 Mouse 2 Fan 3 UDisk---------------------");
        Scanner input = new Scanner(System.in);
        String choice = input.next();
        Properties properties = new Properties();
        //1=com.qf.Chapter17_2.Mouse
//        //2=com.qf.Chapter17_2.Fan
//        //3=com.qf.Chapter17_2.UDisk
//        //4=com.qf.Chapter17_2.KeyBoard
//        //5=com.qf.Chapter17_2.Mouse2
        FileInputStream fis = new FileInputStream("D:\\\\IDEA_Project\\\\Chapter_17\\\\src\\\\com\\\\qf\\\\Chapter17_2\\\\usbProperties.properties");
        properties.load(fis);
        Usb usb = UsbFactory.createUsb(properties.getProperty(choice));
        if(usb!=null){
            System.out.println("购买成功!");
            usb.Service();
        }else{
            System.out.println("你选择的商品不存在，请重新选择...");
        }
        fis.close();

    }
}
