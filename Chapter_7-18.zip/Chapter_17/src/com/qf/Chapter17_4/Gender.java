package com.qf.Chapter17_4;
/**
 * @Description: 性别枚举
 * (1)枚举中必须包含枚举常量，可以包含属性，方法，私有构造方法，
 * (2)枚举常量必须在最前面，彼此之间用逗号隔开，
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public enum Gender {
    MALE,FEMALE;
}
