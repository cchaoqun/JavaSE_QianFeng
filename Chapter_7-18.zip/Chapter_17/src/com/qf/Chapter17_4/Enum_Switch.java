package com.qf.Chapter17_4;
/**
 * @Description:
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Enum_Switch {
    public static void main(String[] args) {
        Season season = Season.SPRING;
        switch(season) {//byte short int char String enum
            case SPRING:
                System.out.println("春天");
                break;
            case SUMMER:
                System.out.println("夏天");
                break;
            case FALL:
                System.out.println("秋天");
                break;
            case WINTER:
                System.out.println("冬天");
                break;
            default:
                break;
        }
    }
}
