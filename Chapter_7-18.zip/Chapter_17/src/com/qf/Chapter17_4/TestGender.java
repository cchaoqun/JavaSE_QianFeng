package com.qf.Chapter17_4;

public class TestGender {
    public static void main(String[] args) {
        Gender gender = Gender.MALE;
        System.out.println(gender.toString());

        Season season = Season.SPRING;
        System.out.println(season.toString());
    }
}
