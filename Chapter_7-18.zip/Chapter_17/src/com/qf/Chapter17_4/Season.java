package com.qf.Chapter17_4;
/**
 * @Description: 季节枚举
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public enum Season {
    SPRING,SUMMER,FALL,WINTER;
}
