package com.qf.Chapter17_5;

import java.lang.reflect.Method;

/**
 * @Description: 反射获取类的注解信息
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Demo {
    public static void main(String[] args) throws Exception{
        //创建类对象
        Class<?> class1 = Class.forName("com.qf.Chapter17_5.Person");
        //获取方法
        Method method = class1.getMethod("show",String.class,int.class,String.class);
        //获取方法的注解
        PersonInfo personInfo = method.getAnnotation(PersonInfo.class);
        System.out.println(personInfo.name());
        System.out.println(personInfo.age());
        System.out.println(personInfo.sex());

        //调用方法
        Person zhangsan = (Person)class1.newInstance();
        method.invoke(zhangsan,personInfo.name(),personInfo.age(),personInfo.sex());
    }
}
