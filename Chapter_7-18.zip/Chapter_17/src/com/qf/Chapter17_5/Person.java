package com.qf.Chapter17_5;

import com.qf.Chapter17_4.Gender;

/**
 * @Description: Person 类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class Person {

    @MyAnnotation()
    public void Service(){

    }
    @MyAnnotation2(value="大肉",num=25,class1=Person.class,gender=Gender.MALE,annotation=@MyAnnotation)
    public void eat(){

    }
    @PersonInfo(name="张三", age=25, sex="男")
    public void show(String name,int age,String sex){
        System.out.println(name+"==="+age+"==="+sex);
    }
}
