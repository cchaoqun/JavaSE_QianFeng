package com.qf.Chapter17_5;

/**
 * @Description: 定义注解
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public @interface MyAnnotation {
    //属性(类似方法)
    String name() default "张三";
    int age() default 20;
}
