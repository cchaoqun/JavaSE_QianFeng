package com.qf.Chapter17_5;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * @Description: 注解
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
@Retention(value= RetentionPolicy.RUNTIME)
public @interface PersonInfo {
    String name();
    int age();
    String sex();
}
