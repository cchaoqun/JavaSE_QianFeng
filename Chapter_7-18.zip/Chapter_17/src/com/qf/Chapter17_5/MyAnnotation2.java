package com.qf.Chapter17_5;

import com.qf.Chapter17_4.Gender;

/**
 * @Description:
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public @interface MyAnnotation2 {
    //String
    String value();
    //基本数据类型
    int num() default 20;
    //Class
    Class<?> class1();
    //枚举
    Gender gender();
    //注解
    MyAnnotation annotation();
    //集合不可以
//    ArrayList<String> arraylist();
}
