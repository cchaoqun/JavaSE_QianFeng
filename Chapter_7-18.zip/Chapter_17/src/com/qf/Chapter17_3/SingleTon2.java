package com.qf.Chapter17_3;

/**
 * @Description: 懒汉式
 * (1)创建一个对象，赋值为null
 * (2)将构造方法改为私有，类外部无法创建对象
 * (3)通过一个公开方法返回该对象
 *
 * 优点：声明周期短 缺点：线程不安全 可以通过synchronized方法 或同步代码块解决
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class SingleTon2 {
    public static SingleTon2 instance = null;
    private SingleTon2(){};
    public static SingleTon2 getInstance(){
        //判断instance==null,若不为空说明其他线程以及进入，对象已创建
        if(instance==null){
        //使用类的类对象作为锁，只有一个
            synchronized (SingleTon2.class){
                if(instance==null){
                    instance = new SingleTon2();
                }
            }
        }
        return instance;

    }
}
