package com.qf.Chapter17_3;
/**
 * @Description: 饿汉式单例
 * (1)创建一个静态常量
 * (2)将构造方法改成私有，类外部无法创建变量
 * (3)通过一个公开的方法返回这个对象
 *
 *
 * 优点：线程安全 缺点：声明周期长，占用空间
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class SingleTon {
    public static final SingleTon instance = new SingleTon();
    private SingleTon(){};
    public static SingleTon getInstance(){
        return instance;
    }
}
