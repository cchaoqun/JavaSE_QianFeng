package com.qf.Chapter17_3;

public class TestSingleTon2 {
    public static void main(String[] args) {
        for (int i = 0; i < 3; i++) {
            new Thread(new Runnable(){
                @Override
                public void run() {
                    System.out.println(SingleTon3.getInstance().hashCode());
                }
            }).start();

        }
        long end = System.currentTimeMillis();
    }
}
