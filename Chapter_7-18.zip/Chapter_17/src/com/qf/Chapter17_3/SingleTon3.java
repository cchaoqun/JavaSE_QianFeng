package com.qf.Chapter17_3;
/**
 * @Description: 懒汉式 静态内部类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/12/1
 */
public class SingleTon3 {
    public static SingleTon3 instance = null;
    private SingleTon3(){};
    private static class Holder{
        static SingleTon3 s = new SingleTon3();
    }
    public static SingleTon3 getInstance(){
        return Holder.s;
    }
}
