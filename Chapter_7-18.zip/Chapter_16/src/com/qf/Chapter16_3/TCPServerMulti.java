package com.qf.Chapter16_3;

import java.net.ServerSocket;
import java.net.Socket;

/**
 * @Description: 多个服务其同时向服务器上传文件
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class TCPServerMulti {
    public static void main(String[] args) throws Exception{
//        //创建SocketServer,并指定端口
//        ServerSocket listener = new ServerSocket(10086);
//        System.out.println("服务器已启动...");
//        //调用accept()，监听客户端请求数据
//        while(true){
//            //服务器不停的对客服端上传数据监听
//            Socket socket = listener.accept();
//            System.out.println(socket.getInetAddress()+"进来了...");
//            //创建线程对象，负责接收数据
//            new SocketThread(socket).start();
//        }
        ServerSocket listener = new ServerSocket(7777);
        System.out.println("服务器启动了...");
        while(true){

            Socket socket = listener.accept();
            System.out.println(socket.getInetAddress().getHostName()+"进来了...");
            new SocketThread(socket).start();

        }

    }
}
