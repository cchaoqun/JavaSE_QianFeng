package com.qf.Chapter16_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 * @Description: 多线程对服务器上传数据
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class SocketThread extends Thread{
//    //创建一个Socket
//    private Socket socket;
//    //将Socket传递到线程
//    public SocketThread(Socket socket){
//        this.socket=socket;
//    }
//
//    @Override
//    public void run() {
//        //判断socket是否为空
//        if(socket!=null){
//            InputStream is = null;
//            BufferedReader br = null;
//            try {
//                //获取字节输入流
//                is = socket.getInputStream();
//                //字符缓冲流进行包装
//                br = new BufferedReader(new InputStreamReader(is,"utf-8"));
//                //读取数据
//                while(true){
//                    String data = br.readLine();
//                    if(data==null){//客服端关闭
//                        break;
//                    }
//                    //data不等于null,打印地址
//                    System.out.println(socket.getInetAddress()+"说："+data);
//                    if(data.equals("886")||data.equals("byebye")){//指定语句表明关闭客服端
//                        break;
//                    }
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }finally{
//                try {
//                    br.close();
//                    socket.close();
//                    System.out.println(socket.getInetAddress()+"退出了...");
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//
//            }
//
//
//        }
//
//    }

    private Socket socket;
    public SocketThread(Socket socket){
        this.socket = socket;
    }

    @Override
    public void run() {
        if(socket!=null){
            InputStream is = null;
            BufferedReader br = null;
                try {
                    is = socket.getInputStream();
                    br = new BufferedReader(new InputStreamReader(is, "utf-8"));
                    while(true) {
                        String dataIn = br.readLine();
                        if (dataIn == null) {
                            break;
                        }
                        System.out.println(socket.getInetAddress() + "说：" + dataIn);
                        if (dataIn.equals("886") || dataIn.equals("byebye")) {
                            System.out.println("客户端想要结束会话...");
                            break;
                        }
                    }
                } catch (Exception e) {
                        e.printStackTrace();;
                }finally{
                    try {
                        br.close();
                        socket.close();
                        System.out.println("服务器退出了...");
                    } catch (IOException e) {
                        e.printStackTrace();;
                    }

                }

        }

    }
}
