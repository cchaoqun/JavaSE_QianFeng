package com.qf.Chapter16_3;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * @Description:  多个服务其同时向服务器上传文件
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class TCPClientMulti {
    public static void main(String[] args) throws Exception{
//        //创建Socket并指定IP和端口号
//        Socket socket = new Socket("192.168.0.104",10086);
//        //获取输出流
//        OutputStream os = socket.getOutputStream();
//        //转换流将字节流转换成字符流，并用缓冲流封装
//        BufferedWriter bw= new BufferedWriter(new OutputStreamWriter(os,"utf-8"));
//        //向服务器写数据
//        Scanner input = new Scanner(System.in);
//        while(true){
//            //输入数据
//            String data = input.nextLine();
//            bw.write(data);
//            bw.newLine();
//            bw.flush();
//            if(data.equals("886")||data.equals("byebye")){
//                break;
//            }
//        }
//        //关闭
//        bw.close();
//        socket.close();


        Socket socket = new Socket("192.168.0.104",7777);
        OutputStream os = socket.getOutputStream();
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os, "utf-8"));
        System.out.println("客户端启动了...");
        Scanner input = new Scanner(System.in);
        while(true){
            String data = input.next();
            System.out.println("客户端发送了数据："+data);
            bw.write(data);
            bw.newLine();
            bw.flush();
            if(data.equals("886")||data.equals("byebye")){
                System.out.println("客户端正在结束对话...");
                break;
            }
        }
        bw.close();
        socket.close();

    }
}
