package com.qf.Chapter16_1;

import java.net.InetAddress;

/**
 * @Description: InetAddress的使用
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class Demo_InetAddress {
    public static void main(String[] args) throws Exception{
        //1创建本机IP地址对象
        //1.1 getLocalHost
        InetAddress ia1 = InetAddress.getLocalHost();
        System.out.println("IP地址："+ia1.getHostAddress()+" 主机名"+ia1.getHostName());
        //1.2 getByName("IP地址")
        InetAddress ia2 = InetAddress.getByName("192.168.0.104");
        System.out.println("IP地址："+ia2.getHostAddress()+" 主机名"+ia2.getHostName());
        //1.3 getByName("LocalHost")
        InetAddress ia3 = InetAddress.getByName("LocalHost");
        System.out.println("IP地址："+ia3.getHostAddress()+" 主机名"+ia3.getHostName());
        //1.4 getByName("127.0.01")
        InetAddress ia4 = InetAddress.getByName("127.0.0.1");
        System.out.println("IP地址："+ia4.getHostAddress()+" 主机名"+ia4.getHostName());

        //2创建局域网IP地址对象
//        InetAddress ia5 = InetAddress.getByName("192.168.0.105");
//        long start = System.currentTimeMillis();
//        System.out.println("IP地址："+ia5.getHostAddress()+" 主机名"+ia5.getHostName());
//        long end = System.currentTimeMillis();
//        System.out.println("查询时间："+(end-start));
//        System.out.println("2秒钟是否可达:"+ia5.isReachable(2000));


        //3创建外网IP地址对象
        InetAddress ia6 = InetAddress.getByName("www.bytedance.com");
        System.out.println("IP地址："+ia6.getHostAddress()+" 主机名"+ia6.getHostName());
        System.out.println("2秒钟是否可达:"+ia6.isReachable(2000));
        InetAddress[] ia7 = InetAddress.getAllByName("WWW.bytedance.com");
        for (InetAddress ia:ia7){
            System.out.println(ia.getHostAddress());
        }



    }
}
