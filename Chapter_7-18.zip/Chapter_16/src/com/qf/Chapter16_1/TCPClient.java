package com.qf.Chapter16_1;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 * @Description: 基于TCP客户端编程
 * (1)创建Socket，并指定IP地址和端口
 * (2)获取输出流，发送请求数据到服务器
 * (3)获取输入流，获取服务器的响应数据到客服端
 * (4)释放资源
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class TCPClient {
    public static void main(String[] args) throws Exception{
//        //     * (1)创建Socket，并指定IP地址和端口
//        Socket socket = new Socket("192.168.0.104",8899);
////     * (2)获取输出流，发送请求数据到服务器
//        //字节流
//        OutputStream os = socket.getOutputStream();
//        //字符缓冲流                                转换流               字节流
//        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os,"utf-8"));
//        System.out.println("客户端发送了数据...");
//        bw.write("好久不见");
////     * (3)获取输入流，获取服务器的响应数据到客服端[可选]
////     * (4)释放资源
//        bw.close();
//        socket.close();


        //* (1)创建Socket，并指定IP地址和端口
        Socket socket = new Socket("192.168.0.104",9999);
        // * (2)获取输出流，发送请求数据到服务器
        OutputStream os = socket.getOutputStream();
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os, "utf-8"));
        System.out.println("客户端发送了数据...");
        bw.write("Long time no see");
        bw.newLine();
        // * (3)获取输入流，获取服务器的响应数据到客服端
        // * (4)释放资源
        bw.close();
        socket.close();

    }

}
