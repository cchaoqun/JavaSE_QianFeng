package com.qf.Chapter16_2;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @Description: TCP客户端文件上传到服务器
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class TCPFileServer {
    public static void main(String[] args) throws Exception{
//        //1.创建ServerSocket,并指定端口号
//        ServerSocket listener = new ServerSocket(9999);
//        //2.监听，调用accept方法
//        System.out.println("服务器启动了...");
//        Socket socket = listener.accept();
//        //3.获取输入流
//        InputStream is = socket.getInputStream();
//        //获取输出流
//        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\002.jpg");
//        //边读取，边保存
//        int count = 0;
//        byte[] buf = new byte[1024*4];
//        while ((count=is.read(buf))!=-1) {
//            fos.write(buf,0,count);
//        }
//        fos.close();
//        socket.close();
//        listener.close();
//        System.out.println("接收完毕");

        ServerSocket listener = new ServerSocket(10086);
        System.out.println("服务器启动了...");
        Socket socket = listener.accept();
        InputStream is = socket.getInputStream();
        FileOutputStream fos = new FileOutputStream("D:\\IDEA_Project\\003.jpg");
        int count = 0;
        byte[] buf = new byte[1024*4];
        while((count=is.read(buf)) != -1){
            fos.write(buf,0,count);
        }
        System.out.println("接收完毕并保存...");
        fos.close();
        socket.close();
        listener.close();
    }
}

