package com.qf.Chapter16_2;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * @Description: TCO文件上传到服务器
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class TCPFileClient {
    public static void main(String[] args) throws Exception{
//        //1.创建Socket，指定IP + 端口
//        Socket socket = new Socket("192.168.0.104",9999);
//        //2.获得输出流
//        OutputStream os = socket.getOutputStream();
//        //边读取文件边发送
//        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\001.jpg");
//        int count = 0;
//        byte[] buf = new byte[1024*4];
//        while((count=fis.read(buf))!=-1){
//            os.write(buf,0,count);
//        }
//        fis.close();
//        os.close();
//        socket.close();
//        System.out.println("发送完毕");

        Socket socket = new Socket("192.168.0.104",10086);
        OutputStream os = socket.getOutputStream();
        FileInputStream fis = new FileInputStream("D:\\IDEA_Project\\002.jpg");
        int count = 0;
        byte[] buf = new byte[1024*4];
        System.out.println("客户端发送了数据...");
        while((count=fis.read(buf)) != -1){
            os.write(buf,0,count);
        }
        System.out.println("发送完毕...");
        fis.close();
        os.close();
        socket.close();
    }
}
