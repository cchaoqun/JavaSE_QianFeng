package com.qf.Chapter16_4;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

/**
 * @Description: 线程实现注册功能
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class RegistThread extends Thread{
    @Override
    public void run() {

//        try {
//            //1.创建ServerSocket,并指定端口
//            ServerSocket listener = new ServerSocket(6666);
//            //2调用accept方法，监听
//            System.out.println("注册服务器启动了...");
//            Socket socket = listener.accept();
//            //3获取字节流，转换成字符流，并用缓冲流封装
//            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//
//            //4接收客户端发送的数据 {id:1001, name:Tom, pwd:123, age:20}
//            String jason = br.readLine();
//            //去掉头尾的 {}  利用逗号分隔获得一个String类数组
//            //[id:1001, name:Tom, pwd:123, age:20]
//            String[] infos = jason.substring(1,jason.length()-1).split(",");
//            //获取数组第一个元素，并用","分割，获得第二个数据即为id
//            String id = infos[0].split(":")[1];
//
//            //5.获得用户注册账号，查询是否存在,加载属性文件
//            Properties properties = Tools.loadProperties();
//            //判断id是否存在于属性文件种
//            if(properties.containsKey(id)){
//                //有
//                bw.write("此用户已存在");
//            }else{
//                //没有，需要将此信息保存到属性文件
//                Tools.saveProperties(jason);
//                bw.write("注册成功！");
//            }
//            bw.newLine();
//            bw.flush();
//            bw.close();
//            br.close();
//            socket.close();
//            listener.close();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        try {
            ServerSocket listener = new ServerSocket(6666);
            System.out.println("注册服务器启动了");
            Socket socket = listener.accept();
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            String json = br.readLine();
            //{id:1001, name:Tom, pwd:123, age:20}
            String[] info = json.substring(1,json.length()-1).split(",");
            String idInput = info[0].split(":")[1];

            Properties properties = Tools.loadProperties();
            if (properties.containsKey(idInput)){
                bw.write("用户已存在！");
            }else {
                Tools.saveProperties(json);
                bw.write("注册成功！");
            }
            bw.newLine();
            bw.flush();

            bw.close();
            br.close();
            socket.close();
            listener.close();






        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
