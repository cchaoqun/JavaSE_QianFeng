package com.qf.Chapter16_4;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

/**
 * @Description: 登录
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class LoginThread extends Thread{
    @Override
    public void run() {
//        try {
//            //1.创建ServerSocket,并指定端口
//            ServerSocket listener = new ServerSocket(7777);
//            //2调用accept方法，监听
//            System.out.println("登录服务器启动了...");
//            Socket socket = listener.accept();
//            //3获取字节流，转换成字符流，并用缓冲流封装
//            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//
//            //4接收客户端发送的数据 {id:1001, pwd:123}
//            String jason = br.readLine();
//            //去掉头尾的 {}  利用逗号分隔获得一个String类数组
//            //[id:1001, pwd:123]
//            String[] infos = jason.substring(1,jason.length()-1).split(",");
//            //获取数组第一个元素，并用","分割，获得第二个数据即为id
//            String id = infos[0].split(":")[1];
//
//
//            //5.获得用户注册账号，查询是否存在,加载属性文件
//            Properties properties = Tools.loadProperties();
//            //判断id是否存在于属性文件中
//            if(properties.containsKey(id)){
//                //CCQ={id\:CCQ, name\:CCQ12138, pwd\:123456, age\:24}
//                //有 判断密码是否正确
//                //获取数组第二个数据即为用户输入的pwd
//                String pwdClient = infos[1].split(":")[1];
//                //获取属性文件里对应用户的密码，判断是否相等
//                String idInfos = properties.getProperty(id);
//                String[] idArray = idInfos.substring(1,idInfos.length()-1).split(",");
//                String pwdServer = idArray[2].split(":")[1];
//                if(pwdClient.equals(pwdServer)){
//                    bw.write("登录成功！");
//                }else{
//                    bw.write("密码错误");
//                }
//
//            }else{
//                //没有，用户不存在
//                bw.write("用户名或密码错误");
//            }
//            bw.newLine();
//            bw.flush();
//            bw.close();
//            br.close();
//            socket.close();
//            listener.close();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        try {
            ServerSocket listener = new ServerSocket(7777);
            System.out.println("登录服务器启动了");
            Socket socket = listener.accept();

            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            //{id:1001, pwd:123}
            String logInfo = br.readLine();
            String[] logInfos = logInfo.substring(1,logInfo.length()-1).split(",");
            String idLogIn = logInfos[0].split(":")[1];
            String pwdLogIn = logInfos[1].split(":")[1];

            //{id:1001, name:Tom, pwd:123, age:20}
            Properties properties = Tools.loadProperties();
            if(properties.containsKey(idLogIn)){
                String userInfo = properties.getProperty(idLogIn);
                String[] userArray = userInfo.substring(1,userInfo.length()-1).split(",");
                String userPwd = userArray[2].split(":")[1];
                if(pwdLogIn.equals(userPwd)){
                    bw.write("登录成功");
                }else{
                    bw.write("密码错误");
                }
            }else{
                bw.write("用户名不存在");
            }
            bw.newLine();
            bw.flush();
            bw.close();
            br.close();
            socket.close();
            listener.close();

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
