package com.qf.Chapter16_4;
/**
 * @Description: 完成注册和登录功能
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class UserServer {
    public static void main(String[] args) {
        new RegistThread().start();
        new LoginThread().start();
    }
}
