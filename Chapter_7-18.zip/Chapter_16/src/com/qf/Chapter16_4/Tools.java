package com.qf.Chapter16_4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @Description: 工具类 加载 保存 properties 
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/30
 */
public class Tools {
    //加载属性文件
    public static Properties loadProperties() {
//        //创建一个集合
//        Properties properties = new Properties();
//        //判断文件是否存在
//        File file = new File("UsersProperties.properties");
//        if(file.exists()){
//            FileInputStream fis = null;
//            try {
//                //创建一个字节输入流
//                fis = new FileInputStream(file);
//                //加载属性文件
//                properties.load(fis);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }finally{
//                //判断是否存在(若fis=null表示文件为空，未读取输入流) 并关闭
//                if(fis!=null){
//                    try {
//                        fis.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//            }
//
//        }
//        //文件不存在返回properties=null
//        return properties;

        Properties properties = new Properties();
        File file = new File("UsersProperties.properties");
        if (file.exists()){
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
                properties.load(fis);

            } catch (Exception e) {
                e.printStackTrace();
            }finally{
                if(fis!=null){
                    try {
                        fis.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return properties;
    }

    //保存属性信息
    public static void saveProperties(String jason){
//        //[id:1001, name:Tom, pwd:123, age:20]
//        String[] infos = jason.substring(1,jason.length()-1).split(",");
//        //获取数组第一个元素，并用":"分割，获得第二个数据即为id
//        String id = infos[0].split(":")[1];
//
//        FileOutputStream fos = null;
//        try {
//            //保存 true不覆盖之前的数据
//            fos = new FileOutputStream("UsersProperties.properties",true);

//            //创建集合
//            Properties properties = new Properties();
//            //往集合存放数据
//            properties.setProperty(id,jason);
//            properties.store(fos," ");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }finally{
//            try {
//                if(fos!=null){
//                    //关闭
//                    fos.close();
//                }
//
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
        //[id:1001, name:Tom, pwd:123, age:20]
        String[] infos = jason.substring(1,jason.length()-1).split(",");
        String id = infos[0].split(":")[1];
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("UsersProperties.properties",true);
            Properties properties = new Properties();
            properties.setProperty(id,jason);
            properties.store(fos,"");

        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(fos!=null){
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
