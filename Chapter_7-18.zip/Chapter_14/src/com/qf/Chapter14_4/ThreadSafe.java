package com.qf.Chapter14_4;

import java.util.Arrays;

/**
 * @Description: 线程安全问题
 * 两个线程同时向一个数组存放数据
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class ThreadSafe {
    //创建数组的索引值
    private static int index=0;

    public static void main(String[] args) throws Exception{
        //创建要存入字符的数组
        String [] s = new String[5];
        //创建可执行的对象A
        Runnable runnableA = new Runnable() {
            @Override
            public void run() {
                //同步代码块
                synchronized(s){
                    s[index] = "Hello";
                    index++;
                }

            }
        };
        //创建可执行的对象B
        Runnable runnableB = new Runnable() {
            @Override
            public void run() {
                //同步代码块
                synchronized(s){
                    s[index] = "World";
                    index++;
                }

            }
        };

        //创建线程对象
        Thread a = new Thread(runnableA);
        Thread b = new Thread(runnableB);
        //启动线程
        a.start();
        b.start();
        //将 a、b两个线程加入到主线程，确保后续打印数组的主线程前，a、b线程以及执行完毕
        a.join();
        b.join();

        System.out.println(Arrays.toString(s));
    }
}
