package com.qf.Chapter14_4;
/**
 * @Description: 测试 同步存钱取钱
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestBankCard {
    public static void main(String[] args) {
        //创建银行卡
        BankCard card = new BankCard();

        //创建两个可执行的操作
        Runnable runnableA = new Runnable() {
            @Override
            public void run() {
                for(int i=0; i<10; i++){
                    synchronized(card){
                        //存钱
                        card.setMoney(card.getMoney()+1000);
                        System.out.println(Thread.currentThread().getName()+" 存了1000,余额是："+card.getMoney());
                    }
                }

            }
        };

        Runnable runnableS = new Runnable() {
            @Override
            public void run() {
                for(int i=0; i<10; i++){
                    synchronized(card){
                        if(card.getMoney() >= 1000){
                            //取钱
                            card.setMoney(card.getMoney()-1000);
                            System.out.println(Thread.currentThread().getName()+"取了1000，余额是"+card.getMoney());
//                            try {
//                                Thread.sleep(200);
//                            } catch (InterruptedException e) {
//                                e.printStackTrace();
//                            }
                        }else{
                            System.out.println("余额不足，请存钱...");
                            i--;
                        }

                    }
                }
            }
        };

        //创建线程
        Thread add = new Thread(runnableA,"CCQ");
        Thread sub = new Thread(runnableS,"Siqi");
        //启动线程
        add.start();
        sub.start();
    }
}
