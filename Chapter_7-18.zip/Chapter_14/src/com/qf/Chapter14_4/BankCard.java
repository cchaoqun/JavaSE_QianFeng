package com.qf.Chapter14_4;
/**
 * @Description: 同步 存钱取钱
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class BankCard {
    private double money;

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }


}
