package com.qf.Chapter14_6;
/**
 * @Description: 取钱
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class SubMoney implements Runnable{
    private BankCard card;

    public SubMoney(BankCard card) {
        this.card = card;
    }

    @Override
    public void run() {
        for(int i=0; i<10; i++){
            card.take(1000);
        }
    }
}
