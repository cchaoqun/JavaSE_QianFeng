package com.qf.Chapter14_6;
/**
 * @Description: 银行卡
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class BankCard {
    private double money;
    //flag作为判断依据，若为true则取钱，若为false则存钱
    private boolean flag = false;
    //存钱
    public synchronized void save(double m){//this
    //判断flag
        while(flag){//有钱
            //flag = true 线程进入等待序列，释放锁和CPU
            try {
                this.wait();//锁.wait()
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //flag=false 存钱
        money = money + m;
        System.out.println(Thread.currentThread().getName()+"存了"+m+"，余额为："+money);
        //改变flag修改标记
        flag = true;
        //唤醒取钱线程
        this.notifyAll();
    }

    //取钱
    public synchronized void take(double m){//this
        //判断flag
        while(!flag){//没钱
            //flag = false 线程进入等待序列，释放锁和CPU
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //flag=true 取钱
        money = money - m;
        System.out.println(Thread.currentThread().getName()+"取了"+m+"，余额为："+money);
        //改变flag修改标记
        flag = false;
        //唤醒存钱线程
        this.notifyAll();

    }
}
