package com.qf.Chapter14_6;
/**
 * @Description: 存钱
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class AddMoney implements Runnable{
    private BankCard card;

    public AddMoney(BankCard card) {
        this.card = card;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            card.save(1000);

        }
    }
}
