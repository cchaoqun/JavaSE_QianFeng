package com.qf.Chapter14_6;

public class TestBankCard {
    public static void main(String[] args) {
        //创建银行卡对象
        BankCard card = new BankCard();
        //创建取钱存钱操作
        AddMoney a = new AddMoney(card);
        SubMoney b = new SubMoney(card);
        //创建两个线程
        Thread CCQ = new Thread(a,"CCQ");
        Thread Siqi = new Thread(b,"Siqi");
        //在创建两个线程 多取多存
        Thread ccq = new Thread(a,"ccq");
        Thread siqi = new Thread(b,"siqi");
        //启动线程
        CCQ.start();
        ccq.start();
        Siqi.start();
        siqi.start();
    }



}
