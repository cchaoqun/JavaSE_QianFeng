package com.qf.Chapter14_5;
/**
 * @Description: 共享卖票类 同步方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TicketShare implements Runnable{
    private int ticket = 100;

    //创建锁
    private Object obj = new Object();

    @Override
    public void run() {
        while(true){
            if(!sale()){
                break;
            }
        }

    }
    //卖票  同步方法
    public synchronized boolean sale(){//非静态方法 锁 this 静态方法 锁 类名.class  Ticket.class
        if(ticket <= 0){
            return false;
        }
        System.out.println(Thread.currentThread().getName()+" 卖了第"+ticket+"张票");
        ticket--;
        return true;
    }
}

