package com.qf.Chapter14_5;
/**
 * @Description: 线程1
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class Boy extends Thread{
    @Override
    public void run() {
        //拿a锁
        synchronized(MyLock.a){
            System.out.println("男孩拿到了a锁");
            //拿b锁
            synchronized(MyLock.b){
                System.out.println("男孩拿到了b锁");
                System.out.println("男孩可以吃饭了...");
            }
        }
    }
}
