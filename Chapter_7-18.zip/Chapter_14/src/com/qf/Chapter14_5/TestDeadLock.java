package com.qf.Chapter14_5;
/**
 * @Description: 测试死锁
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestDeadLock {
    public static void main(String[] args) {
        //创建两个线程对象
        Boy boy = new Boy();
        Girl girl = new Girl();

        //启动线程
        girl.start();
        //通过休眠方法，可以让某一个线程先拿到两个锁再释放，另一个线程再拿
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        boy.start();
    }
}
