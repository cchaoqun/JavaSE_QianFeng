package com.qf.Chapter14_5;
/**
 * @Description: 锁对象
 * 线程必须拿到两个锁才能吃饭
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class MyLock {
    //创建两个锁
    public static Object a = new Object();
    public static Object b = new Object();
}
