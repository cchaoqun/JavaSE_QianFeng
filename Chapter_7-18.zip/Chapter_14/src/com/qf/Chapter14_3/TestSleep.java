package com.qf.Chapter14_3;
/**
 * @Description: 测试线程休眠方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestSleep {
    public static void main(String[] args) {
        SleepThread s1 = new SleepThread();
        s1.start();
        SleepThread s2 = new SleepThread();
        s2.start();
    }
}
