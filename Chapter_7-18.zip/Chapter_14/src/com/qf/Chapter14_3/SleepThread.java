package com.qf.Chapter14_3;
/**
 * @Description: 线程休眠方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class SleepThread extends Thread{
    @Override
    public void run() {//本方法不能抛出异常，因为继承的Thread父类没有抛出异常
        for(int i=0; i<10; i++){
            System.out.println(Thread.currentThread().getName()+"----------"+i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
