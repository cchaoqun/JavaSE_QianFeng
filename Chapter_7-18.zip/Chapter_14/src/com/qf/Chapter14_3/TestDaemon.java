package com.qf.Chapter14_3;

/**
 * @Description: 测试守护线程
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestDaemon {
    public static void main(String[] args) {
        //创建线程
        DaemonThread d1 = new DaemonThread();
        //设置为后台线程（在启动前设置）
        //前台线程结束后，后台线程自动结束
        d1.setDaemon(true);
        d1.start();

        //for 主线程为前台线程
        for(int i=0; i<10; i++){
            System.out.println(Thread.currentThread().getName()+"--------------"+i);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
