package com.qf.Chapter14_3;
/**
 * @Description: 线程优先级设定
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class PriorityThread extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 50; i++) {
            System.out.println(Thread.currentThread().getName()+"-------"+i);

        }
    }
}
