package com.qf.Chapter14_3;

/**
 * @Description: 线程放弃方法测试
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestYield {
    public static void main(String[] args) {
        YieldThread t1 = new YieldThread();
        t1.start();
        YieldThread t2 = new YieldThread();
        t2.start();

    }
}
