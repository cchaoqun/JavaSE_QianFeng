package com.qf.Chapter14_3;
/**
 * @Description: 测试线程加入方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestJoin {
    public static void main(String[] args) throws InterruptedException {
        JoinThread j1 = new JoinThread();
        j1.start();
        try{
            j1.join();//将j1线程加入当前线程（main),直到当前线程执行完毕
        }catch(InterruptedException e){
            e.printStackTrace();
        }

        //for 主线程
        for(int i=0; i<10; i++){
            System.out.println(Thread.currentThread().getName()+"============="+i);
            try{
                Thread.sleep(100);
            }catch(InterruptedException e1){
                e1.printStackTrace();
            }
        }

    }
}
