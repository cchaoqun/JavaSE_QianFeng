package com.qf.Chapter14_3;
/** 
 * @Description: 线程放弃方法
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class YieldThread extends Thread{
    @Override
    public void run() {
        for(int i=0; i<10; i++){
            System.out.println(Thread.currentThread().getName()+"---------"+i);
            //放弃争夺CPU
            Thread.yield();
        }
    }
}
