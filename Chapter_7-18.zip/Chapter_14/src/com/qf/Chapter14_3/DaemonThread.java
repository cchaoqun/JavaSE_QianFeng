package com.qf.Chapter14_3;
/**
 * @Description: 守护线程
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class DaemonThread extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 30; i++) {
            System.out.println(Thread.currentThread().getName()+"---------"+i);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
