package com.qf.Chapter14_3;
/**
 * @Description: 线程加入方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class JoinThread extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            System.out.println(Thread.currentThread().getName()+"-------"+i);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
