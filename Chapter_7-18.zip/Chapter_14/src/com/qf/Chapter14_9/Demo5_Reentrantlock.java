package com.qf.Chapter14_9;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @Description: 重入锁的使用
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class Demo5_Reentrantlock {
    //创建重入锁
    private Lock lock = new ReentrantLock();
    //创建字符串类型数组
    private String [] list = new String[]{"A", "B","","",""};
    //数组索引
    private int index = 2;
    public String [] add(String value){
        //上锁
        lock.lock();
        try{
            list[index] = value;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }finally{
            //释放锁
            lock.unlock();
        }
        index++;
        System.out.println(Thread.currentThread().getName()+"添加了："+value);

        return list;

    }

    public String[] getList() {
        return list;
    }
}
