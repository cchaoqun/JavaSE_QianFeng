package com.qf.Chapter14_9;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Description: 测试读写锁
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class TestReadWriteLock {
    public static void main(String[] args) {
        //创建读写锁
        ReentrantReadWriteLock1 readwritelock = new ReentrantReadWriteLock1();
        //创建线程池
        ExecutorService es = Executors.newFixedThreadPool(20);

        //创建读操作
        Runnable read = new Runnable() {
            @Override
            public void run() {
                readwritelock.getValue();
            }
        };

        //创建写操作
        Runnable write = new Runnable() {
            @Override
            public void run() {
                readwritelock.setValue("CCQ"+ new Random().nextInt(100));
            }
        };

        long start = System.currentTimeMillis();
        //写操作2次
        for (int i = 0; i < 2; i++) {
            es.submit(write);
        }

        //读操作18次
        for (int i = 0; i < 18; i++) {
            es.submit(read);
        }

        //关闭线程
        es.shutdown();

        //若还有线程未执行完毕，空转直到全部结束
        while(!es.isTerminated()){};

        long end = System.currentTimeMillis();

        System.out.println("总用时："+(end-start));
    }
}
