package com.qf.Chapter14_9;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

/**
 * @Description: 读写锁 
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class ReentrantReadWriteLock1 {
    //创建读写锁
    private ReentrantReadWriteLock rrwl = new ReentrantReadWriteLock();
    //获取读锁
    private ReadLock readLock = rrwl.readLock();
    //获取写锁
    private WriteLock writeLock = rrwl.writeLock();

    //若使用互斥锁
    private ReentrantLock lock = new ReentrantLock();

    private String value;

    //读操作
    public String getValue(){
        //1读锁上锁
//        readLock.lock();
        //2互斥锁上锁
        lock.lock();
        try{
            try {
                //每次读取之前休眠1000ms
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //读取值
            System.out.println(Thread.currentThread().getName()+"读取:"+this.value);
            return this.value;
        }finally{
            //1读锁释放锁
//            readLock.unlock();
            //2互斥锁释放锁
            lock.unlock();
        }



    }

    //写操作
    public void setValue(String value){
        //写锁上锁
//        writeLock.lock();
        //2互斥锁上锁
        lock.lock();
        try{
            try {
                //每次写入前休眠1000ms
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //写入
            this.value = value;
            System.out.println(Thread.currentThread().getName()+"写入:"+value);
        }finally{
            //写锁上锁
//            writeLock.unlock();
            //2互斥锁释放锁
            lock.unlock();
        }

    }
}
