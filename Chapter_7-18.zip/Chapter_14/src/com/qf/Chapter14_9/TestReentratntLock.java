package com.qf.Chapter14_9;

import java.util.Arrays;

/**
 * @Description: 测试重入锁
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class TestReentratntLock {
    public static void main(String[] args) throws Exception{
        //创建对象
        Demo5_Reentrantlock list = new Demo5_Reentrantlock();
        //创建两个可执行的操作
        Runnable runnable = new Runnable(){
            @Override
            public void run() {
                list.add("Hello");
            }
        };
        Runnable runnable2 = new Runnable() {
            @Override
            public void run() {
                list.add("World");
            }
        };

        //创建两个线程
        Thread t1 = new Thread(runnable);
        Thread t2 = new Thread(runnable2);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println(Arrays.toString(list.getList()));

    }





}
