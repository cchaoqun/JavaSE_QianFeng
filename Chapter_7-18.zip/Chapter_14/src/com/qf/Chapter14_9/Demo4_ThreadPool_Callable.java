package com.qf.Chapter14_9;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * @Description: 使用两个线程并发计算 1~50 51~100，并求和
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class Demo4_ThreadPool_Callable {
    public static void main(String[] args) throws Exception {
        //1.创建两个线程的线程池
        ExecutorService es = Executors.newFixedThreadPool(2);

        //2.1提交第一个任务到线程池 计算1~50
        Future<Integer> task1 = es.submit(new Callable<Integer>() {

            @Override
            public Integer call() throws Exception {
                System.out.println("开始计算1~50...");
                int sum = 0;
                for(int i=0; i<=50; i++){
                    sum+=i;
                }
                System.out.println("1~50计算完成...");
                return sum;
            }
        });

        //2.2提交第二个任务到线程池 计算51~100
        Future<Integer> task2 = es.submit(new Callable<Integer>() {

            @Override
            public Integer call() throws Exception {
                System.out.println("开始计算51~100...");
                int sum = 0;
                for(int i=51; i<=100; i++){
                    sum+=i;
                }
                System.out.println("51~100计算完成...");
                return sum;
            }
        });

        //3.获取结果
        int sum = task1.get() + task2.get();
        System.out.println("计算结果:"+sum);

        //4.关闭线程池
        es.shutdown();

    }
}
