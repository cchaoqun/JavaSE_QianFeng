package com.qf.Chapter14_2;
/**
 * @Description: 取钱类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class SubMoney implements Runnable{
    private BankCard card;

    public SubMoney(BankCard card) {
        this.card = card;
    }

    @Override
    public void run() {
        for(int i=0; i<10; i++){
            //判断余额是否大于1000
            if(card.getMoney() > 1000){
                //取钱
                card.setMoney(card.getMoney() - 1000);
                System.out.println(Thread.currentThread().getName()+" 取了1000，余额："+card.getMoney());
            }else{
                System.out.println("余额不足，请存钱！！！");
                i--;
            }

        }

    }
}
