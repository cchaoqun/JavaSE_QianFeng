package com.qf.Chapter14_2;
/**
 * @Description: 测试共享卖票
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestTicketShare {
    public static void main(String[] args) {
        //创建可执行的实现类对象
        TicketShare ticket = new TicketShare();
        //创建线程对象
        Thread w1 = new Thread(ticket, "窗口1");
        Thread w2 = new Thread(ticket, "窗口2");
        Thread w3 = new Thread(ticket, "窗口3");
        Thread w4 = new Thread(ticket, "窗口4");

        //启动线程
        w1.start();
        w2.start();
        w3.start();
        w4.start();
    }
}
