package com.qf.Chapter14_2;
/**
 * @Description: 共享卖票类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TicketShare implements Runnable{
    private int ticket = 100;

    //创建锁
    private Object obj = new Object();

    @Override
    public void run() {
        while(true){
            if(ticket <= 0){
                break;
            }
            System.out.println(Thread.currentThread().getName()+" 卖了第"+ticket+"张票");
            ticket--;
        }

    }
}

