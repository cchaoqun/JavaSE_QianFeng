package com.qf.Chapter14_2;
/**
 * @Description: 匿名内部类实现存取钱功能
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestBankCard2 {
    public static void main(String[] args) {
        //创建银行卡对象，用来存钱取钱
        BankCard card = new BankCard();
        //匿名内部实现存取钱对象
        Runnable add = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    //存钱
                    card.setMoney(card.getMoney() + 1000);
                    System.out.println(Thread.currentThread().getName() + " 存了1000，余额：" + card.getMoney());
                }
            }
        };

        Runnable sub = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    //判断余额是否大于1000
                    if (card.getMoney() > 1000) {
                        //取钱
                        card.setMoney(card.getMoney() - 1000);
                        System.out.println(Thread.currentThread().getName() + " 取了1000，余额：" + card.getMoney());
                    } else {
                        System.out.println("余额不足，请存钱！！！");
                        i--;
                    }
                }
            }

        };

        //创建线程对象并启动线程
        new Thread(add, "CCQ").start();
        new Thread(sub, "Siqi").start();
    }
}
