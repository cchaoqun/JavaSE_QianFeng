package com.qf.Chapter14_2;

/**
 * @Description: 存钱类
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class AddMoney implements Runnable {
    private BankCard card;

    public AddMoney(BankCard card) {
        this.card = card;
    }

    @Override
    public void run() {
        for(int i=0; i<10; i++){
            //存钱
            card.setMoney(card.getMoney()+1000);
            System.out.println(Thread.currentThread().getName()+" 存了1000，余额："+card.getMoney());
        }
    }
}
