package com.qf.Chapter14_2;
/**
 * @Description: 测试存取钱功能类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestBankCard {
    public static void main(String[] args) {
        //创建银行卡对象，用来存钱取钱
        BankCard card = new BankCard();
        //创建可执行的存钱取钱类对象
        AddMoney add = new AddMoney(card);
        SubMoney sub = new SubMoney(card);
        //创建线程类
        Thread threadadd = new Thread(add,"CCQ");
        Thread threadsub = new Thread(sub,"Siqi");
        //启动线程
        threadadd.start();
        threadsub.start();
    }
}
