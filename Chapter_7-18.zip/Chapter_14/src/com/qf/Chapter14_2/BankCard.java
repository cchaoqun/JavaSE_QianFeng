package com.qf.Chapter14_2;
/**
 * @Description: 银行卡类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class BankCard {
    private double money = 1000;

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
}
