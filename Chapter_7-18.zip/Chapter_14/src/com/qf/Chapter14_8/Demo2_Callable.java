package com.qf.Chapter14_8;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

/**
 * @Description: 演示Callable接口的使用
 * Callable接口与Runnable接口的区别
 *  (1)Callable接口中的call方法有泛型返回值，Runnbale接口中run方法没有返回值
 *  (2)Callable接口中的call方法可以声明异常，Runnbale接口中run方法不可以声明异常
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class Demo2_Callable {
    //Callable接口实现1-100的和
    public static void main(String[] args) throws Exception{
        //1.匿名内部类创建对象
        Callable<Integer> callable = new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                System.out.println(Thread.currentThread().getName() + "开始计算");
                int sum = 0;
                for(int i=0; i<=100; i++){
                    sum += i;
                    Thread.sleep(100);
                }
                return sum;
            }
        };
        //2.将Callable对象转变成可执行的对象,将callable传递给FutureTask
        //FutureTask实现了RunnbaleFuture接口， RunnableFuture接口继承了Runnable接口
        FutureTask<Integer> task = new FutureTask<>(callable);

        //3.创建线程对象并启动
        Thread cal = new Thread(task);
        cal.start();
        //4.获取结果(等待call执行完毕才会返回值)
        Integer sum = task.get();
        System.out.println("计算结果："+sum);
    }

}
