package com.qf.Chapter14_8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Description: 测试ReentrantLock
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class TestTicket {
    public static void main(String[] args) {
        //创建一张票
        Ticket ticket = new Ticket();
        //创建线程池
        ExecutorService es = Executors.newFixedThreadPool(4);
        //提交任务
        for(int i=0; i<4; i++){
            es.submit(ticket);
        }
        //关闭线程池
        es.shutdown();

    }
}
