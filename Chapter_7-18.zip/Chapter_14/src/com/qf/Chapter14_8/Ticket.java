package com.qf.Chapter14_8;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @Description: 用ReentrantLock重写卖票
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class Ticket implements Runnable {
    //票
    private int ticket = 100;
    //创建重入锁
    private Lock lock = new ReentrantLock();

    @Override
    public void run() {
        while(true){
            //上锁
            lock.lock();
            try{
                if(ticket<=0){
                    break;
                }
                System.out.println(Thread.currentThread().getName() + "卖了第" + ticket + "张票");
                ticket--;
            }finally{
                //释放锁
                lock.unlock();
            }

        }
    }

}
