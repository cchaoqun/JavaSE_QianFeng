package com.qf.Chapter14_8;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * @Description: 通过线程池和Callable实现1-100的和
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class Demo3_Thread_Callable {
    public static void main(String[] args) throws Exception {
        //1.创建线程池
        ExecutorService es = Executors.newFixedThreadPool(1);
        //2.1es提交任务给线程池
        //2.2匿名内部类创建Callable对象任务
        //2.3submit返回的是Future类型(Future表示将要完成任务的结果)
        Future<Integer> task = es.submit(new Callable(){
            @Override
            public Integer call() throws Exception {
                System.out.println(Thread.currentThread().getName()+"开始计算");
                int sum = 0;
                for(int i=0; i<=100; i++){
                    sum+=i;
                    Thread.sleep(10);
                }
                return sum;
            }
        });

        //3.获取结果，等待任务执行完毕才会返回
        System.out.println("计算结果："+task.get());

        //4.关闭线程池
        es.shutdown();
    }
}
