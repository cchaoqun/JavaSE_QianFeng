package com.qf.Chapter14_8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Description: 线程池的创建
 * Executor:线程池的根接口，只有一个方法 executor()
 * ExecutorService:包含管理线程池的一些方法 submit shutdown
 *      ThreadPoolExecutor
 *          ScheduleThreadPoolExecutor
 * Executors: 创建线程池的工具类
 *      (1)创建固定个数线程的线程池
 *      (2)创建缓存线程池，由任务个数确定
 *      (3)创建单线程池，只有一个线程
 *      (4)创建调度线程池，调度：周期，定时执行
 *
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class Demo1_ThreadPool {
    public static void main(String[] args) {
        //1.1创建固定大小线程池
//        ExecutorService es = Executors.newFixedThreadPool(4);
        //1.2创建缓存线程池，由任务个数确定
        ExecutorService es = Executors.newCachedThreadPool();
        //1.3创建单线程池
//        ExecutorService es = Executors.newSingleThreadExecutor();
        //1.4创建调度线程池，调度：周期，定时执行
//        ExecutorService es = Executors.newScheduledThreadPool(int corePoolSize);

        //2.创建任务
        Runnable runnable = new Runnable() {
            //卖票任务
            private int ticket = 100;
            @Override
            public void run() {
                while(true){
                    //同步代码块
                    synchronized (this){
                        if(ticket<=0){
                            break;
                        }
                        System.out.println(Thread.currentThread().getName()+"卖了第"+ticket+"张票");
                        ticket--;
//                        try {
//                            Thread.sleep(200);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
                    }

                }
            }
        };

        //3.提交任务
        for(int i=0; i<5; i++){
            es.submit(runnable);
        }

        //4.关闭线程池
//        es.shutdown();//等待所有任务执行完毕，关闭线程池，不再接受新的任务
        es.shutdownNow();//立即关闭线程池，即使有正在运行的任务
    }

}
