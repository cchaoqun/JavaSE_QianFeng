package com.qf.Chapter14_10;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * @Description: 测试阻塞队列的使用
 * (1)创建一个阻塞队列，添加数据
 * (2)使用阻塞队列实现生产者消费者
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class BlockingQueueDemo {
    public static void main(String[] args) throws Exception{
        //创建一个队列
        ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<>(5);

        //添加元素,不适用，add\offer
        queue.put("aaa");
        queue.put("bbb");
        queue.put("ccc");
        queue.put("ddd");
        queue.put("eee");
        //删除元素
        queue.take();
        System.out.println("添加了5个元素");
        queue.put("fff");
        System.out.println("添加了第6个元素");

    }
}
