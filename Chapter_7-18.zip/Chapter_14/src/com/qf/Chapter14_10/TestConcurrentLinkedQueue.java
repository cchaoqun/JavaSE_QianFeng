package com.qf.Chapter14_10;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @Description: 测试ConcurrentLinkedQueue
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class TestConcurrentLinkedQueue {
    public static void main(String[] args) throws Exception{
        //创建安全队列
        ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<Integer>();
        //分别使用两个线程执行入队操作
        //线程1
        Thread t1 = new Thread(new Runnable(){
            @Override
            public void run() {
                for (int i = 1; i <= 5; i++) {
                    queue.offer(i);
                }
            }
        });
        //线程2
        Thread t2 = new Thread(new Runnable(){
            @Override
            public void run() {
                for (int i = 6; i < 10; i++) {
                    queue.offer(i);
                }
            }
        });

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        //出队操作，必须等两个线程执行万才出队，将这两个线程加入到主线程
        System.out.println("======出队====");
        int size = queue.size();
        for(int i=0; i<size; i++){
            System.out.println(queue.poll());
        }
        System.out.println("出队后队列数量:"+queue.size());
    }
}
