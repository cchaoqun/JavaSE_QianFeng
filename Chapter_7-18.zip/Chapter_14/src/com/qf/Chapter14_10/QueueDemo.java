package com.qf.Chapter14_10;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @Description: Queue接口的使用
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class QueueDemo {
    public static void main(String[] args) {
        //创建队列
        Queue<String> queue = new LinkedList<>();
        //入队
        queue.offer("1");
        queue.offer("2");
        queue.offer("3");
        queue.offer("4");
        queue.offer("5");
        //peek
        System.out.println(queue.peek());
        System.out.println("----------");
        System.out.println("出队前元素数量："+queue.size());
        //出队
        int size = queue.size();
        for (int i = 0; i < size; i++) {
            System.out.println(queue.poll());
        }
        System.out.println("出队后元素数量："+queue.size());
    }
}
