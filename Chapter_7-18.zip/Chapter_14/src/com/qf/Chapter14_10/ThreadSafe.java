package com.qf.Chapter14_10;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @Description: 使用多线程操作线程不安全的集合
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class ThreadSafe {
    public static void main(String[] args) {
        //1.创建一个ArrayList集合
//        ArrayList<String> arrayList = new ArrayList<>();//线程不安全
//        //1.2使用线程安全方法转变成线程安全的集合
//        List<String> synchlist = Collections.synchronizedList(arrayList);
        //1.3使用 CopyOnWriteArrayList
        CopyOnWriteArrayList<String> arraylist = new CopyOnWriteArrayList<>();
        //2.创建线程
        for(int i=0; i<10; i++){
            int temp = i;
            new Thread(new Runnable(){
                @Override
                public void run() {
                    for (int j = 0; j < 20; j++) {
                        arraylist.add(Thread.currentThread().getName()+"======"+temp+"======"+j);
                        System.out.println(arraylist.toString());
                    }
                }
            }).start();
        }
    }
}
