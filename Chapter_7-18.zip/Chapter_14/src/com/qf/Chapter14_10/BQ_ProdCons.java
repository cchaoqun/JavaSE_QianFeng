package com.qf.Chapter14_10;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * @Description: ArrayBlockingQueue 实现生产者消费者
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class BQ_ProdCons {
    public static void main(String[] args) {
        //创建一个队列
        ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<>(6);

        //创建两个线程
        new Thread(new Runnable(){
            @Override
            public void run() {
                for (int i = 0; i < 30; i++) {
                    synchronized (this){
                        int temp = i;
                        try {
                            queue.put(temp);
                            System.out.println(Thread.currentThread().getName()+"生产了第"+temp+"块面包");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }


                }
            }
        },"CCQ").start();

        new Thread(new Runnable(){
            @Override
            public void run() {
                for (int i = 0; i < 30; i++) {
                    synchronized (this){
                        int temp = i;
                        try {
                            queue.take();
                            System.out.println(Thread.currentThread().getName()+"消费了第"+temp+"块面包");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }


                }
            }
        },"Siqi").start();
    }
}
