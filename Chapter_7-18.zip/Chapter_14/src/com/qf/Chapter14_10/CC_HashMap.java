package com.qf.Chapter14_10;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @Description: 多线程操作ConcurrentHashMap
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/29
 */
public class CC_HashMap {
    public static void main(String[] args) {
        //创建集合
        ConcurrentHashMap<String, String> hashmap = new ConcurrentHashMap<>();
        //使用5个线程，每个向集合添加10个数据
        for (int i = 0; i < 5; i++) {
            new Thread(new Runnable(){
                @Override
                public void run() {
                    for (int j = 0; j < 10; j++) {
                        hashmap.put(Thread.currentThread().getName()+"--"+j,"->"+j);
                        System.out.println(hashmap.toString());
                    }
                }
            }).start();
        }

    }
}
