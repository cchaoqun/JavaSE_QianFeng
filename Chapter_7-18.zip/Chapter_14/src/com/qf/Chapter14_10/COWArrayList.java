package com.qf.Chapter14_10;

import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Description: 使用多线程操作 CopyOnWriteArrayList
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class COWArrayList {
    public static void main(String[] args) {
        //1.创建集合
        CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
        //2.创建线程池
        ExecutorService es = Executors.newFixedThreadPool(5);
        //3.提交5个任务给线程池
        for (int i = 0; i < 5; i++) {
            es.submit(new Runnable(){
                @Override
                public void run() {
                    for (int j = 0; j < 10; j++) {
                        list.add(Thread.currentThread().getName()+"..."+new Random().nextInt(1000));
                    }
                }
            });
        }

        //4.关闭线程池
        es.shutdown();
        //5.确定任务都执行完毕
        while(!es.isTerminated()){}

        //6.打印结果
        System.out.println("元素个数:"+list.size());
        for (String str:list){
            System.out.println(str);
        }
    }
}
