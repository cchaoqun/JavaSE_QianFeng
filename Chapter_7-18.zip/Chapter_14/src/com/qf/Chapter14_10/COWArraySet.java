package com.qf.Chapter14_10;

import java.util.concurrent.CopyOnWriteArraySet;

/**
 * @Description: 演示CopyOnWriteArraySet
 * 重复依据，equals
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/27
 */
public class COWArraySet {
    public static void main(String[] args) {
        //创建集合
        CopyOnWriteArraySet<String> set = new CopyOnWriteArraySet<>();
        //添加元素
        set.add("苹果");
        set.add("华为");
        set.add("小米");
        set.add("苹果");

        //打印结果
        System.out.println("元素个数:" + set.size());
        System.out.println(set.toString());
    }
}
