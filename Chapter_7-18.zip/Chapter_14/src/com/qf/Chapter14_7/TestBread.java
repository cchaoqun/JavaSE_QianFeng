package com.qf.Chapter14_7;
/**
 * @Description: 测试面包
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TestBread {
    public static void main(String[] args) {
        //创建面包容器
        BreadCon cons = new BreadCon();
        //创建生产和消费操作
        Product product = new Product(cons);
        Consume consume = new Consume(cons);
        //创建两个线程
        Thread CCQ = new Thread(product,"CCQ");
        Thread Siqi = new Thread(consume,"Siqi");
        Thread ccq = new Thread(product,"ccq");
        Thread siqi = new Thread(consume,"siqi");

        //启动线程
        CCQ.start();
        Siqi.start();
        ccq.start();
        siqi.start();

    }
}
