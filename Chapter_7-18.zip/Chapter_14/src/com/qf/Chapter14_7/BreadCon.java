package com.qf.Chapter14_7;
/**
 * @Description: 面包容器
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class BreadCon {
    //创建一个面包产品
    private Bread b;
    //创建一个面包容器数组
    private Bread [] Breadcon = new Bread[6];
    //创建数组索引值
    private int index = 0;

    //取面包方法
    public synchronized void output(){//this锁
        while(index<=0){//没有面包
            try {
                this.wait();//进入等待队列
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //取面包
        index--;
        Bread b = Breadcon[index];
        System.out.println(Thread.currentThread().getName()+"消费了"+b.getId()+" 生产者"+b.getProductName());
        Breadcon[index] = null;
        //唤醒
        this.notifyAll();

    }

    //存面包方法
    public synchronized void  input(Bread b){
        while(index>=6){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //存面包
        Breadcon[index] = b;
        System.out.println(Thread.currentThread().getName()+"生产了面包"+b.getId()+" ");
        index++;
        //唤醒
        this.notifyAll();
    }
}
