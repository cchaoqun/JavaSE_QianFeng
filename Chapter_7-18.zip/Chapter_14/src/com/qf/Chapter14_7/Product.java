package com.qf.Chapter14_7;

public class Product implements Runnable{
    //创建面包容器
    private BreadCon cons;
    //带参构造，把容器传递到生产类中

    public Product(BreadCon cons) {
        this.cons = cons;
    }

    @Override
    public void run() {
        for(int i=0; i<30; i++){
            //调用面包容器的生产方法，生产一个新的面包，并用当前线程的名称为面包赋予名字
            cons.input(new Bread(i,Thread.currentThread().getName()));
        }
    }
}
