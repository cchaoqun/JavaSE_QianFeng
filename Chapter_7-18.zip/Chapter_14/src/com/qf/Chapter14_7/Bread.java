package com.qf.Chapter14_7;
/**
 * @Description: 面包产品
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class Bread {
    private int Id;
    private String productName;

    public Bread() {
    }

    public Bread(int id, String productName) {
        Id = id;
        this.productName = productName;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    @Override
    public String toString() {
        return "Bread{" +
                "Id=" + Id +
                ", productName='" + productName + '\'' +
                '}';
    }
}
