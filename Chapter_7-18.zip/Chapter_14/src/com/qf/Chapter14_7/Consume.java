package com.qf.Chapter14_7;

/**
 * @Description: 消费类
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class Consume implements Runnable {
    //创建面包容器
    private BreadCon cons;
    //带参构造，将容器传递过来
    public Consume(BreadCon cons) {
        this.cons = cons;
    }

    @Override
    public void run() {
        for (int i = 0; i < 30; i++) {
            //调用面包容器消费方法
            cons.output();
        }
    }
}
