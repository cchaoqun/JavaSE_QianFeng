package com.qf.Chapter14_1;
/**
 * @Description: 线程可执行的功能类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class Demo3_Runnable implements Runnable{
    @Override
    public void run() {
        for(int i = 0; i < 100; i++){
            System.out.println(Thread.currentThread().getName()+"----------"+i);
        }
    }
}
