package com.qf.Chapter14_1;
/**
 * @Description: 线程类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class Demo1_Thread extends Thread{
    public Demo1_Thread() {
    }

    public Demo1_Thread(String name){
        //将该name传递给父类Tread中的带参构造方法
       super(name);
    }


    //重写Run方法
    @Override
    public void run() {
        for (int i = 0; i < 100; i++) {
            //第一种方式 this.getId()和this.getName()
            //this.getId() 获取Id
            //this.getName() 获取名称
//            System.out.println("线程ID:"+this.getId()+" 线程名称:"+this.getName()+" 子线程------------"+i);

            //第二种方式 Thread.currentThread() 获取当前线程
            System.out.println("线程ID:"+Thread.currentThread().getId()+" 线程名称:"+Thread.currentThread().getName()+" 子线程------------"+i);
        }
    }
}
