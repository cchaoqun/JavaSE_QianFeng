package com.qf.Chapter14_1;

public class Demo2_TestThread {
    public static void main(String[] args) {
        //创建线程对象
        Demo1_Thread myThread = new Demo1_Thread("我的子线程1");
        //修改线程名称
//        myThread.setName("我的子线程1");
        //调用Run方法启动子线程，不能使用Run方法
        myThread.start();

        Demo1_Thread myThread2 = new Demo1_Thread("我的子线程2");
//        myThread2.setName("我的子线程2");
        myThread2.start();

        //主线程执行
        for(int i = 0; i < 100; i++){
            System.out.println("主线程=============================="+i);
        }
    }
}
