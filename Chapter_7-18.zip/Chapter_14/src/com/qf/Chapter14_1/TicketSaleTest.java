package com.qf.Chapter14_1;
/**
 * @Description: 卖票窗口类测试
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TicketSaleTest {
    public static void main(String[] args) {
        //创建卖票窗口对象
        TicketSale t1 = new TicketSale("窗口1");
        TicketSale t2 = new TicketSale("窗口2");
        TicketSale t3 = new TicketSale("窗口3");
        TicketSale t4 = new TicketSale("窗口4");
        //调用start方法启动线程
        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }

}
