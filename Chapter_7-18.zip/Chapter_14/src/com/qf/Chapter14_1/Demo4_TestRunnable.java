package com.qf.Chapter14_1;
/**
 * @Description: Runnable方法创建线程
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class Demo4_TestRunnable {
    public static void main(String[] args) {
//        //创建实现类对象，表示可执行的功能
//        Demo3_Runnable runnable = new Demo3_Runnable();
//        //创建线程类对象，将可执行的功能传递过来
//        Thread thread = new Thread(runnable, "我的线程1");
//
//        //调用start方法启动子线程
//        thread.start();
//
//        for(int i = 0; i < 50; i++){
//            System.out.println("main=================="+i);
//        }

        //方式2 使用匿名内部类实现

        //创建可运行对象
        Runnable runnable = new Runnable(){
            @Override
            public void run() {
                for(int i = 0; i < 100; i++){
                    System.out.println(Thread.currentThread().getName()+"----------"+i);
                }
            }
        };
        //创建线程对象
        Thread t2 = new Thread(runnable, "我的线程2");
        //启动线程
        t2.start();

        for(int i = 0; i < 50; i++){
            System.out.println("main================="+i);
        }
    }
}
