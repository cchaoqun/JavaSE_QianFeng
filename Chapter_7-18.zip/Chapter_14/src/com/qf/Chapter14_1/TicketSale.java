package com.qf.Chapter14_1;
/** 
 * @Description: 卖票窗口类(线程类)
 *
 *
 *
 * 
 * @Author: CCQ
 * @Date: 2020/11/26
 */
public class TicketSale extends Thread{
    private int ticket = 100;

    public TicketSale() {
    }
    //传递线程名称到父类Thread,在创建对象时可以修改线程名称
    public TicketSale(String name) {
        super(name);
    }

    @Override
    public void run() {
        while(true){
            //这里先判断sale()返回值，如果为false则表明没票了，如果为true,则表明有票且依据执行了打印语句和ticket--
            if(!sale()){
                break;
            }
        }


    }

    public synchronized boolean sale(){
        while(true){
            if(ticket<=0){
                return false;
            }
            System.out.println(Thread.currentThread().getName()+"卖了第"+this.ticket+"张票");
            ticket--;
            return true;
        }
    }
}
