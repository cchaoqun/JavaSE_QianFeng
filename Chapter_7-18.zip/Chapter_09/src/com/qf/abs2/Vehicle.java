package com.qf.abs2;
/*
* 交通工具类
*
*
* */
public abstract class Vehicle {
    //交通工具品牌
    private String brand;
    //默认构造方法
    public Vehicle(){

    }
    //带参构造方法
    public Vehicle(String brand){
        super();
        this.brand = brand;
    }

    //Get Set
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    //前进
//    public void run(){
//        System.out.println("交通工具正在前进...");
//    }
    //抽象方法
    public abstract void run();
}
