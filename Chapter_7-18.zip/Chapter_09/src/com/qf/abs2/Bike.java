package com.qf.abs2;

public class Bike extends Vehicle{

    //默认构造方法
    public Bike(){

    }
    //带参构造方法
    public Bike(String brand) {
        super(brand);
    }

    //方法重写
    public void run(){
        System.out.println(super.getBrand()+"牌自行车正在前进...");
    }
}
