package com.qf.abs2;

public class Master {
    //封装名称
    private String name;
    //默认构造方法
    public Master(){

    }
    //带参构造方法
    public Master(String name) {
        super();
        this.name = name;
    }
    //Get Set
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    //回家方法
    //回家需要借助交通工具，添加交通工具为形参
    public void goHome(Vehicle vehicle){
        System.out.println(this.name+"下班回家了...");
        vehicle.run();
    }
}
