package com.qf.abs2;

/*
* 汽车类
*
* */
public class Car extends Vehicle{

    //默认构造方法
    public Car(){

    }
    //根据父类生成带参构造

    public Car(String brand) {
        super(brand);
    }

    //方法重写
    //父类中brand经过private封装，需调用get方法获取brand值
    public void run(){
        System.out.println(super.getBrand()+"牌汽车在前进...");
    }
}
