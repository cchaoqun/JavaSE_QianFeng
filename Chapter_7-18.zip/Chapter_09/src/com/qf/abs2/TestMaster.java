package com.qf.abs2;

public class TestMaster {
    public static void main(String[] args) {
        //定义人
        Master xiaoming = new Master("小明");
        //定义两个交通工具子类
        Vehicle car = new Car("宝马");
        Vehicle bike = new Bike("永久");
        xiaoming.goHome(car);
        xiaoming.goHome(bike);
    }
}
