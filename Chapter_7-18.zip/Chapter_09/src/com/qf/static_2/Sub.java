package com.qf.static_2;

public class Sub extends Super{
    static String Sub_Field = "子类静态属性";

    //动态代码块
    static{
        System.out.println(Sub_Field);
        System.out.println("子类静态代码块");
    }

    String subField = "子类实例属性";
    {
        System.out.println(subField);
        System.out.println("子类动态代码块");
    }

    public Sub(){
        System.out.println("子类构造方法");
    }
}
