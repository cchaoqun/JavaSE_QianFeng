package com.qf.static_2;
/*
* 动态代码块
*   创建对象时，触发动态代码块的执行(每创建一个对象，触发一次动态代码块的执行)
*   执行地位：初始化属性之后，构造方法之前
*   作用：为实例对象赋值，或必要的行为
*
*
*
* */
public class TestDynamicBlock {
    public static void main(String[] args) {
        //创建对象
        new DynamicBlock();
        new DynamicBlock();
        new DynamicBlock();

    }
}
