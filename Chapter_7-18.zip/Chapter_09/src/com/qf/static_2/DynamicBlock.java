package com.qf.static_2;
/*
* 动态代码块
*
*
* */
public class DynamicBlock {
    String field = "实例属性";

    //动态代码块
    {
        System.out.println(field);
        System.out.println("动态代码块");
    }

    public DynamicBlock(){
        System.out.println("构造方法");
    }
}
