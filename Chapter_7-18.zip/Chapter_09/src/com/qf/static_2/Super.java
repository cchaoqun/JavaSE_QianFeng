package com.qf.static_2;

public class Super {
    static String Super_Field = "父类静态属性";

    //动态代码块
    static{
        System.out.println(Super_Field);
        System.out.println("父类静态代码块");
    }

    String superField = "父类实例属性";
    {
        System.out.println(superField);
        System.out.println("父类动态代码块");
    }

    public Super(){
        System.out.println("父类构造方法");
    }
}
