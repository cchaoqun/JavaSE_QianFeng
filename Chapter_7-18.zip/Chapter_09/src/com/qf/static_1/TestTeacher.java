package com.qf.static_1;

public class TestTeacher {
    public static void main(String[] args) {
        System.out.println("Teacher类对象被创建次数："+Teacher.count);
        Teacher t1 = new Teacher();
        Teacher t2 = new Teacher();
        Teacher t3 = new Teacher();
        System.out.println("Teacher类对象被创建次数："+Teacher.count);


    }
}
