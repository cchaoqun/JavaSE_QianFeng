package com.qf.static_1;
/*
* 统计一个类的对象被创建多少次
*
*
* */
public class Teacher {
    //姓名
    String name;
    //年龄
    int age;
    //工资
    double salary;
    //静态属性 统计Teacher类对象被创建次数
    static int count;

    //通过构造方法中每创建一次count++
    public Teacher(){
        Teacher.count++;
    }

    public void show(){
        System.out.println(name+"---"+age+"---"+salary);
    }
}
