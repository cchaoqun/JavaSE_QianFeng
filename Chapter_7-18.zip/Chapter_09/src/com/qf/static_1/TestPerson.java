package com.qf.static_1;

public class TestPerson {
    public static void main(String[] args) {
        //创建对象，触发静态代码块执行一次
//        Person p1 = new Person();
//        Person p2 = new Person();
//        Person p3 = new Person();
        //调用静态方法，也触发静态代码块执行一次
        Person.method();
        Person.method();
        Person.method();
    }

}
