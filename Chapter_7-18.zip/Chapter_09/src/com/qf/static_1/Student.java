package com.qf.static_1;

public class Student {
    //学生姓名
    String name;
    //学生年龄
    int age;
    //静态属性 学生数量 属于整个类共有的属性
    static int count;

    public void show(){
        System.out.println(name+"----"+age);
    }

    public static void method1(){//static 修饰的静态方法
        System.out.println("第一个静态方法");
        method2();//本类中通过"静态方法名"访问
        //静态方法可以直接访问静态成员
        count = 10000;
        //静态方法不可以直接访问非静态成员: 非静态属性需要通过创建对象来访问，而静态方法无需创建对象
//        name = "xiaoming"
//        show();
    }
    public static void method2(){
        System.out.println("第二个静态方法");
    }
}
