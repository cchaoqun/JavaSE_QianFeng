package com.qf.static_1;
/*
* 静态
*   静态可以修饰属性和方法
*   称为静态属性(类属性)和静态方法(类方法)
*   静态成员为全类所有对象共享的成员
*   静态属性和方法只有一个，不因为创建多个对象而产生多份
*   无需创建对象，通过类名.静态属性名访问
* 静态的特点
*   静态方法可以直接访问静态
*
*
* */
public class TestStudent {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.name = "aaa";
        s1.age = 20;

        Student s2 = new Student();
        s2.name = "bbb";
        s2.age = 22;

        s1.show();
        s2.show();
        //------调用静态属性 类名.静态属性名
        Student.count = 50;
        //也可以用 对象.静态属性名，但是会有警告，静态属性实际属于整个类而非单个对象
//        s1.count = 100;
        System.out.println("班级学生数量："+Student.count);

        //------调用静态方法 类名.静态方法名
        System.out.println("=========调用静态方法============");
        //在其它类中通过 "类名.静态方法名" 访问
        Student.method1();
        Student.method2();
    }


}
