package com.qf.static_1;
/*
* 静态代码块
*   类加载时，触发静态代码块的执行(仅执行一次)
*   执行地位：静态属性初始化之后
*   作用：可为静态属性赋值
*   静态方法只有被调用时才执行
* 类加载
*   JVM首次使用某个类的时候，通过CLASSPATH查找该类的.class文件
*   将.class文件中对类的描述信息加载到内存中保存
*       如：包名，类名，父类，属性，方法，构造方法...
* 加载时机
*   创建对象
*   创建子类对象
*   访问静态属性
*   调用静态方法
*   主动加载 Class.forName
*
*
* */
public class Person {
    //名字
    String name;
    //静态成员 最大数量
    static int max = 0;
    //静态代码块：类加载的时候，则执行静态代码块，只执行一次
    static{
        //为静态属性赋值
        max = 10000;
        System.out.println("人的最大数量："+max);
    }
    //静态方法
    public static void method(){

    }

}
