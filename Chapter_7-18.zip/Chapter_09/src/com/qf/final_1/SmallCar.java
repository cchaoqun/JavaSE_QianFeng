package com.qf.final_1;

public class SmallCar extends Car{
    //父类 run()方法被final修饰，不能被重写

//    @Override
//    public void run() {
//        System.out.println("小汽车正在前进...");
//    }
}
