package com.qf.final_1;
/*
* final 修饰类，不能被继承
*
*
* */
public class Car {
    //-------------------------------------------------------
    //final修饰实例变量 -> 实例常量
    //实例常量不在提供默认值，必须手动赋予初始值
    //final String brand = "宝马";
    final String brand;
    //构造方法中为实例常量赋值，必须保证所有构造方法都能为其正确赋值
    public Car(){
        this.brand = "宝马";
    }
    public Car(String brand){
        this.brand = brand;
    }
    //-------------------------------------------------------
    //final 修饰静态变量 -> 静态常量, 静态常量不在提供默认值，需手动赋予初始值，且只能赋值一次
    //赋值时机：显示时机，静态代码块
    final static String ADDRESS;
    static{
        ADDRESS = "德国";
    }
    //-------------------------------------------------------

    String name;

    //final 修饰方法，不能被重写和覆盖，但可以被继承
    public final void run(){
        System.out.println("汽车正在前进...");
        //final修饰变量，变量值不可被修改，变成常量
        final int num = 10;
//        num = 20;
        final String city = "北京";
//        city = "上海";
    }
}
