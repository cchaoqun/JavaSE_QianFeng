package com.qf.final_1;

/*
* final 总结
*   final修饰类: 类不可被继承
*   final修饰方法: 该方法不可以被重写覆盖，但可以被继承
*   final修饰变量: 此变量值不可改变，不提供默认值，只能赋值一次
*       局部常量: 显示初始化
*       实例常量: 显示初始化，构造方法
*       静态常量: 显示初始化，静态代码块
*       基本类型常量: 值不可变
*       引用类型常量: 地址不可变，属性可变
*
*
*
*
* */

import java.util.Arrays;

public class TestStudent {
    public static void main(String[] args) {
        //final修饰基本类型，值不可变
        final int num = 20;
        //num = 30;

        //final修饰引用类型，地址不可变
        //-----------------------------------------
        final int[] nums = new int[]{10, 20, 30};
        //不可改变数组的size,但可以改变数组中元素的值
        //nums = new int[5];
        nums[0] = 100;
        System.out.println(Arrays.toString(nums));
        //-----------------------------------------
        final Student s = new Student();
        //引用类型地址不可改变，属性可以改变
        //s = new Student();
        s.name = "aaa";
        s.name = "bbb";
        System.out.println(s.name);
    }

}
