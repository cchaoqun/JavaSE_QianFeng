package com.qf.final_1;
/*
* final类
*   最终类，不可被继承
* final方法
*   最终方法，不能被重写覆盖，但可以被继承
* final变量
*   此变量值不能被改变，常量
*
*
*
*
* */
public class TestCar {
    public static void main(String[] args) {
        SmallCar smallcar = new SmallCar();
        smallcar.run();
    }
}
