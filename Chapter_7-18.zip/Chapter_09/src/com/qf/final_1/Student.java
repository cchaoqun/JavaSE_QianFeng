package com.qf.final_1;

public class Student {
    String name;
}
