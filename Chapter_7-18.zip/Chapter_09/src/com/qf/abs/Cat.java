package com.qf.abs;

public class Cat extends Animal{

    @Override
    public void eat() {
        System.out.println("猫吃鱼...");
    }
}
