package com.qf.abs;

public class Dog extends Animal{

    @Override
    public void eat() {
        System.out.println("狗在吃骨头...");
    }
}
