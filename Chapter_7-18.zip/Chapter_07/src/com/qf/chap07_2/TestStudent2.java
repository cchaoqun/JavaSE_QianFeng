package com.qf.chap07_2;

public class TestStudent2 {
    public static void main(String[] args) {
        /*
        * this
        * 类是模板，可服务于此类的所有对象
        * this是类的默认引用，代表当前实例
        * 当类服务于某个对象时，this则指向这个对象
        *
        *
        *
        * */
        Student s1 = new Student("xiaohei",20,"男", 90);
        s1.sayHi();

        Student s2 = new Student("xiaobai",22,"女", 98);
        s2.sayHi();
    }
}
