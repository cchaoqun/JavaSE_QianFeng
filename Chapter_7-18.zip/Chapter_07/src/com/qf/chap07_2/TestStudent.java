package com.qf.chap07_2;

public class TestStudent {
    public static void main(String[] args) {

        Student xiaoli = new Student();
        //new Student();触发对象创建，
        /*
        * 对象创建的过程
        * (1)内存中开辟一个空间，并赋值属性为默认值
        * (2)调用构造方法初始化
        * (3)把对象地址赋值给变量(存储对象的变量中保存对象的地址，通过变量中的地址访问对象的属性和方法)
        * */
        xiaoli.name = "小李";
        xiaoli.age = 19;
        xiaoli.sex = "男";
        xiaoli.score = 98;
        xiaoli.sayHi();

        //构造方法重载
        /*
        * 创建对象时根据传入参数，匹配对应的构造方法
        * 在类中，如果没有显示定义构造方法，则编译器默认提供无参构造方法
        * 如已手动添加有参构造方法，则不再默认提供无参构造方法，需要手动添加无参构造方法
        *
        * 构造方法为属性赋值
        *   创建对象时，将值传入构造方法
        *   由构造方法为属性赋值
        *
        * */
        Student xiaowang = new Student("小王",17);
        xiaowang.sayHi();

        Student xiaohei = new Student("小黑", 21, "女",98);
        xiaohei.sayHi();
    }
}
