package com.qf.chap07_2;
/*
* 学生类
* 属性
*   姓名
*   年龄
*   性别
*   成绩
* 方法
*   sayHi()//打印学生所有信息
*
*
* */

public class Student {
    //属性

    //姓名
    String name;
    //年龄
    int age;
    //性别
    String sex;
    //成绩
    int score;

    //构造方法
    /*
    * 类中的特殊方法，主要用于创建对象
    * 特点
    *   名称与类完全相同
    *   没有返回值类型 public 类名(){}
    *   创建对象时，触发构造方法的调用，不可通过句点手动调用
    * */
   public Student(){
// 初始化工作
        System.out.println("默认构造方法执行了...");
//        name = "小李";
//        age = 19;
//        sex = "男";
//        score = 98;
    }

    //有参构造方法，遵循方法重载规则

    public Student(String name, int age){
       //如果成员变量和局部变量名相同，由于局部变量优先级高，怎么访问实例变量？使用this
        this.name = name;
        //类变量    局部变量
        this.age = age;
    }

    public Student(String name, int age, String sex, int score){

       /*
       * this调用本类的其他构造方法，即可复用构造方法中的逻辑代码
       *    this(); 调用无参构造
       *    this(实参)；调用有参构造方法，必须时第一条语句
       *注意事项
       *    this()必须是第一条语句
       *    只能调用一次
       * */
//        this.name = name;
//        this.age = age;
        this(name, age);
        this.sex = sex;
        this.score = score;
    }

    //方法
    public void sayHi(){
        System.out.println("大家好，我是" + this.name);
        System.out.println("年龄：" + this.age);
        System.out.println("性别：" + this.sex);
        System.out.println("成绩：" + this.score);

        this.study();
    }

    public void study(){
        System.out.println(this.name+"好好学习");
    }
}
