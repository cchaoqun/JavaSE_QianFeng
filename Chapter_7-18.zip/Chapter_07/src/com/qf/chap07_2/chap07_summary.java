package com.qf.chap07_2;

public class chap07_summary {
    public static void main(String[] args) {

        /*
        * 对象
        *   一切客观存在的事物都是对象
        * 类
        *   定义了对象所具有的特征和行为，类是对象的模板
        * 方法重载
        *   方法名相同，参数列表不同
        * 构造方法
        *   类中用于创建对象的特殊方法，名称与类名相同，没有返回值，不可通过句点调用
        * this关键字
        *   代表当前实例，通过this.访问实例成员，通过this()和this(a, b, ...)访问本类中的其他构造方法
        *
        *
        *
        *
        *
        *
        *
        *
        *
        *
        *
        *
        * */
    }
}
