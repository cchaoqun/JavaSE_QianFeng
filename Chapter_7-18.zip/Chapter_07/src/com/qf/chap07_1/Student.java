package com.qf.chap07_1;
/*
* 学生类
* 属性
*   姓名
*   年龄
*   性别
*   成绩
* 方法
*   sayHi()//打印学生所有信息
*
*
* */

public class Student {
    //属性

    //姓名
    String name;
    //年龄
    int age;
    //性别
    String sex;
    //成绩
    int score;

    //方法
    public void sayHi(){
        System.out.println("大家好，我是" + name);
        System.out.println("年龄：" + age);
        System.out.println("性别：" + sex);
        System.out.println("成绩：" + score);
    }
}
