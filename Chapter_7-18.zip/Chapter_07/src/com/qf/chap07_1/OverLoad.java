package com.qf.chap07_1;
/*
* 方法重载
*  (1)方法名相同
*  (2)参数列表不同(类型，顺序，个数）
*       两个方法的参数名称和参数列表都相同，只是参数名称不一样，不能构成方法重载，编译报错
*  (3)与返回值类型，修饰符无关
*
*
*
*
* */
public class OverLoad {

    public void show(){
        System.out.println("无参方法");
    }

    public void show(int num){
        System.out.println("一个int类型的方法："+num);

    }

    public void show(double num){
        System.out.println("一个double类型的方法："+num);

    }

    public void show(String name){
        System.out.println("一个string类型的方法："+name);

    }

    public void show(int num, String name){
        System.out.println("两个参数int，String类型的方法："+num+'\t'+name);
    }

    public void show(String name, int num){
        System.out.println("两个参数String，int类型的方法："+name+'\t'+num);
    }
}
