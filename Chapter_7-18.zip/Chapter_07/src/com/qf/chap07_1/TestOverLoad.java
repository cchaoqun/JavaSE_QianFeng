package com.qf.chap07_1;

public class TestOverLoad {
    public static void main(String[] args) {
        //创建OverLoad
        OverLoad ope = new OverLoad();

        //调用方法
        ope.show();
        ope.show(100);
        ope.show(100.0);
        ope.show("小张");
        ope.show(100,"小张");
        ope.show("小张",100);

    }
}
