package com.qf.chap07_1;

public class TestDog {

    public static void main(String[] args) {

        //创建一个对象，对象名 myDog
        Dog myDog = new Dog();
        //属性赋值
        myDog.breed = "哈士奇";
        myDog.age = 10;
        myDog.sex = "Male";
        myDog.furColor = "Black and White";
        //获取属性值
        System.out.println("Breed is:" + "\n" + myDog.breed + "\n" + "年龄:" + "\n" + myDog.age);
        //调用方法
        myDog.eat();
        myDog.sleep();

        System.out.println("----------------------");

        Dog myDog2 = new Dog();
        System.out.println(myDog2.breed);
        System.out.println(myDog2.age);
        System.out.println(myDog2.sex);
        System.out.println(myDog2.furColor);
    }
}
