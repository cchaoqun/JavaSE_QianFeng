package com.qf.chap07_1;

public class TestTeacher {
    public static void main(String[] args) {
        //声明类
        Teacher wang = new Teacher();
        Student xiaoming = new Student();

        wang.name = "王老师";
        wang.age = 35;
        wang.salary = 50000;

        xiaoming.name = "小明";
        xiaoming.age = 18;
        xiaoming.sex = "男";
        xiaoming.score = 99;

        wang.sayHi();
        wang.know(xiaoming);


    }
}
