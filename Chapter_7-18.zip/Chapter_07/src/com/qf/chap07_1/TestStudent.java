package com.qf.chap07_1;

public class TestStudent {
    public static void main(String[] args){

        //声明变量
        Student xiaoming = new Student();

        //赋值
        xiaoming.name = "小明";
        xiaoming.age = 10;
        xiaoming.sex = "男";
        xiaoming.score = 100;
        //调用方法
        xiaoming.sayHi();


    }



}
