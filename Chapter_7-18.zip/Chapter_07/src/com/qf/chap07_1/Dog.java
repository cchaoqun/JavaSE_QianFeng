package com.qf.chap07_1;
/*
* 狗狗类
*
*
*
* */
public class Dog {
    //属性

    //品种
    String breed;
    //年龄
    int age;
    //性别
    String sex;
    //毛色
    String furColor;

    //方法

    //eat吃
    public void eat(){
        System.out.println("eating...");
    }

    //sleep睡觉
    public void sleep(){
        System.out.println("sleeping...");
    }
}
