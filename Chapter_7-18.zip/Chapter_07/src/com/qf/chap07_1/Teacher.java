package com.qf.chap07_1;
/*
* 老师类
* 属性
*   姓名
*   年龄
*   工资
* 方法
*   sayHi()
*   know(Student s)
*
* */
public class Teacher {
    //属性
    String name;
    int age;
    int salary;

    public void sayHi(){
        System.out.println("大家好，我是"+name+"我今年"+age+"岁。");
    }

    public void know(Student s){
        System.out.println(name+"要认识学生");
        s.sayHi();
    }
}
