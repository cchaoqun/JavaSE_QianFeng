package com.qf.interface2;
/*
* 接口
* 飞的能力
*
* */
public interface Flyable {
    //public abstract void fly();
    void fly();
}
