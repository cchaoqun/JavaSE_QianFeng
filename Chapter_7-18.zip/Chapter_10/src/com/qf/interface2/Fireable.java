package com.qf.interface2;
/*
* 接口
* 喷火的能力
*
* */
public interface Fireable {
    void fire();
}
