package com.qf.interface2;

public class Person implements Flyable,Fireable{
    String name;
    int age;

    public Person(){

    }
    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }

    public void eat(){
        System.out.println(name+"开始吃...");
    }
    public void sleep(){
        System.out.println(name+"开始睡觉...");
    }

    //实现类必须覆盖接口中所有的方法
    @Override
    public void fly() {
        System.out.println(name+"飞起来了...");
    }
    //喷火的能力
    @Override
    public void fire() {
        System.out.println(name+"可以喷火...");
    }
}
