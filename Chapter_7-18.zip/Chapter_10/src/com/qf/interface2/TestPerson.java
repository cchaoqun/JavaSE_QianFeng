package com.qf.interface2;
/*
* 什么是接口
*   接口是一种能力
*   接口的定义：代表了某种能力
*   方法的定义：能力的具体要求
* 经验：
*   Java为单继承，当父类的方法种类无法满足子类的需求时，可实现接口扩充子类能力
*   接口支持多实现，可为类扩充多种能力
*
* 接口规范
*   任何类在实现接口时，必须实现接口中所有的抽象方法，否则此类为抽象类
*   实现接口中的抽象方法时，访问修饰符必须为 public
* 接口引用
*   同父类一样，接口也可以声明为引用，并指向实现类对象
*   注意：
*       仅可调用接口中所实现的方法，不可以调用实现类中独有的方法
*       可强制转回实现类本身类型，进行独有方法调用
*
*
*
* */
public class TestPerson {
    public static void main(String[] args) {
        Person p = new Person("小明",20);
        p.fly();
        p.fire();
        //==========多态实现接口==========
        System.out.println("==========多态实现接口==========");
        //利用多态实现接口，每个接口只能调用自己的方法而不能调用对象里独有的方法
        Flyable flyable = new Person("小张", 22);
        flyable.fly();
        //flyable.fire();
        Fireable fireable = new Person("小李",23);
        fireable.fire();
        //fireable.fly();
    }
}
