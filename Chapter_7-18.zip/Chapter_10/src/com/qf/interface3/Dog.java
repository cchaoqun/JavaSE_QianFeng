package com.qf.interface3;
/*
* 子类
* 实现类
*
*
* */
public class Dog extends Animal implements Runnable,Swimmable {
    ////父类继承方法重写
    //public void eat(){
    //    System.out.println("狗狗吃狗粮...");
    //}
    //public void sleep(){
    //    System.out.println("狗狗睡觉...");
    //}

    //接口方法
    @Override
    public void run() {
        System.out.println("狗狗跑步");
    }

    @Override
    public void swim() {
        System.out.println("狗狗游泳");
    }

    public void shout(){
        System.out.println("狗狗开始叫...");
    }
}
