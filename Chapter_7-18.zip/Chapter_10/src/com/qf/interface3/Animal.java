package com.qf.interface3;
/*
* 父类
*
*
* */
public abstract class Animal {
    public void eat(){
        System.out.println("吃");
    }
    public void sleep(){
        System.out.println("睡");
    }
}
