package com.qf.interface3;
/*
* 常见关系
*
* 类与类
*   单继承
*   子类名称 extends 父类名称
* 类与接口
*   多实现
*   implements 接口1,接口2,接口n
* 接口与接口
*   多继承
*   子接口名称 extends 父接口1,父接口2,父接口n,
*
*
*
* */
public class TestDog {
    public static void main(String[] args) {
        //多种不同类型的引用指向同一个对象时，表示看待对象的视角不同
        //不同引用看到对象的范围不同，只能调用自身类型中所声明的部分
        Dog dog = new Dog();//将狗当狗看
        Animal a = new Dog();//将狗当动物看
        Runnable r = new Dog();//将狗当可以跑的看
        Swimmable s = new Dog();//将狗当可以游泳的看

    }
}
