package com.qf.interface3;

import java.io.Serializable;

/*
* 接口
* */
public interface Runnable extends Swimmable, Serializable, Cloneable {
    void run();
}
