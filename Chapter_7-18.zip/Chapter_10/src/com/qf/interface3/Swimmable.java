package com.qf.interface3;
/*
* 接口
* */
public interface Swimmable {
    void swim();
}
