package com.qf.interface5;
/*
* Usb接口
*
* */
public interface Usb {
    void service();
}
