package com.qf.interface5;

public class Upan implements Usb{
    @Override
    public void service() {
        System.out.println("U盘连接电脑成功，开始工作...");
    }
}
