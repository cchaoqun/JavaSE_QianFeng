package com.qf.interface5;

public class Computer {
    //声明三个引用类型
    Usb usb1;
    Usb usb2;
    Usb usb3;
    //运行方法
    public void run(){
        System.out.println("电脑开始工作...");
        if (usb1 != null){//值不为空，说明被赋值了即运行了
            usb1.service();
        }
        if (usb2 != null){//值不为空，说明被赋值了即运行了
            usb2.service();
        }
        if (usb2 != null){//值不为空，说明被赋值了即运行了
            usb2.service();
        }

    }
}
