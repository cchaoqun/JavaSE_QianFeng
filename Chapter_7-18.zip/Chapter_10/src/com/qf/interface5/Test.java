package com.qf.interface5;
/*
* 接口回调：先有接口的使用者后有接口的实现者
*
* 什么是接口
*   微观：一种能力和方法
*   宏观：一种标准
* 接口与类的异同
*   没有构造方法，尽可以定义公开静态常量和公开抽象类
* 接口的应用
*   Java为单继承，当父类的方法种类无法满足子类需求时，可实现接口扩充能力
* 接口的规范
*   任何类实现接口时，必须实现接口中所有的抽象方法，否则此类为抽象类
*   实现接口中的抽象类，访问修饰符必须为public
* 常量接口
*   将多个常用于表示状态或固定值的变量，以静态常量的形式定义在接口中统一管理
* 标记接口
*   Serializable
*   Cloneable
* 接口回调
*   先有接口的使用者，后有接口的实现者
*
*
* */
public class Test {
    public static void main(String[] args) {
        Computer lenovo = new Computer();
        //Usb接口声明引用类型创建实例化对象
        Usb mouse = new Mouse();
        Usb fan = new Fan();
        Usb upan = new Upan();
        //把Usb设备连接到电脑上
        lenovo.usb1 = mouse;
        lenovo.usb2 = fan;
        lenovo.usb3 = upan;
        lenovo.run();
    }
}
