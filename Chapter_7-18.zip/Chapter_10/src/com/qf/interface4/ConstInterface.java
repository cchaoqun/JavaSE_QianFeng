package com.qf.interface4;
/*
* 常量接口
*   将多个常用于表示状态或固定值的变量，以静态常量的形式定义在接口中统一管理，提高代码可读性
* 标记接口
*   标记接口中没有包含任意成员，仅仅用作标记
*   Serializable 表示可序列化的
*   Cloneable   表示可以克隆的
*
*
*
*
* */
public interface ConstInterface {
    //
    public static final String CONST1 = "aaa";
    public static final String CONST2 = "bbb";
    public static final String CONST3 = "ccc";
}
