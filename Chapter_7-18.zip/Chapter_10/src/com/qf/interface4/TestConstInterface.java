package com.qf.interface4;

public class TestConstInterface {
    public static void main(String[] args) {
        System.out.println(ConstInterface.CONST1);

    }

}
