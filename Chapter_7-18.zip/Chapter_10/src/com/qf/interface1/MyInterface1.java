package com.qf.interface1;
/*
* 接口
*   不能创建对象
*
* */
public interface MyInterface1 {
    //公开静态常量
    //public static final String name = "接口";
    String name = "接口";//默认公开静态常量
    //公开抽象方法
    //public abstract void method1();
    void method1();
}
