package com.qf.interface1;

public class AbstractClass {
    public AbstractClass(){

    }
}
