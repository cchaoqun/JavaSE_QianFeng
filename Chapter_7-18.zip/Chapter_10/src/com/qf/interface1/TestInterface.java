package com.qf.interface1;
/*
* 接口与抽象类的异同
*
* 相同
*   都可编译成字节码
*   不能创建对象
*   可以作为引用对象
*   具备Object类中定义的方法
* 不同
*   所有属性都是公开静态常量，隐式使用 public static final修饰
*   所有方法都是公开抽象方法，隐式使用 public abstract修饰
*   没有构造方法，动态代码块，静态代码块
*
*
*
*
* */
public class TestInterface {
    public static void main(String[] args) {
        //不能创建对象
        //new MyInterface1();
        //可以定义变量 引用
        //父类定义变量，实例化子类对象 (多态)
        MyInterface1 myInterface1 = new Imple();
        myInterface1.method1();

    }

}

