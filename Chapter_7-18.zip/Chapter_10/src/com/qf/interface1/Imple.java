package com.qf.interface1;

public class Imple implements MyInterface1{//Imple类实现接口
    //Imple覆盖接口中所有的方法
    //鼠标放在Imple -> implement method -> 接口中所有的方法
    @Override
    public void method1() {
        System.out.println("method");
    }

}
