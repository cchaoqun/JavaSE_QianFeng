package com.qf.Chapter13_1;

import java.util.Scanner;

/**
 * @Description:  throws:声明异常,通知调用者处理异常，否则程序中断
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class Demo7_throws {
    public static void main(String[] args) {
        try {
            divide();
        } catch (Exception e) {
            System.out.println("异常："+e.getMessage());
        }
    }
    public static void divide() throws Exception{
        Scanner input = new Scanner(System.in);
        System.out.println("请输入第一个数");
        int n1 = input.nextInt();
        System.out.println("请输入第二个数");
        int n2 = input.nextInt();
        int result = n1 / n2;
        System.out.println("结果：" + result);
        System.out.println("程序执行完毕...");
    }
}
