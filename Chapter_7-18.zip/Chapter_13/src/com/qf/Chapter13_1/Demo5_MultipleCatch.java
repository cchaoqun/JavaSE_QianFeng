package com.qf.Chapter13_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @Description: 多重catch语句
 * try{}   catch(异常1){}   catch(异常2){}
 * (1)子类异常在前，父类异常在后
 * (2)发生异常时，按顺序匹配异常类型
 * (3)只执行匹配的第一个异常类型，其余不在判断
 * (4)finally可根据需要决定是否写
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class Demo5_MultipleCatch {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int result = 0;
        try{
            System.out.println("输入第一个数");
            int n1 = input.nextInt();//InputMismatchException
            System.out.println("输入第二个数");
            int n2 = input.nextInt();
            result = n1 / n2;//ArithmeticException
            String name = null;
            System.out.println(name.equals("hello"));
            //退出JVM
//            System.exit(0);
        }catch(InputMismatchException e){
            System.out.println("输入不匹配异常");
        }catch(ArithmeticException e){
            System.out.println("算数异常");
        }catch(Exception e){
            System.out.println("未知异常");
        }
        System.out.println("结果："+result);
        System.out.println("程序执行完毕...");
    }
}
