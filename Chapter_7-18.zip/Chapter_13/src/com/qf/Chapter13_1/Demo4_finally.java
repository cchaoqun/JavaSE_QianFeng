package com.qf.Chapter13_1;

import java.util.Scanner;

/**
 * @Description:
 * try catch finally的使用
 * finally{...无论是否有异常都执行，用于释放资源}
 *  唯一不执行的情况是退出JVM System.exit(0)
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class Demo4_finally {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int result = 0;
        try{
            System.out.println("输入第一个数");
            int n1 = input.nextInt();//InputMismatchException
            System.out.println("输入第二个数");
            int n2 = input.nextInt();
            result = n1 / n2;//ArithmeticException
            //退出JVM
            System.exit(0);
        }catch(Exception e){
            //打印堆栈信息
            e.printStackTrace();
            System.out.println(e.getMessage());
        }finally {
            System.out.println("释放资源");
        }

        System.out.println("结果："+result);
        System.out.println("程序执行完毕...");
    }
}
