package com.qf.Chapter13_1;

import java.util.Scanner;

/**
 * @Description: 演示异常的产生与传递
 * 要求：输入两个数，实现两个数相除
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class Demo2_Exception2 {
    public static void main(String[] args) {
        operation();

    }
    public static void operation(){
        System.out.println("--------operation()----------");
        divide();
    }
    public static void divide(){
        Scanner input = new Scanner(System.in);
        System.out.println("输入第一个数");
        int n1 = input.nextInt();//出现异常，未处理，程序中断 (输入a)
        System.out.println("输入第二个数");
        int n2 = input.nextInt();
        int result = n1/n2;//出现异常，未处理，程序中断 (除以0)
        System.out.println("结果："+result);
        System.out.println("程序执行完毕了");

    }
}
