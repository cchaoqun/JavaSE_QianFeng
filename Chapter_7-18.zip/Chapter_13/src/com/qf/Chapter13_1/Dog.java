package com.qf.Chapter13_1;

public class Dog extends People{
    public void eat()throws RuntimeException{
        System.out.println("子类吃方法...");
    }
}
