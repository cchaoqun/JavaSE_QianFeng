package com.qf.Chapter13_1;
/**
 * @Description:  年龄异常类
 * (1)继承父类异常
 * (2)创建构造方法
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class AgeException extends RuntimeException{
    public AgeException() {
    }

    public AgeException(String message) {
        super(message);
    }

    public AgeException(String message, Throwable cause) {
        super(message, cause);
    }

    public AgeException(Throwable cause) {
        super(cause);
    }

    public AgeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
