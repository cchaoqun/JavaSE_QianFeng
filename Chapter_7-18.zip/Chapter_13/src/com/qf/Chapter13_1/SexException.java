package com.qf.Chapter13_1;
/**
 * @Description: 性别异常类
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class SexException extends RuntimeException{
    public SexException() {
    }

    public SexException(String message) {
        super(message);
    }

    public SexException(String message, Throwable cause) {
        super(message, cause);
    }

    public SexException(Throwable cause) {
        super(cause);
    }

    public SexException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
