package com.qf.Chapter13_1;

public class TestPerson {
    public static void main(String[] args) {
        Person p1 = new Person();
//        try {
//            p1.setAge(20);
//            p1.setAge(200);
//        } catch (Exception e) {
//            System.out.println("异常:"+e.getMessage());
//        }

        p1.setAge(200);//AgeException:年龄不符合
        System.out.println(p1.toString());
    }
}
