package com.qf.Chapter13_1;

import java.util.Scanner;

/**
 * @Description:  try finally的使用
 * 不能捕获异常，可以释放资源，将异常向上抛出
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class Demo6_tryFinally {
    public static void main(String[] args) {//JVM处理异常
        try {
            divide();
        }catch(Exception e){//可以在main方法中捕获异常并处理
            System.out.println("出现异常："+e.getMessage());
        }

    }
    public static void divide(){
        Scanner input = new Scanner(System.in);
        int result = 0;
        try{
            System.out.println("输入第一个数");
            int n1 = input.nextInt();//InputMismatchException
            System.out.println("输入第二个数");
            int n2 = input.nextInt();
            result = n1 / n2;//ArithmeticException
        }finally{
            System.out.println("释放资源");
        }
        System.out.println("结果："+result);
        System.out.println("程序执行完毕...");
    }
}
