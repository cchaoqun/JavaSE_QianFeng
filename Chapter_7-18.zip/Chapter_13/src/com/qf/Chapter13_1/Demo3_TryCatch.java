package com.qf.Chapter13_1;

import java.util.Scanner;

/**
 * @Description:
 * 演示 try...catch...语句的使用
 * try{...可能发生异常的代码块}
 * catch{...捕获异常并处理}
 * 三种可能的情况
 * (1)程序正常运行
 * (2)产生异常并捕获
 * (3)不能捕获异常 (catch语句中的参数异常与产生的异常不匹配)
 *
 *
 *
 *
 * @Author: CCQ
 * @Date: 2020/11/25
 */
public class Demo3_TryCatch {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int result = 0;
        try{
            System.out.println("输入第一个数");
            int n1 = input.nextInt();//InputMismatchException
            System.out.println("输入第二个数");
            int n2 = input.nextInt();
            result = n1 / n2;//ArithmeticException
        }catch(Exception e){
            //打印堆栈信息
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        System.out.println("结果："+result);
        System.out.println("程序执行完毕...");
    }
}
