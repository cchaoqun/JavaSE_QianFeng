package com.qf.Chapter13_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 *常见异常演示
 *  * RuntimeException: RuntimeException以及所有子类
 *  * CheckedException: Exception及其子类 除了RuntimeException以外
 *
 * @Description:
 * @Author: CCQ
 * @Date: 2020/11/25
 */

public class Demo1_Exception {
    public static void main(String[] args) {
        //1.NullPointerException 空指针异常
//        String name = null;
//        System.out.println(name.equals("zhangsan"));

        //2.ArrayIndexOutOfBoundsException 索引超出异常
//        int [] nums = {100,200,300};
//        System.out.println(nums[3]);

        //3.ClassCastException 类型转换异常
//        Object str = "hello";
//        Integer i = (Integer)str;
//        System.out.println(i);

        //4.NumberFormatException 数字格式化异常
//        int n = Integer.parseInt("100aa");
//        System.out.println(n);

        //5.ArithmeticException 算数异常
//        int n = 10/0;
//        System.out.println(n);

        //CheckedException
        //FileNotFoundException
        try {
            FileInputStream fis = new FileInputStream("d:\\text.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}
