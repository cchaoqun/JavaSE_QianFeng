package com.qf.Chapter13_1;

import java.io.FileNotFoundException;

public class People {
    public void eat()throws FileNotFoundException {
        System.out.println("吃...");
    }
}
